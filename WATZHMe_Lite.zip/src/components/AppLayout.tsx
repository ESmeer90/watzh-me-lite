import React, { useState, useEffect } from 'react';
import { useAuthStore } from '@/stores/authStore';
import { useFeedStore } from '@/stores/feedStore';
import { initErrorReporting } from '@/lib/errorReporting';
import ErrorBoundary from './watzhme/ErrorBoundary';
import OfflineIndicator from './watzhme/OfflineIndicator';
import SplashScreen from './watzhme/SplashScreen';
import BottomNav, { type TabName } from './watzhme/BottomNav';
import FeedScreen from './watzhme/FeedScreen';
import LoginScreen from './watzhme/LoginScreen';
import RegisterScreen from './watzhme/RegisterScreen';
import ForgotPasswordScreen from './watzhme/ForgotPasswordScreen';
import ProfileScreen from './watzhme/ProfileScreen';
import UploadScreen from './watzhme/UploadScreen';
import SearchScreen from './watzhme/SearchScreen';
import InboxScreen from './watzhme/InboxScreen';
import ChatScreen from './watzhme/ChatScreen';
import PrivacyPolicy from './watzhme/PrivacyPolicy';
import TermsOfService from './watzhme/TermsOfService';
import FollowersFollowingScreen from './watzhme/FollowersFollowingScreen';
import AnalyticsScreen from './watzhme/AnalyticsScreen';
import SettingsScreen from './watzhme/SettingsScreen';

type Screen =
  | 'splash'
  | 'feed'
  | 'search'
  | 'create'
  | 'inbox'
  | 'profile'
  | 'login'
  | 'register'
  | 'forgot-password'
  | 'privacy-policy'
  | 'terms-of-service'
  | 'view-profile'
  | 'chat'
  | 'followers-following'
  | 'analytics'
  | 'settings';

// Initialize error reporting on module load
let errorReportingInitialized = false;

const AppLayout: React.FC = () => {
  const { isAuthenticated, isLoading, initialize, logout } = useAuthStore();
  const [currentScreen, setCurrentScreen] = useState<Screen>('splash');
  const [activeTab, setActiveTab] = useState<TabName>('home');
  const [viewProfileId, setViewProfileId] = useState<string | null>(null);
  const [previousScreen, setPreviousScreen] = useState<Screen>('feed');
  const [initialized, setInitialized] = useState(false);
  const [wasOnAuth, setWasOnAuth] = useState(false);

  // Chat state
  const [chatUserId, setChatUserId] = useState<string>('');
  const [chatUsername, setChatUsername] = useState<string>('');
  const [chatAvatarUrl, setChatAvatarUrl] = useState<string | null>(null);

  // Followers/Following state
  const [ffUserId, setFfUserId] = useState<string>('');
  const [ffUsername, setFfUsername] = useState<string>('');
  const [ffInitialTab, setFfInitialTab] = useState<'followers' | 'following'>('followers');

  // Initialize error reporting once
  useEffect(() => {
    if (!errorReportingInitialized) {
      initErrorReporting();
      errorReportingInitialized = true;
      console.log('[App] WATZHMe Lite v1.0.0 initialized');
    }
  }, []);

  // Initialize auth
  useEffect(() => {
    const init = async () => {
      try {
        await initialize();
      } catch (err) {
        console.error('Init error:', err);
      }
      setInitialized(true);
    };
    init();
  }, []);

  // Show splash for minimum 1.5s, then show feed
  useEffect(() => {
    if (initialized) {
      const timer = setTimeout(() => {
        setCurrentScreen('feed');
      }, 1500);
      return () => clearTimeout(timer);
    }
  }, [initialized]);

  // Auto-navigate after successful login
  useEffect(() => {
    if (isAuthenticated && wasOnAuth) {
      setCurrentScreen(previousScreen === 'login' || previousScreen === 'register' ? 'feed' : previousScreen);
      setActiveTab(getTabForScreen(previousScreen === 'login' || previousScreen === 'register' ? 'feed' : previousScreen));
      setWasOnAuth(false);
    }
  }, [isAuthenticated]);

  const navigateToTab = (tab: TabName) => {
    setActiveTab(tab);
    switch (tab) {
      case 'home':
        setCurrentScreen('feed');
        break;
      case 'search':
        setCurrentScreen('search');
        break;
      case 'create':
        if (isAuthenticated) {
          setCurrentScreen('create');
        } else {
          navigateToAuth();
        }
        break;
      case 'inbox':
        if (isAuthenticated) {
          setCurrentScreen('inbox');
        } else {
          navigateToAuth();
        }
        break;
      case 'profile':
        if (isAuthenticated) {
          setViewProfileId(null);
          setCurrentScreen('profile');
        } else {
          navigateToAuth();
        }
        break;
    }
  };

  const navigateToAuth = () => {
    setPreviousScreen(currentScreen);
    setWasOnAuth(true);
    setCurrentScreen('login');
  };

  const navigateBack = () => {
    if (currentScreen === 'chat') { setCurrentScreen('inbox'); return; }
    if (currentScreen === 'analytics') { setCurrentScreen('profile'); setActiveTab('profile'); return; }
    if (currentScreen === 'settings') { setCurrentScreen('profile'); setActiveTab('profile'); return; }
    if (currentScreen === 'followers-following') {
      if (previousScreen === 'view-profile' && viewProfileId) {
        setCurrentScreen('view-profile');
      } else {
        setCurrentScreen(previousScreen);
      }
      return;
    }
    if (currentScreen === 'view-profile') { setCurrentScreen(previousScreen); return; }
    if (currentScreen === 'login' || currentScreen === 'register' || currentScreen === 'forgot-password') {
      setCurrentScreen(previousScreen);
      setActiveTab(getTabForScreen(previousScreen));
      return;
    }
    if (currentScreen === 'privacy-policy' || currentScreen === 'terms-of-service') {
      setCurrentScreen(previousScreen);
      return;
    }
    setCurrentScreen('feed');
    setActiveTab('home');
  };


  const getTabForScreen = (screen: Screen): TabName => {
    switch (screen) {
      case 'feed': return 'home';
      case 'search': return 'search';
      case 'create': return 'create';
      case 'inbox': return 'inbox';
      case 'chat': return 'inbox';
      case 'profile': return 'profile';
      case 'settings': return 'profile';
      default: return 'home';
    }
  };

  const handleProfileClick = (userId: string) => {
    setPreviousScreen(currentScreen);
    setViewProfileId(userId);
    setCurrentScreen('view-profile');
  };

  const handleOpenChat = (userId: string, username: string, avatarUrl: string | null) => {
    setChatUserId(userId);
    setChatUsername(username);
    setChatAvatarUrl(avatarUrl);
    setCurrentScreen('chat');
  };

  const handleFollowersClick = (userId: string, username: string, tab: 'followers' | 'following') => {
    setPreviousScreen(currentScreen);
    setFfUserId(userId);
    setFfUsername(username);
    setFfInitialTab(tab);
    setCurrentScreen('followers-following');
  };

  const handleLogout = async () => {
    await logout();
    setCurrentScreen('feed');
    setActiveTab('home');
  };

  const handleUploadSuccess = () => {
    setCurrentScreen('feed');
    setActiveTab('home');
    useFeedStore.getState().fetchPosts(true);
  };

  const handlePrivacyPolicy = () => {
    setPreviousScreen(currentScreen);
    setCurrentScreen('privacy-policy');
  };

  const handleTermsOfService = () => {
    setPreviousScreen(currentScreen);
    setCurrentScreen('terms-of-service');
  };

  const handleSettings = () => {
    setPreviousScreen('profile');
    setCurrentScreen('settings');
  };

  const showBottomNav = ['feed', 'search', 'inbox', 'profile', 'view-profile'].includes(currentScreen);

  if (currentScreen === 'splash') {
    return <SplashScreen />;
  }

  return (
    <ErrorBoundary onReset={() => { setCurrentScreen('feed'); setActiveTab('home'); }}>
      <div className="h-screen w-full bg-black flex flex-col overflow-hidden">
        {/* Offline indicator */}
        <OfflineIndicator />

        {/* Main content area */}
        <div className="flex-1 relative overflow-hidden">
          {/* Feed */}
          <div className={`absolute inset-0 transition-opacity duration-200 ${currentScreen === 'feed' ? 'opacity-100 z-10' : 'opacity-0 z-0 pointer-events-none'}`}>
            <FeedScreen onProfileClick={handleProfileClick} onAuthRequired={navigateToAuth} />
          </div>

          {/* Search */}
          <div className={`absolute inset-0 transition-opacity duration-200 ${currentScreen === 'search' ? 'opacity-100 z-10' : 'opacity-0 z-0 pointer-events-none'}`}>
            <SearchScreen onPostClick={() => {}} onProfileClick={handleProfileClick} />
          </div>

          {/* Create */}
          <div className={`absolute inset-0 transition-opacity duration-200 ${currentScreen === 'create' ? 'opacity-100 z-10' : 'opacity-0 z-0 pointer-events-none'}`}>
            <UploadScreen onClose={() => { setCurrentScreen('feed'); setActiveTab('home'); }} onSuccess={handleUploadSuccess} />
          </div>

          {/* Inbox */}
          <div className={`absolute inset-0 transition-opacity duration-200 ${currentScreen === 'inbox' ? 'opacity-100 z-10' : 'opacity-0 z-0 pointer-events-none'}`}>
            <InboxScreen isAuthenticated={isAuthenticated} onLogin={navigateToAuth} onOpenChat={handleOpenChat} onProfileClick={handleProfileClick} />
          </div>

          {/* Chat */}
          <div className={`absolute inset-0 transition-opacity duration-200 ${currentScreen === 'chat' ? 'opacity-100 z-20' : 'opacity-0 z-0 pointer-events-none'}`}>
            {chatUserId && (
              <ChatScreen
                otherUserId={chatUserId}
                otherUsername={chatUsername}
                otherAvatarUrl={chatAvatarUrl}
                onBack={() => setCurrentScreen('inbox')}
                onProfileClick={handleProfileClick}
              />
            )}
          </div>

          {/* Own Profile */}
          <div className={`absolute inset-0 transition-opacity duration-200 ${currentScreen === 'profile' ? 'opacity-100 z-10' : 'opacity-0 z-0 pointer-events-none'}`}>
            <ProfileScreen
              onLogout={handleLogout}
              onLogin={navigateToAuth}
              onMessage={handleOpenChat}
              onPrivacyPolicy={handlePrivacyPolicy}
              onTermsOfService={handleTermsOfService}
              onFollowersClick={handleFollowersClick}
              onAnalytics={() => { setPreviousScreen('profile'); setCurrentScreen('analytics'); }}
              onSettings={handleSettings}
            />
          </div>

          {/* Analytics */}
          <div className={`absolute inset-0 transition-opacity duration-200 ${currentScreen === 'analytics' ? 'opacity-100 z-20' : 'opacity-0 z-0 pointer-events-none'}`}>
            <AnalyticsScreen onBack={navigateBack} />
          </div>

          {/* Settings */}
          <div className={`absolute inset-0 transition-opacity duration-200 ${currentScreen === 'settings' ? 'opacity-100 z-20' : 'opacity-0 z-0 pointer-events-none'}`}>
            <SettingsScreen
              onBack={navigateBack}
              onEditProfile={() => {
                // Navigate back to profile and trigger edit mode
                setCurrentScreen('profile');
                setActiveTab('profile');
              }}
              onPrivacyPolicy={() => { setPreviousScreen('settings'); setCurrentScreen('privacy-policy'); }}
              onTermsOfService={() => { setPreviousScreen('settings'); setCurrentScreen('terms-of-service'); }}
              onLogout={handleLogout}
            />
          </div>

          {/* View Other Profile */}
          <div className={`absolute inset-0 transition-opacity duration-200 ${currentScreen === 'view-profile' ? 'opacity-100 z-10' : 'opacity-0 z-0 pointer-events-none'}`}>
            {viewProfileId && (
              <ProfileScreen
                userId={viewProfileId}
                onBack={navigateBack}
                onLogout={handleLogout}
                onLogin={navigateToAuth}
                onMessage={handleOpenChat}
                onPrivacyPolicy={handlePrivacyPolicy}
                onTermsOfService={handleTermsOfService}
                onFollowersClick={handleFollowersClick}
              />
            )}
          </div>

          {/* Followers/Following Screen */}
          <div className={`absolute inset-0 transition-opacity duration-200 ${currentScreen === 'followers-following' ? 'opacity-100 z-20' : 'opacity-0 z-0 pointer-events-none'}`}>
            {ffUserId && (
              <FollowersFollowingScreen
                userId={ffUserId}
                username={ffUsername}
                initialTab={ffInitialTab}
                onBack={navigateBack}
                onProfileClick={(uid) => {
                  // Navigate to profile from followers/following list
                  setPreviousScreen('followers-following');
                  setViewProfileId(uid);
                  setCurrentScreen('view-profile');
                }}
                onMessage={handleOpenChat}
              />
            )}
          </div>

          {/* Login */}
          <div className={`absolute inset-0 transition-opacity duration-200 ${currentScreen === 'login' ? 'opacity-100 z-20' : 'opacity-0 z-0 pointer-events-none'}`}>
            <LoginScreen
              onBack={navigateBack}
              onRegister={() => setCurrentScreen('register')}
              onForgotPassword={() => setCurrentScreen('forgot-password')}
              onPrivacyPolicy={() => { setPreviousScreen('login'); setCurrentScreen('privacy-policy'); }}
              onTermsOfService={() => { setPreviousScreen('login'); setCurrentScreen('terms-of-service'); }}
            />
          </div>


          {/* Register */}
          <div className={`absolute inset-0 transition-opacity duration-200 ${currentScreen === 'register' ? 'opacity-100 z-20' : 'opacity-0 z-0 pointer-events-none'}`}>
            <RegisterScreen
              onBack={navigateBack}
              onLogin={() => setCurrentScreen('login')}
              onPrivacyPolicy={() => { setPreviousScreen('register'); setCurrentScreen('privacy-policy'); }}
              onTermsOfService={() => { setPreviousScreen('register'); setCurrentScreen('terms-of-service'); }}
            />
          </div>

          {/* Forgot Password */}
          <div className={`absolute inset-0 transition-opacity duration-200 ${currentScreen === 'forgot-password' ? 'opacity-100 z-20' : 'opacity-0 z-0 pointer-events-none'}`}>
            <ForgotPasswordScreen onBack={() => setCurrentScreen('login')} />
          </div>

          {/* Privacy Policy */}
          <div className={`absolute inset-0 transition-opacity duration-200 ${currentScreen === 'privacy-policy' ? 'opacity-100 z-20' : 'opacity-0 z-0 pointer-events-none'}`}>
            <PrivacyPolicy onBack={navigateBack} />
          </div>

          {/* Terms of Service */}
          <div className={`absolute inset-0 transition-opacity duration-200 ${currentScreen === 'terms-of-service' ? 'opacity-100 z-20' : 'opacity-0 z-0 pointer-events-none'}`}>
            <TermsOfService
              onBack={navigateBack}
              onPrivacyPolicy={() => { setPreviousScreen('terms-of-service'); setCurrentScreen('privacy-policy'); }}
            />
          </div>
        </div>

        {/* Bottom Navigation */}
        {showBottomNav && (
          <BottomNav activeTab={activeTab} onTabChange={navigateToTab} isAuthenticated={isAuthenticated} />
        )}
      </div>
    </ErrorBoundary>
  );
};

export default AppLayout;
