import React, { Component, type ErrorInfo, type ReactNode } from 'react';
import { reportError } from '@/lib/errorReporting';
import { RefreshCw, AlertTriangle, Home } from 'lucide-react';

interface Props {
  children: ReactNode;
  fallback?: ReactNode;
  onReset?: () => void;
}

interface State {
  hasError: boolean;
  error: Error | null;
  errorInfo: ErrorInfo | null;
}

class ErrorBoundary extends Component<Props, State> {
  constructor(props: Props) {
    super(props);
    this.state = { hasError: false, error: null, errorInfo: null };
  }

  static getDerivedStateFromError(error: Error): Partial<State> {
    return { hasError: true, error };
  }

  componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    this.setState({ errorInfo });
    
    console.error('[ErrorBoundary] Caught error:', error, errorInfo);
    
    // Report to Sentry
    reportError(error, {
      component: 'ErrorBoundary',
      extra: {
        componentStack: errorInfo.componentStack,
      },
    });
  }

  handleReset = () => {
    this.setState({ hasError: false, error: null, errorInfo: null });
    this.props.onReset?.();
  };

  handleReload = () => {
    window.location.reload();
  };

  render() {
    if (this.state.hasError) {
      if (this.props.fallback) {
        return this.props.fallback;
      }

      return (
        <div className="h-screen w-full bg-black flex flex-col items-center justify-center px-8 text-center">
          {/* Error icon */}
          <div className="relative mb-6">
            <div className="w-20 h-20 rounded-full bg-red-500/10 flex items-center justify-center">
              <AlertTriangle className="w-10 h-10 text-red-400" />
            </div>
            <div className="absolute -inset-2 rounded-full bg-red-500/5 -z-10 animate-pulse" />
          </div>

          {/* Error message */}
          <h2 className="text-white text-xl font-bold mb-2">Something went wrong</h2>
          <p className="text-gray-500 text-sm mb-2 max-w-xs">
            WATZHMe encountered an unexpected error. The issue has been reported automatically.
          </p>
          
          {/* Error details (collapsed) */}
          {this.state.error && (
            <details className="mb-6 w-full max-w-sm">
              <summary className="text-gray-600 text-xs cursor-pointer hover:text-gray-400 transition-colors">
                View error details
              </summary>
              <div className="mt-2 p-3 bg-white/5 rounded-lg text-left overflow-auto max-h-32">
                <p className="text-red-400 text-xs font-mono break-all">
                  {this.state.error.message}
                </p>
              </div>
            </details>
          )}

          {/* Action buttons */}
          <div className="flex gap-3 w-full max-w-xs">
            <button
              onClick={this.handleReset}
              className="flex-1 py-3 bg-gradient-to-r from-emerald-500 to-cyan-500 text-white font-semibold rounded-xl flex items-center justify-center gap-2 hover:shadow-lg hover:shadow-emerald-500/20 transition-all active:scale-[0.98]"
            >
              <Home className="w-4 h-4" />
              Go Home
            </button>
            <button
              onClick={this.handleReload}
              className="flex-1 py-3 bg-white/10 text-white font-medium rounded-xl flex items-center justify-center gap-2 hover:bg-white/15 transition-colors active:scale-[0.98]"
            >
              <RefreshCw className="w-4 h-4" />
              Reload
            </button>
          </div>

          {/* Support info */}
          <div className="mt-8 text-center">
            <p className="text-gray-700 text-[10px]">
              If this keeps happening, contact us at
            </p>
            <a href="mailto:watzhme@gmail.com" className="text-emerald-500 text-xs hover:text-emerald-400 transition-colors">
              watzhme@gmail.com
            </a>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}

export default ErrorBoundary;
