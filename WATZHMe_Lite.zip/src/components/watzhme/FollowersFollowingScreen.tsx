import React, { useState, useEffect, useRef, useCallback } from 'react';
import { ArrowLeft, Search, X, UserPlus, UserCheck, Users, Sparkles, ChevronRight } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useAuthStore } from '@/stores/authStore';
import { useFeedStore } from '@/stores/feedStore';
import { useToast } from '@/hooks/use-toast';

interface FollowUser {
  id: string;
  username: string;
  full_name: string | null;
  avatar_url: string | null;
  bio: string | null;
  is_mutual: boolean;
}

interface FollowersFollowingScreenProps {
  userId: string;
  username: string;
  initialTab: 'followers' | 'following';
  onBack: () => void;
  onProfileClick: (userId: string) => void;
  onMessage?: (userId: string, username: string, avatarUrl: string | null) => void;
}

const FollowersFollowingScreen: React.FC<FollowersFollowingScreenProps> = ({
  userId,
  username,
  initialTab,
  onBack,
  onProfileClick,
  onMessage,
}) => {
  const { user, isAuthenticated } = useAuthStore();
  const { toggleFollow, followingUsers, fetchUserFollowing } = useFeedStore();
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState<'followers' | 'following' | 'suggested'>(initialTab);
  const [followers, setFollowers] = useState<FollowUser[]>([]);
  const [following, setFollowing] = useState<FollowUser[]>([]);
  const [suggested, setSuggested] = useState<FollowUser[]>([]);
  const [loadingFollowers, setLoadingFollowers] = useState(false);
  const [loadingFollowing, setLoadingFollowing] = useState(false);
  const [loadingSuggested, setLoadingSuggested] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [followingInProgress, setFollowingInProgress] = useState<Set<string>>(new Set());
  const searchInputRef = useRef<HTMLInputElement>(null);
  const isOwnProfile = userId === user?.id;

  useEffect(() => {
    loadFollowers();
    loadFollowing();
    if (isOwnProfile && isAuthenticated) {
      loadSuggested();
    }
  }, [userId]);

  const loadFollowers = useCallback(async () => {
    setLoadingFollowers(true);
    try {
      const { data: followRows, error } = await supabase
        .from('follows')
        .select('follower_id, created_at')
        .eq('following_id', userId)
        .order('created_at', { ascending: false })
        .limit(100);

      if (error || !followRows || followRows.length === 0) {
        setFollowers([]);
        setLoadingFollowers(false);
        return;
      }

      const followerIds = followRows.map((f: any) => f.follower_id);
      const { data: profiles } = await supabase
        .from('profiles')
        .select('id, username, full_name, avatar_url, bio')
        .in('id', followerIds);

      if (profiles) {
        let mutualSet = new Set<string>();
        if (user?.id) {
          const { data: mutuals } = await supabase
            .from('follows')
            .select('following_id')
            .eq('follower_id', userId)
            .in('following_id', followerIds);
          if (mutuals) {
            mutualSet = new Set(mutuals.map((m: any) => m.following_id));
          }
        }

        const sorted = followerIds
          .map(id => profiles.find((p: any) => p.id === id))
          .filter(Boolean)
          .map((p: any) => ({
            id: p.id,
            username: p.username,
            full_name: p.full_name,
            avatar_url: p.avatar_url,
            bio: p.bio,
            is_mutual: mutualSet.has(p.id),
          }));

        setFollowers(sorted);
      }
    } catch (err) {
      console.error('[Followers] Load error:', err);
    }
    setLoadingFollowers(false);
  }, [userId, user?.id]);

  const loadFollowing = useCallback(async () => {
    setLoadingFollowing(true);
    try {
      const { data: followRows, error } = await supabase
        .from('follows')
        .select('following_id, created_at')
        .eq('follower_id', userId)
        .order('created_at', { ascending: false })
        .limit(100);

      if (error || !followRows || followRows.length === 0) {
        setFollowing([]);
        setLoadingFollowing(false);
        return;
      }

      const followingIds = followRows.map((f: any) => f.following_id);
      const { data: profiles } = await supabase
        .from('profiles')
        .select('id, username, full_name, avatar_url, bio')
        .in('id', followingIds);

      if (profiles) {
        let followsBackSet = new Set<string>();
        const { data: followsBack } = await supabase
          .from('follows')
          .select('follower_id')
          .eq('following_id', userId)
          .in('follower_id', followingIds);
        if (followsBack) {
          followsBackSet = new Set(followsBack.map((f: any) => f.follower_id));
        }

        const sorted = followingIds
          .map(id => profiles.find((p: any) => p.id === id))
          .filter(Boolean)
          .map((p: any) => ({
            id: p.id,
            username: p.username,
            full_name: p.full_name,
            avatar_url: p.avatar_url,
            bio: p.bio,
            is_mutual: followsBackSet.has(p.id),
          }));

        setFollowing(sorted);
      }
    } catch (err) {
      console.error('[Following] Load error:', err);
    }
    setLoadingFollowing(false);
  }, [userId]);

  const loadSuggested = async () => {
    if (!user?.id) return;
    setLoadingSuggested(true);
    try {
      const { data: currentFollowing } = await supabase
        .from('follows')
        .select('following_id')
        .eq('follower_id', user.id);

      const followingIds = (currentFollowing || []).map((f: any) => f.following_id);
      followingIds.push(user.id);

      let query = supabase
        .from('profiles')
        .select('id, username, full_name, avatar_url, bio')
        .not('id', 'in', `(${followingIds.join(',')})`)
        .limit(20);

      const { data: profiles } = await query;

      if (profiles && profiles.length > 0) {
        const suggestedWithCounts = await Promise.all(
          profiles.map(async (p: any) => {
            const { count } = await supabase
              .from('follows')
              .select('id', { count: 'exact', head: true })
              .eq('following_id', p.id);

            const { count: mutualCount } = await supabase
              .from('follows')
              .select('id', { count: 'exact', head: true })
              .eq('following_id', p.id)
              .in('follower_id', followingIds.filter(id => id !== user.id));

            return {
              id: p.id,
              username: p.username,
              full_name: p.full_name,
              avatar_url: p.avatar_url,
              bio: p.bio,
              is_mutual: false,
              followers_count: count || 0,
              mutual_count: mutualCount || 0,
            };
          })
        );

        suggestedWithCounts.sort((a, b) => {
          if (b.mutual_count !== a.mutual_count) return b.mutual_count - a.mutual_count;
          return b.followers_count - a.followers_count;
        });

        setSuggested(suggestedWithCounts.slice(0, 15));
      }
    } catch (err) {
      console.error('[Suggested] Load error:', err);
    }
    setLoadingSuggested(false);
  };

  // === BUG 4 FIX: After follow/unfollow, refresh following set + reload both lists immediately ===
  const handleFollow = async (targetUserId: string) => {
    if (!isAuthenticated || !user?.id) return;

    setFollowingInProgress(prev => new Set(prev).add(targetUserId));

    const success = await toggleFollow(targetUserId, user.id);

    if (!success) {
      toast({
        title: 'Action failed',
        description: 'Could not complete the follow action. Please try again.',
        variant: 'destructive',
      });
    } else {
      // Refresh the current user's following set immediately
      await fetchUserFollowing(user.id);
    }

    setFollowingInProgress(prev => {
      const next = new Set(prev);
      next.delete(targetUserId);
      return next;
    });

    // Reload both lists to reflect changes immediately
    await Promise.all([loadFollowers(), loadFollowing()]);
  };

  const handleRemoveFollower = async (followerId: string) => {
    if (!user?.id || !isOwnProfile) return;
    try {
      await supabase
        .from('follows')
        .delete()
        .eq('follower_id', followerId)
        .eq('following_id', user.id);

      setFollowers(prev => prev.filter(f => f.id !== followerId));
    } catch (err) {
      console.error('[Followers] Remove error:', err);
      toast({
        title: 'Failed to remove follower',
        description: 'Something went wrong. Please try again.',
        variant: 'destructive',
      });
    }
  };

  // Filter by search
  const filterUsers = (users: FollowUser[]) => {
    if (!searchQuery.trim()) return users;
    const q = searchQuery.toLowerCase();
    return users.filter(
      u =>
        u.username.toLowerCase().includes(q) ||
        (u.full_name || '').toLowerCase().includes(q)
    );
  };

  const currentList = activeTab === 'followers' ? followers : activeTab === 'following' ? following : suggested;
  const filteredList = filterUsers(currentList);
  const isLoading = activeTab === 'followers' ? loadingFollowers : activeTab === 'following' ? loadingFollowing : loadingSuggested;

  return (
    <div className="h-full w-full bg-black flex flex-col">
      {/* Header */}
      <div className="flex items-center gap-3 px-3 py-3 border-b border-white/10 bg-black sticky top-0 z-10">
        <button onClick={onBack} className="p-1.5 hover:bg-white/10 rounded-full transition-colors">
          <ArrowLeft className="w-5 h-5 text-white" />
        </button>
        <div className="flex-1 min-w-0">
          <h2 className="text-white font-bold text-base truncate">@{username}</h2>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex border-b border-white/10 bg-black sticky top-12 z-10">
        <button
          onClick={() => setActiveTab('followers')}
          className={`flex-1 py-3 text-sm font-medium transition-colors relative ${
            activeTab === 'followers' ? 'text-white' : 'text-gray-500 hover:text-gray-300'
          }`}
        >
          <div className="flex items-center justify-center gap-1.5">
            <span>{followers.length}</span>
            <span className="text-xs">Followers</span>
          </div>
          {activeTab === 'followers' && (
            <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-12 h-0.5 bg-white rounded-full" />
          )}
        </button>
        <button
          onClick={() => setActiveTab('following')}
          className={`flex-1 py-3 text-sm font-medium transition-colors relative ${
            activeTab === 'following' ? 'text-white' : 'text-gray-500 hover:text-gray-300'
          }`}
        >
          <div className="flex items-center justify-center gap-1.5">
            <span>{following.length}</span>
            <span className="text-xs">Following</span>
          </div>
          {activeTab === 'following' && (
            <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-12 h-0.5 bg-white rounded-full" />
          )}
        </button>
        {isOwnProfile && (
          <button
            onClick={() => setActiveTab('suggested')}
            className={`flex-1 py-3 text-sm font-medium transition-colors relative ${
              activeTab === 'suggested' ? 'text-white' : 'text-gray-500 hover:text-gray-300'
            }`}
          >
            <div className="flex items-center justify-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5" />
              <span className="text-xs">Suggested</span>
            </div>
            {activeTab === 'suggested' && (
              <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-12 h-0.5 bg-emerald-500 rounded-full" />
            )}
          </button>
        )}
      </div>

      {/* Search bar */}
      <div className="px-4 py-3">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
          <input
            ref={searchInputRef}
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder={`Search ${activeTab}...`}
            className="w-full bg-white/5 border border-white/10 rounded-xl pl-10 pr-10 py-2.5 text-white text-sm placeholder-gray-600 outline-none focus:border-emerald-500/40 transition-all"
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="absolute right-3 top-1/2 -translate-y-1/2 p-0.5 hover:bg-white/10 rounded-full"
            >
              <X className="w-4 h-4 text-gray-400" />
            </button>
          )}
        </div>
      </div>

      {/* User list */}
      <div className="flex-1 overflow-y-auto pb-20 scrollbar-hide">
        {isLoading ? (
          <div className="flex items-center justify-center py-12">
            <div className="w-6 h-6 border-2 border-emerald-400 border-t-transparent rounded-full animate-spin" />
          </div>
        ) : filteredList.length === 0 ? (
          <EmptyState
            tab={activeTab}
            searchQuery={searchQuery}
            isOwnProfile={isOwnProfile}
            username={username}
          />
        ) : (
          <div className="px-2">
            {/* Mutual friends section header */}
            {activeTab === 'followers' && filteredList.some(u => u.is_mutual) && !searchQuery && (
              <div className="px-2 py-2 flex items-center gap-2">
                <Users className="w-3.5 h-3.5 text-emerald-400" />
                <span className="text-emerald-400 text-xs font-medium">Mutual follows shown first</span>
              </div>
            )}

            {/* Sort: mutuals first */}
            {[...filteredList]
              .sort((a, b) => {
                if (a.is_mutual && !b.is_mutual) return -1;
                if (!a.is_mutual && b.is_mutual) return 1;
                return 0;
              })
              .map((followUser) => (
                <UserListItem
                  key={followUser.id}
                  user={followUser}
                  isOwnProfile={isOwnProfile}
                  isFollowing={followingUsers.has(followUser.id)}
                  isCurrentUser={followUser.id === user?.id}
                  isFollowingInProgress={followingInProgress.has(followUser.id)}
                  activeTab={activeTab}
                  onFollow={() => handleFollow(followUser.id)}
                  onRemove={() => handleRemoveFollower(followUser.id)}
                  onProfileClick={() => onProfileClick(followUser.id)}
                  onMessage={onMessage ? () => onMessage(followUser.id, followUser.username, followUser.avatar_url) : undefined}
                />
              ))}
          </div>
        )}
      </div>
    </div>
  );
};

// Individual user list item
const UserListItem: React.FC<{
  user: FollowUser;
  isOwnProfile: boolean;
  isFollowing: boolean;
  isCurrentUser: boolean;
  isFollowingInProgress: boolean;
  activeTab: string;
  onFollow: () => void;
  onRemove: () => void;
  onProfileClick: () => void;
  onMessage?: () => void;
}> = ({
  user,
  isOwnProfile,
  isFollowing,
  isCurrentUser,
  isFollowingInProgress,
  activeTab,
  onFollow,
  onRemove,
  onProfileClick,
  onMessage,
}) => {
  const [showRemoveConfirm, setShowRemoveConfirm] = useState(false);

  return (
    <div className="flex items-center gap-3 px-2 py-2.5 rounded-xl hover:bg-white/5 transition-colors group">
      {/* Avatar */}
      <button onClick={onProfileClick} className="flex-shrink-0">
        <div className="w-12 h-12 rounded-full overflow-hidden bg-gray-800 ring-2 ring-transparent group-hover:ring-emerald-500/20 transition-all">
          {user.avatar_url ? (
            <img src={user.avatar_url} alt={user.username} className="w-full h-full object-cover" />
          ) : (
            <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-emerald-500 to-cyan-500 text-white font-bold text-lg">
              {user.username[0]?.toUpperCase()}
            </div>
          )}
        </div>
      </button>

      {/* User info */}
      <button onClick={onProfileClick} className="flex-1 min-w-0 text-left">
        <div className="flex items-center gap-1.5">
          <span className="text-white text-sm font-semibold truncate">@{user.username}</span>
          {user.is_mutual && (
            <span className="flex-shrink-0 px-1.5 py-0.5 bg-emerald-500/10 rounded-full">
              <span className="text-emerald-400 text-[9px] font-medium">Friends</span>
            </span>
          )}
        </div>
        {user.full_name && (
          <p className="text-gray-400 text-xs truncate mt-0.5">{user.full_name}</p>
        )}
        {user.bio && (
          <p className="text-gray-600 text-xs truncate mt-0.5 max-w-[200px]">{user.bio}</p>
        )}
      </button>

      {/* Action buttons */}
      <div className="flex items-center gap-2 flex-shrink-0">
        {!isCurrentUser && (
          <>
            {isFollowing ? (
              <button
                onClick={onFollow}
                disabled={isFollowingInProgress}
                className="px-4 py-1.5 bg-white/10 text-gray-300 text-xs font-semibold rounded-lg hover:bg-white/15 transition-all active:scale-95 disabled:opacity-50 flex items-center gap-1.5"
              >
                {isFollowingInProgress ? (
                  <div className="w-3 h-3 border-2 border-gray-400 border-t-transparent rounded-full animate-spin" />
                ) : (
                  <UserCheck className="w-3.5 h-3.5" />
                )}
                Following
              </button>
            ) : (
              <button
                onClick={onFollow}
                disabled={isFollowingInProgress}
                className="px-4 py-1.5 bg-emerald-500 text-white text-xs font-semibold rounded-lg hover:bg-emerald-400 transition-all active:scale-95 disabled:opacity-50 flex items-center gap-1.5"
              >
                {isFollowingInProgress ? (
                  <div className="w-3 h-3 border-2 border-white border-t-transparent rounded-full animate-spin" />
                ) : (
                  <UserPlus className="w-3.5 h-3.5" />
                )}
                Follow
              </button>
            )}
          </>
        )}

        {/* Remove follower button */}
        {isOwnProfile && activeTab === 'followers' && !isCurrentUser && (
          <>
            {showRemoveConfirm ? (
              <div className="flex items-center gap-1">
                <button
                  onClick={() => { onRemove(); setShowRemoveConfirm(false); }}
                  className="px-2 py-1 bg-red-500/20 text-red-400 text-[10px] font-medium rounded-md hover:bg-red-500/30 transition-colors"
                >
                  Remove
                </button>
                <button
                  onClick={() => setShowRemoveConfirm(false)}
                  className="px-2 py-1 bg-white/5 text-gray-400 text-[10px] font-medium rounded-md hover:bg-white/10 transition-colors"
                >
                  Cancel
                </button>
              </div>
            ) : (
              <button
                onClick={() => setShowRemoveConfirm(true)}
                className="p-1.5 hover:bg-white/10 rounded-full transition-colors opacity-0 group-hover:opacity-100"
                title="Remove follower"
              >
                <X className="w-3.5 h-3.5 text-gray-500" />
              </button>
            )}
          </>
        )}
      </div>
    </div>
  );
};

// Empty state component
const EmptyState: React.FC<{
  tab: string;
  searchQuery: string;
  isOwnProfile: boolean;
  username: string;
}> = ({ tab, searchQuery, isOwnProfile, username }) => {
  if (searchQuery) {
    return (
      <div className="flex flex-col items-center justify-center py-16 text-center px-8">
        <Search className="w-10 h-10 text-gray-700 mb-3" />
        <p className="text-gray-500 text-sm">No results for "{searchQuery}"</p>
      </div>
    );
  }

  const configs = {
    followers: {
      icon: Users,
      title: isOwnProfile ? 'No followers yet' : `@${username} has no followers yet`,
      subtitle: isOwnProfile
        ? 'Share your profile to get more followers'
        : 'Be the first to follow!',
    },
    following: {
      icon: UserPlus,
      title: isOwnProfile ? "You're not following anyone" : `@${username} isn't following anyone`,
      subtitle: isOwnProfile
        ? 'Discover people to follow on the Search tab'
        : '',
    },
    suggested: {
      icon: Sparkles,
      title: 'No suggestions right now',
      subtitle: 'Check back later for new people to follow',
    },
  };

  const config = configs[tab as keyof typeof configs] || configs.followers;
  const Icon = config.icon;

  return (
    <div className="flex flex-col items-center justify-center py-16 text-center px-8">
      <div className="w-16 h-16 rounded-full bg-gradient-to-br from-emerald-500/10 to-cyan-500/10 flex items-center justify-center mb-4">
        <Icon className="w-7 h-7 text-emerald-400/60" />
      </div>
      <h3 className="text-white text-base font-semibold mb-1">{config.title}</h3>
      {config.subtitle && (
        <p className="text-gray-500 text-sm">{config.subtitle}</p>
      )}
    </div>
  );
};

export default FollowersFollowingScreen;
