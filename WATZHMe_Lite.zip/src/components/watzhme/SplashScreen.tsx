import React from 'react';

const SplashScreen: React.FC = () => {
  return (
    <div className="h-screen w-full bg-black flex flex-col items-center justify-center relative overflow-hidden">
      {/* Background gradient effects */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-1/4 left-1/4 w-64 h-64 bg-emerald-500/8 rounded-full blur-3xl animate-pulse" />
        <div className="absolute bottom-1/4 right-1/4 w-64 h-64 bg-cyan-500/8 rounded-full blur-3xl animate-pulse" style={{ animationDelay: '1s' }} />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-emerald-500/3 rounded-full blur-3xl" />
      </div>

      {/* Logo */}
      <div className="relative mb-6 animate-[scaleIn_0.5s_ease-out]">
        <div className="w-24 h-24 rounded-3xl overflow-hidden shadow-2xl shadow-emerald-500/20 ring-1 ring-white/10">
          <div className="w-full h-full bg-gradient-to-br from-emerald-500 to-cyan-500 flex items-center justify-center">
            <span className="text-black text-4xl font-black tracking-tighter">W</span>
          </div>
        </div>
        <div className="absolute -inset-3 rounded-3xl bg-gradient-to-br from-emerald-500/20 to-cyan-500/20 -z-10 blur-xl animate-pulse" />
      </div>

      {/* App name */}
      <h1 className="text-white text-3xl font-extrabold tracking-tight mb-1 animate-[fadeIn_0.5s_ease-out_0.2s_both]">
        WATZH<span className="text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 to-cyan-400">Me</span>
      </h1>
      <p className="text-gray-500 text-sm tracking-widest uppercase animate-[fadeIn_0.5s_ease-out_0.4s_both]">Share Every Moment</p>

      {/* Version badge */}
      <div className="mt-3 px-3 py-1 bg-white/5 rounded-full animate-[fadeIn_0.5s_ease-out_0.6s_both] ring-1 ring-white/5">
        <span className="text-gray-600 text-[10px] font-medium">Lite v1.0.0</span>
      </div>

      {/* Loading spinner */}
      <div className="mt-12 animate-[fadeIn_0.5s_ease-out_0.8s_both]">
        <div className="w-8 h-8 border-2 border-emerald-500/30 border-t-emerald-400 rounded-full animate-spin" />
      </div>

      {/* Footer */}
      <div className="absolute bottom-8 text-center animate-[fadeIn_0.5s_ease-out_1s_both]">
        <p className="text-gray-700 text-[10px]">Kimberley, Northern Cape, South Africa</p>
        <p className="text-gray-800 text-[9px] mt-1">Copyright 2026 WATZHMe</p>
      </div>
    </div>
  );
};

export default SplashScreen;
