import React, { useState } from 'react';
import { ArrowLeft, FileText, ChevronDown, ChevronUp, Scale, AlertTriangle, Ban, Shield, Users, Globe, Gavel } from 'lucide-react';

interface TermsOfServiceProps {
  onBack: () => void;
  onPrivacyPolicy?: () => void;
}

interface SectionProps {
  title: string;
  icon: React.ReactNode;
  children: React.ReactNode;
  defaultOpen?: boolean;
}

const Section: React.FC<SectionProps> = ({ title, icon, children, defaultOpen = false }) => {
  const [isOpen, setIsOpen] = useState(defaultOpen);
  return (
    <div className="border border-white/5 rounded-xl overflow-hidden">
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="w-full flex items-center gap-3 px-4 py-3.5 hover:bg-white/5 transition-colors text-left"
      >
        <div className="w-8 h-8 rounded-lg bg-cyan-500/10 flex items-center justify-center flex-shrink-0">
          {icon}
        </div>
        <span className="text-white font-semibold text-sm flex-1">{title}</span>
        {isOpen ? <ChevronUp className="w-4 h-4 text-gray-500" /> : <ChevronDown className="w-4 h-4 text-gray-500" />}
      </button>
      {isOpen && (
        <div className="px-4 pb-4 pt-1 text-gray-300 text-sm leading-relaxed space-y-3 border-t border-white/5">
          {children}
        </div>
      )}
    </div>
  );
};

const TermsOfService: React.FC<TermsOfServiceProps> = ({ onBack, onPrivacyPolicy }) => {
  return (
    <div className="h-full w-full bg-black flex flex-col overflow-y-auto scrollbar-hide">
      {/* Header */}
      <div className="flex items-center gap-3 px-4 py-3 sticky top-0 bg-black/95 backdrop-blur-sm z-10 border-b border-white/10">
        <button onClick={onBack} className="p-1 hover:bg-white/10 rounded-full transition-colors">
          <ArrowLeft className="w-5 h-5 text-white" />
        </button>
        <h2 className="text-white font-bold text-base">Terms of Service</h2>
      </div>

      <div className="px-4 py-5 pb-24 space-y-4">
        {/* Header card */}
        <div className="bg-gradient-to-br from-cyan-500/10 to-purple-500/10 rounded-2xl p-5 border border-cyan-500/20">
          <div className="flex items-center gap-3 mb-2">
            <div className="w-12 h-12 rounded-xl bg-cyan-500/20 flex items-center justify-center">
              <Scale className="w-6 h-6 text-cyan-400" />
            </div>
            <div>
              <h1 className="text-white font-bold text-lg">Terms of Service</h1>
              <p className="text-gray-400 text-xs">Effective: February 11, 2026</p>
            </div>
          </div>
          <p className="text-gray-400 text-sm mt-2">
            By using WATZHMe Lite, you agree to these terms. Please read them carefully.
          </p>
        </div>

        <div className="space-y-2">
          <Section
            title="1. Acceptance of Terms"
            icon={<FileText className="w-4 h-4 text-cyan-400" />}
            defaultOpen={true}
          >
            <p>
              By accessing or using WATZHMe Lite ("the Service"), you agree to be bound by these 
              Terms of Service ("Terms"). If you do not agree to these Terms, you may not use the Service.
            </p>
            <p>
              WATZHMe Lite is operated from Kimberley, Northern Cape, South Africa. These Terms are 
              governed by the laws of the Republic of South Africa.
            </p>
          </Section>

          <Section
            title="2. Eligibility"
            icon={<Users className="w-4 h-4 text-cyan-400" />}
          >
            <p>To use WATZHMe, you must:</p>
            <ul className="list-disc list-inside space-y-1 text-gray-400 ml-2">
              <li>Be at least 13 years of age</li>
              <li>If between 13-18, have parental or guardian consent</li>
              <li>Not be prohibited from using the Service under applicable law</li>
              <li>Provide accurate and complete registration information</li>
            </ul>
          </Section>

          <Section
            title="3. Your Account"
            icon={<Shield className="w-4 h-4 text-cyan-400" />}
          >
            <p>When you create an account, you are responsible for:</p>
            <ul className="list-disc list-inside space-y-1 text-gray-400 ml-2">
              <li>Maintaining the security of your password and account</li>
              <li>All activities that occur under your account</li>
              <li>Notifying us immediately of any unauthorized access</li>
              <li>Keeping your account information accurate and up-to-date</li>
            </ul>
            <p>
              We reserve the right to suspend or terminate accounts that violate these Terms or 
              that have been inactive for more than 12 months.
            </p>
          </Section>

          <Section
            title="4. Content & Conduct"
            icon={<AlertTriangle className="w-4 h-4 text-cyan-400" />}
          >
            <p className="font-medium text-white text-xs uppercase tracking-wider mb-2">Your Content</p>
            <p>
              You retain ownership of content you post on WATZHMe. By posting content, you grant us 
              a non-exclusive, worldwide, royalty-free license to use, display, and distribute your 
              content within the Service.
            </p>
            <p className="font-medium text-white text-xs uppercase tracking-wider mb-2 mt-3">Content Standards</p>
            <p>WATZHMe is an open platform with minimal content restrictions. However, the following is prohibited:</p>
            <ul className="list-disc list-inside space-y-1 text-gray-400 ml-2">
              <li>Content that exploits or endangers minors (CSAM)</li>
              <li>Content that promotes terrorism or extreme violence</li>
              <li>Spam, malware, or phishing attempts</li>
              <li>Impersonation of other users or public figures</li>
              <li>Content that violates South African law</li>
            </ul>
            <p className="text-gray-400 text-xs mt-2">
              All other content is permitted. Users are responsible for their own content and should 
              use discretion when viewing content from others.
            </p>
          </Section>

          <Section
            title="5. Prohibited Activities"
            icon={<Ban className="w-4 h-4 text-cyan-400" />}
          >
            <p>You agree not to:</p>
            <ul className="list-disc list-inside space-y-1 text-gray-400 ml-2">
              <li>Use the Service for any illegal purpose</li>
              <li>Attempt to gain unauthorized access to other accounts or systems</li>
              <li>Use automated tools (bots, scrapers) without permission</li>
              <li>Interfere with or disrupt the Service</li>
              <li>Collect user data without consent</li>
              <li>Upload viruses or malicious code</li>
              <li>Harass, bully, or threaten other users</li>
              <li>Create multiple accounts to evade bans</li>
            </ul>
          </Section>

          <Section
            title="6. Intellectual Property"
            icon={<Globe className="w-4 h-4 text-cyan-400" />}
          >
            <p>
              The WATZHMe name, logo, and app design are the intellectual property of WATZHMe. 
              You may not use our branding without written permission.
            </p>
            <p>
              If you believe content on WATZHMe infringes your intellectual property rights, 
              please contact us at{' '}
              <a href="mailto:watzhme@gmail.com" className="text-cyan-400 hover:underline">watzhme@gmail.com</a>{' '}
              with details of the alleged infringement.
            </p>
          </Section>

          <Section
            title="7. Disclaimers & Limitations"
            icon={<AlertTriangle className="w-4 h-4 text-cyan-400" />}
          >
            <p>
              THE SERVICE IS PROVIDED "AS IS" AND "AS AVAILABLE" WITHOUT WARRANTIES OF ANY KIND, 
              EITHER EXPRESS OR IMPLIED.
            </p>
            <ul className="list-disc list-inside space-y-1 text-gray-400 ml-2">
              <li>We do not guarantee uninterrupted or error-free service</li>
              <li>We are not responsible for user-generated content</li>
              <li>We are not liable for any indirect, incidental, or consequential damages</li>
              <li>Our total liability is limited to the amount you paid us (which is R0 for free users)</li>
            </ul>
          </Section>

          <Section
            title="8. Termination"
            icon={<Ban className="w-4 h-4 text-cyan-400" />}
          >
            <p>
              You may delete your account at any time by contacting us at{' '}
              <a href="mailto:watzhme@gmail.com" className="text-cyan-400 hover:underline">watzhme@gmail.com</a>.
            </p>
            <p>
              We may suspend or terminate your account if you violate these Terms, with or without 
              notice. Upon termination, your right to use the Service ceases immediately, and we may 
              delete your content within 30 days.
            </p>
          </Section>

          <Section
            title="9. Governing Law & Disputes"
            icon={<Gavel className="w-4 h-4 text-cyan-400" />}
          >
            <p>
              These Terms are governed by the laws of the Republic of South Africa. Any disputes 
              arising from these Terms or the Service shall be resolved in the courts of the 
              Northern Cape Division, Kimberley.
            </p>
            <p>
              Before initiating legal proceedings, you agree to first attempt to resolve the dispute 
              informally by contacting us at{' '}
              <a href="mailto:watzhme@gmail.com" className="text-cyan-400 hover:underline">watzhme@gmail.com</a>.
            </p>
          </Section>

          <Section
            title="10. Changes to Terms"
            icon={<FileText className="w-4 h-4 text-cyan-400" />}
          >
            <p>
              We may modify these Terms at any time. Material changes will be communicated via 
              in-app notification or email. Continued use of the Service after changes constitutes 
              acceptance of the updated Terms.
            </p>
          </Section>
        </div>

        {/* Privacy Policy link */}
        {onPrivacyPolicy && (
          <button
            onClick={onPrivacyPolicy}
            className="w-full py-3.5 bg-white/5 rounded-xl text-emerald-400 text-sm font-medium hover:bg-white/10 transition-colors flex items-center justify-center gap-2"
          >
            <Shield className="w-4 h-4" />
            View Privacy Policy
          </button>
        )}

        {/* Footer */}
        <div className="text-center py-4">
          <p className="text-gray-700 text-[10px]">
            WATZHMe Lite v1.0.0 | Terms of Service v1.0
          </p>
          <p className="text-gray-700 text-[10px] mt-0.5">
            Copyright 2026 WATZHMe. All rights reserved.
          </p>
        </div>
      </div>
    </div>
  );
};

export default TermsOfService;
