import React, { useState, useEffect, useRef, useCallback } from 'react';
import { Settings, Grid3x3, Bookmark, Heart, Edit3, Camera, ArrowLeft, MessageCircle, Share2, X, Check, UserPlus, Users, ChevronRight, BarChart3, MoreVertical, Trash2, AlertTriangle } from 'lucide-react';


import { supabase } from '@/lib/supabase';
import { useAuthStore, type Profile } from '@/stores/authStore';
import { useFeedStore, type Post } from '@/stores/feedStore';
import { useToast } from '@/hooks/use-toast';

interface ProfileScreenProps {
  userId?: string;
  onBack?: () => void;
  onPostClick?: (post: Post) => void;
  onLogout: () => void;
  onLogin: () => void;
  onMessage?: (userId: string, username: string, avatarUrl: string | null) => void;
  onPrivacyPolicy?: () => void;
  onTermsOfService?: () => void;
  onFollowersClick?: (userId: string, username: string, tab: 'followers' | 'following') => void;
  onAnalytics?: () => void;
  onSettings?: () => void;
}

const ProfileScreen: React.FC<ProfileScreenProps> = ({ userId, onBack, onPostClick, onLogout, onLogin, onMessage, onPrivacyPolicy, onTermsOfService, onFollowersClick, onAnalytics, onSettings }) => {

  const { user, profile: myProfile, isAuthenticated, updateProfile, fetchProfile } = useAuthStore();
  const { toggleFollow, followingUsers, getFollowCounts, bookmarkedPosts, fetchUserFollowing, deletePost } = useFeedStore();

  const { toast } = useToast();
  const [viewProfile, setViewProfile] = useState<Profile | null>(null);
  const [posts, setPosts] = useState<Post[]>([]);
  const [likedPosts, setLikedPosts] = useState<Post[]>([]);
  const [savedPosts, setSavedPosts] = useState<Post[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<'posts' | 'liked' | 'saved'>('posts');
  const [editing, setEditing] = useState(false);
  const [editBio, setEditBio] = useState('');
  const [editFullName, setEditFullName] = useState('');
  const [editUsername, setEditUsername] = useState('');
  const [uploadingAvatar, setUploadingAvatar] = useState(false);
  const [followCounts, setFollowCounts] = useState({ followers_count: 0, following_count: 0 });
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [isFollowAnimating, setIsFollowAnimating] = useState(false);
  // === POST DELETE STATE ===
  const [deletePostTarget, setDeletePostTarget] = useState<Post | null>(null);
  const [isDeletingPost, setIsDeletingPost] = useState(false);
  const [postMenuOpen, setPostMenuOpen] = useState<string | null>(null);

  const avatarInputRef = useRef<HTMLInputElement>(null);
  const followsChannelRef = useRef<any>(null);

  const isOwnProfile = !userId || userId === user?.id;
  const displayProfile = isOwnProfile ? myProfile : viewProfile;
  const isFollowingUser = userId ? followingUsers.has(userId) : false;
  const targetUserId = userId || user?.id;

  useEffect(() => {
    loadProfile();
    loadPosts();
    loadFollowCounts();
    subscribeToFollows();

    return () => {
      unsubscribeFromFollows();
    };
  }, [userId, user?.id]);

  // Refresh follow counts when followingUsers changes
  useEffect(() => {
    if (targetUserId) {
      loadFollowCounts();
    }
  }, [followingUsers.size]);

  // === REALTIME: Subscribe to follows table changes for this profile ===
  const subscribeToFollows = () => {
    unsubscribeFromFollows();
    if (!targetUserId) return;

    try {
      const channel = supabase
        .channel(`follows-profile-${targetUserId}-${Date.now()}`)
        .on(
          'postgres_changes',
          {
            event: '*',
            schema: 'public',
            table: 'follows',
          },
          (payload: any) => {
            const row = payload.new || payload.old;
            if (row?.follower_id === targetUserId || row?.following_id === targetUserId ||
                row?.follower_id === user?.id || row?.following_id === user?.id) {
              console.log('[Profile] Realtime follows change, refreshing counts');
              loadFollowCounts();
            }
          }
        )
        .subscribe();

      followsChannelRef.current = channel;
    } catch (err) {
      console.error('[Profile] Subscribe to follows error:', err);
    }
  };

  const unsubscribeFromFollows = () => {
    if (followsChannelRef.current) {
      try {
        supabase.removeChannel(followsChannelRef.current);
      } catch (err) {
        console.error('[Profile] Unsubscribe follows error:', err);
      }
      followsChannelRef.current = null;
    }
  };

  const loadProfile = async () => {
    if (isOwnProfile) return;
    try {
      const { data } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', userId)
        .single();
      if (data) setViewProfile(data as Profile);
    } catch (err) {
      console.error('Load profile error:', err);
    }
  };

  const loadPosts = async () => {
    setLoading(true);
    const targetId = userId || user?.id;
    if (!targetId) { setLoading(false); return; }
    try {
      const { data } = await supabase
        .from('posts')
        .select('*, profiles(id, username, avatar_url, full_name)')
        .eq('user_id', targetId)
        .order('created_at', { ascending: false });
      if (data) setPosts(data as Post[]);
    } catch (err) {
      console.error('Load posts error:', err);
    }
    setLoading(false);
  };

  const loadFollowCounts = useCallback(async () => {
    const targetId = userId || user?.id;
    if (!targetId) return;
    try {
      const counts = await getFollowCounts(targetId);
      console.log('[Profile] Follow counts loaded:', counts);
      setFollowCounts(counts);
    } catch (err) {
      console.error('[Profile] Load follow counts error:', err);
    }
  }, [userId, user?.id, getFollowCounts]);

  const loadLikedPosts = async () => {
    const targetId = userId || user?.id;
    if (!targetId) return;
    try {
      const { data: likes } = await supabase
        .from('likes')
        .select('post_id')
        .eq('user_id', targetId)
        .order('created_at', { ascending: false })
        .limit(50);
      if (likes && likes.length > 0) {
        const postIds = likes.map((l: any) => l.post_id);
        const { data: postsData } = await supabase
          .from('posts')
          .select('*, profiles(id, username, avatar_url, full_name)')
          .in('id', postIds);
        if (postsData) {
          const sorted = postIds.map(id => postsData.find((p: any) => p.id === id)).filter(Boolean) as Post[];
          setLikedPosts(sorted);
        }
      }
    } catch (err) {
      console.error('Load liked posts error:', err);
    }
  };

  const loadSavedPosts = async () => {
    if (!user?.id || !isOwnProfile) return;
    try {
      const { data: bookmarks } = await supabase
        .from('bookmarks')
        .select('post_id')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false })
        .limit(50);
      if (bookmarks && bookmarks.length > 0) {
        const postIds = bookmarks.map((b: any) => b.post_id);
        const { data: postsData } = await supabase
          .from('posts')
          .select('*, profiles(id, username, avatar_url, full_name)')
          .in('id', postIds);
        if (postsData) {
          const sorted = postIds.map(id => postsData.find((p: any) => p.id === id)).filter(Boolean) as Post[];
          setSavedPosts(sorted);
        }
      }
    } catch (err) {
      console.error('Load saved posts error:', err);
    }
  };

  useEffect(() => {
    if (activeTab === 'liked') loadLikedPosts();
    if (activeTab === 'saved') loadSavedPosts();
  }, [activeTab]);

  const handleAvatarUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !user) return;
    setUploadingAvatar(true);
    try {
      const ext = file.name.split('.').pop() || 'jpg';
      const fileName = `${user.id}/avatar_${Date.now()}.${ext}`;
      const { error: uploadError } = await supabase.storage
        .from('avatars')
        .upload(fileName, file, { cacheControl: '3600', upsert: true, contentType: file.type });
      if (uploadError) { console.error('Avatar upload error:', uploadError); setUploadingAvatar(false); return; }
      const { data: urlData } = supabase.storage.from('avatars').getPublicUrl(fileName);
      await updateProfile({ avatar_url: urlData.publicUrl });
    } catch (err) {
      console.error('Avatar upload error:', err);
    }
    setUploadingAvatar(false);
  };

  const handleSaveProfile = async () => {
    const updates: Partial<Profile> = { bio: editBio, full_name: editFullName };
    if (editUsername && editUsername !== displayProfile?.username) {
      updates.username = editUsername.toLowerCase().replace(/[^a-z0-9_]/g, '');
    }
    const success = await updateProfile(updates);
    if (success) setEditing(false);
  };

  const startEditing = () => {
    setEditBio(displayProfile?.bio || '');
    setEditFullName(displayProfile?.full_name || '');
    setEditUsername(displayProfile?.username || '');
    setEditing(true);
  };

  // === BUG 4 FIX: More robust follow with immediate count refresh ===
  const handleFollow = async () => {
    if (!isAuthenticated || !user?.id || !userId) {
      console.warn('[Profile] Cannot follow: not authenticated or missing IDs');
      return;
    }
    setIsFollowAnimating(true);

    // === OPTIMISTIC COUNT UPDATE ===
    const wasFollowing = followingUsers.has(userId);
    setFollowCounts(prev => ({
      followers_count: Math.max(0, prev.followers_count + (wasFollowing ? -1 : 1)),
      following_count: prev.following_count,
    }));

    const success = await toggleFollow(userId, user.id);

    if (!success) {
      // Revert optimistic update on failure
      setFollowCounts(prev => ({
        followers_count: Math.max(0, prev.followers_count + (wasFollowing ? 1 : -1)),
        following_count: prev.following_count,
      }));
      toast({
        title: 'Action failed',
        description: wasFollowing ? 'Could not unfollow. Try again.' : 'Could not follow. Try again.',
        variant: 'destructive',
      });
      setIsFollowAnimating(false);
      return;
    }

    // Refresh the current user's following set immediately
    if (user?.id) {
      await fetchUserFollowing(user.id);
    }

    // Refresh actual counts from server immediately
    await loadFollowCounts();

    // And again after a short delay to catch any propagation lag
    setTimeout(async () => {
      await loadFollowCounts();
      setIsFollowAnimating(false);
    }, 800);
  };

  const handleMessage = () => {
    if (!displayProfile || !onMessage) return;
    onMessage(displayProfile.id, displayProfile.username, displayProfile.avatar_url);
  };

  const handleShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: `@${displayProfile?.username} on WATZHMe`,
          text: displayProfile?.bio || 'Check out this profile on WATZHMe!',
          url: window.location.href,
        });
      } catch {}
    }
  };

  const handleDeleteAccount = async () => {
    console.log('[Profile] Delete account requested');
    setShowDeleteConfirm(false);
    alert('To delete your account and all data, please email watzhme@gmail.com with your username. We will process your request within 30 days as required by POPIA.');
    onLogout();
  };

  const handleFollowersClick = (tab: 'followers' | 'following') => {
    if (!displayProfile || !targetUserId) return;
    if (onFollowersClick) {
      onFollowersClick(targetUserId, displayProfile.username, tab);
    }
  };

  const formatCount = (n: number): string => {
    if (n >= 1000000) return (n / 1000000).toFixed(1) + 'M';
    if (n >= 10000) return (n / 1000).toFixed(0) + 'K';
    if (n >= 1000) return (n / 1000).toFixed(1) + 'K';
    return n.toString();

  };

  // === POST DELETE HANDLER ===
  const handleDeletePostConfirm = async () => {
    if (!deletePostTarget || !user?.id) return;
    setIsDeletingPost(true);
    console.log('[Profile] Deleting post:', deletePostTarget.id);

    const success = await deletePost(deletePostTarget.id, user.id, deletePostTarget.media_url);

    if (success) {
      // Remove from local posts list (optimistic)
      setPosts(prev => prev.filter(p => p.id !== deletePostTarget.id));
      toast({ title: 'Post deleted', description: 'Your post has been removed.' });
    } else {
      toast({
        title: 'Failed to delete post',
        description: 'Something went wrong. Please try again.',
        variant: 'destructive',
      });
    }

    setIsDeletingPost(false);
    setDeletePostTarget(null);
    setPostMenuOpen(null);
  };


  // Not authenticated - show login prompt
  if (!isAuthenticated && isOwnProfile) {
    return (
      <div className="h-full w-full bg-black flex flex-col items-center justify-center px-8 text-center">
        <div className="relative mb-6">
          <div className="w-24 h-24 rounded-3xl overflow-hidden shadow-2xl shadow-emerald-500/20 ring-1 ring-white/10">
            <div className="w-full h-full bg-gradient-to-br from-emerald-500 to-cyan-500 flex items-center justify-center">
              <span className="text-black text-4xl font-black">W</span>
            </div>
          </div>
        </div>
        <h2 className="text-white text-xl font-bold mb-2">Join WATZHMe</h2>
        <p className="text-gray-500 text-sm mb-8 max-w-xs">
          Create an account to share moments, follow creators, and connect with the world.
        </p>
        <button
          onClick={onLogin}
          className="w-full max-w-xs py-3.5 bg-gradient-to-r from-emerald-500 to-cyan-500 text-white font-semibold rounded-xl hover:shadow-lg hover:shadow-emerald-500/20 transition-all active:scale-[0.98]"
        >
          Sign In
        </button>
        <button
          onClick={onLogin}
          className="w-full max-w-xs py-3.5 mt-3 bg-white/10 text-white font-medium rounded-xl hover:bg-white/15 transition-colors"
        >
          Create Account
        </button>
      </div>
    );
  }

  if (!displayProfile) {
    return (
      <div className="h-full w-full bg-black flex items-center justify-center">
        <div className="w-8 h-8 border-2 border-emerald-400 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  const displayPosts = activeTab === 'posts' ? posts : activeTab === 'liked' ? likedPosts : savedPosts;

  return (
    <div className="h-full w-full bg-black flex flex-col overflow-y-auto scrollbar-hide">
      {/* Header */}
      <div className="flex items-center justify-between px-4 py-3 sticky top-0 bg-black/90 backdrop-blur-sm z-10">
        <div className="flex items-center gap-3">
          {onBack && !isOwnProfile && (
            <button onClick={onBack} className="p-1 hover:bg-white/10 rounded-full transition-colors">
              <ArrowLeft className="w-5 h-5 text-white" />
            </button>
          )}
          <h2 className="text-white font-bold text-base">@{displayProfile.username}</h2>
          {!isOwnProfile && isFollowingUser && (
            <span className="px-2 py-0.5 bg-emerald-500/10 rounded-full text-[10px] text-emerald-400 font-medium">Following</span>
          )}
        </div>
        <div className="flex items-center gap-1">
          {!isOwnProfile && (
            <button onClick={handleShare} className="p-2 hover:bg-white/10 rounded-full transition-colors">
              <Share2 className="w-5 h-5 text-gray-400" />
            </button>
          )}
          {/* === BUG 3 FIX: Settings button — direct onSettings call, no intermediate wrapper === */}
          {isOwnProfile && (
            <button
              type="button"
              onClick={(e) => {
                e.preventDefault();
                e.stopPropagation();
                console.log('[Profile] Settings icon clicked');
                if (onSettings) {
                  console.log('[Profile] Calling onSettings()');
                  onSettings();
                } else {
                  console.warn('[Profile] onSettings prop is undefined!');
                  toast({
                    title: 'Settings',
                    description: 'Settings screen is not available.',
                  });
                }
              }}
              className="p-2 hover:bg-white/10 rounded-full transition-colors active:scale-90 active:bg-white/20"
              aria-label="Settings"
            >
              <Settings className="w-5 h-5 text-gray-400" />
            </button>
          )}
        </div>
      </div>

      {/* Delete account confirmation */}
      {showDeleteConfirm && (
        <div className="mx-4 mb-3 bg-red-500/5 rounded-xl border border-red-500/20 p-4">
          <p className="text-white text-sm font-semibold mb-2">Delete your account?</p>
          <p className="text-gray-400 text-xs mb-4 leading-relaxed">
            This will permanently delete your account, posts, comments, and all associated data.
            This action cannot be undone. As per POPIA, your data will be removed within 30 days.
          </p>
          <div className="flex gap-2">
            <button
              onClick={handleDeleteAccount}
              className="flex-1 py-2.5 bg-red-500 text-white text-sm font-medium rounded-lg hover:bg-red-600 transition-colors"
            >
              Delete Account
            </button>
            <button
              onClick={() => setShowDeleteConfirm(false)}
              className="flex-1 py-2.5 bg-white/10 text-white text-sm font-medium rounded-lg hover:bg-white/15 transition-colors"
            >
              Cancel
            </button>
          </div>
        </div>
      )}

      {/* Profile info */}
      <div className="px-6 pt-2 pb-4">
        <div className="flex items-center gap-6 mb-4">
          {/* Avatar */}
          <div className="relative">
            <div className="w-20 h-20 rounded-full overflow-hidden border-2 border-emerald-500/30 bg-gray-800">
              {uploadingAvatar ? (
                <div className="w-full h-full flex items-center justify-center bg-gray-900">
                  <div className="w-6 h-6 border-2 border-emerald-400 border-t-transparent rounded-full animate-spin" />
                </div>
              ) : displayProfile.avatar_url ? (
                <img src={displayProfile.avatar_url} alt={displayProfile.username} className="w-full h-full object-cover" />
              ) : (
                <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-emerald-500 to-cyan-500 text-white text-2xl font-bold">
                  {displayProfile.username[0]?.toUpperCase()}
                </div>
              )}
            </div>
            {isOwnProfile && (
              <>
                <input ref={avatarInputRef} type="file" accept="image/*" onChange={handleAvatarUpload} className="hidden" />
                <button
                  onClick={() => avatarInputRef.current?.click()}
                  className="absolute -bottom-1 -right-1 w-7 h-7 rounded-full bg-emerald-500 flex items-center justify-center border-2 border-black hover:bg-emerald-400 transition-colors"
                >
                  <Camera className="w-3.5 h-3.5 text-white" />
                </button>
              </>
            )}
          </div>

          {/* Stats - tappable followers/following */}
          <div className="flex-1 flex justify-around">
            <div className="text-center">
              <p className="text-white font-bold text-lg">{formatCount(posts.length)}</p>
              <p className="text-gray-500 text-xs">Posts</p>
            </div>
            <button
              onClick={() => handleFollowersClick('followers')}
              className="text-center group hover:bg-white/5 rounded-lg px-2 py-1 -mx-1 transition-colors"
            >
              <p className="text-white font-bold text-lg group-hover:text-emerald-400 transition-colors">
                {formatCount(followCounts.followers_count)}
              </p>
              <p className="text-gray-500 text-xs group-hover:text-gray-400 transition-colors">Followers</p>
            </button>
            <button
              onClick={() => handleFollowersClick('following')}
              className="text-center group hover:bg-white/5 rounded-lg px-2 py-1 -mx-1 transition-colors"
            >
              <p className="text-white font-bold text-lg group-hover:text-emerald-400 transition-colors">
                {formatCount(followCounts.following_count)}
              </p>
              <p className="text-gray-500 text-xs group-hover:text-gray-400 transition-colors">Following</p>
            </button>
          </div>
        </div>

        {/* Name & Bio */}
        {editing ? (
          <div className="space-y-3 mb-4">
            <div>
              <label className="text-gray-500 text-[10px] uppercase tracking-wider mb-1 block">Username</label>
              <input
                type="text"
                value={editUsername}
                onChange={(e) => setEditUsername(e.target.value.toLowerCase().replace(/[^a-z0-9_]/g, ''))}
                placeholder="Username"
                maxLength={30}
                className="w-full bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-white text-sm outline-none focus:border-emerald-500/50"
              />
            </div>
            <div>
              <label className="text-gray-500 text-[10px] uppercase tracking-wider mb-1 block">Full Name</label>
              <input
                type="text"
                value={editFullName}
                onChange={(e) => setEditFullName(e.target.value)}
                placeholder="Full name"
                className="w-full bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-white text-sm outline-none focus:border-emerald-500/50"
              />
            </div>
            <div>
              <label className="text-gray-500 text-[10px] uppercase tracking-wider mb-1 block">Bio</label>
              <textarea
                value={editBio}
                onChange={(e) => setEditBio(e.target.value)}
                placeholder="Tell us about yourself..."
                rows={3}
                maxLength={150}
                className="w-full bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-white text-sm outline-none focus:border-emerald-500/50 resize-none"
              />
              <p className="text-gray-600 text-[10px] mt-1 text-right">{editBio.length}/150</p>
            </div>
            <div className="flex gap-2">
              <button onClick={handleSaveProfile} className="flex-1 py-2.5 bg-emerald-500 text-white text-sm font-medium rounded-lg hover:bg-emerald-600 transition-colors flex items-center justify-center gap-2">
                <Check className="w-4 h-4" /> Save
              </button>
              <button onClick={() => setEditing(false)} className="flex-1 py-2.5 bg-white/10 text-white text-sm font-medium rounded-lg hover:bg-white/15 transition-colors flex items-center justify-center gap-2">
                <X className="w-4 h-4" /> Cancel
              </button>
            </div>
          </div>
        ) : (
          <div className="mb-4">
            {displayProfile.full_name && <p className="text-white font-semibold text-sm">{displayProfile.full_name}</p>}
            {displayProfile.bio && <p className="text-gray-400 text-sm mt-1 leading-relaxed">{displayProfile.bio}</p>}
            {!displayProfile.bio && isOwnProfile && (
              <button onClick={startEditing} className="text-gray-600 text-sm mt-1 hover:text-gray-400 transition-colors">+ Add a bio</button>
            )}
          </div>
        )}

        {/* Action buttons */}
        {isOwnProfile ? (
          <>
            <div className="flex gap-2">
              <button onClick={startEditing} className="flex-1 py-2.5 bg-white/10 text-white text-sm font-medium rounded-lg flex items-center justify-center gap-2 hover:bg-white/15 transition-colors">
                <Edit3 className="w-4 h-4" /> Edit Profile
              </button>
              <button
                onClick={() => handleFollowersClick('followers')}
                className="py-2.5 px-4 bg-white/10 text-white text-sm font-medium rounded-lg flex items-center justify-center gap-1.5 hover:bg-white/15 transition-colors"
              >
                <Users className="w-4 h-4" />
              </button>
            </div>

            {/* View Analytics Button */}
            {onAnalytics && (
              <button
                onClick={onAnalytics}
                className="w-full mt-2.5 py-3 bg-gradient-to-r from-purple-600/90 via-indigo-500/90 to-cyan-500/90 text-white text-sm font-semibold rounded-xl flex items-center justify-center gap-2.5 hover:shadow-lg hover:shadow-purple-500/20 transition-all active:scale-[0.98] border border-white/10"
              >
                <BarChart3 className="w-5 h-5" />
                <span>View Analytics</span>
                <ChevronRight className="w-4 h-4 opacity-60" />
              </button>
            )}
          </>
        ) : (
          <div className="flex gap-2">
            <button
              onClick={handleFollow}
              disabled={isFollowAnimating}
              className={`flex-1 py-2.5 text-sm font-semibold rounded-lg transition-all active:scale-[0.98] flex items-center justify-center gap-2 ${
                isFollowingUser
                  ? 'bg-white/10 text-white hover:bg-red-500/10 hover:text-red-400 hover:border-red-500/20 border border-transparent'
                  : 'bg-gradient-to-r from-emerald-500 to-cyan-500 text-white hover:shadow-lg hover:shadow-emerald-500/20'
              }`}
            >
              {isFollowAnimating ? (
                <div className="w-4 h-4 border-2 border-current border-t-transparent rounded-full animate-spin" />
              ) : isFollowingUser ? (
                <>
                  <Users className="w-4 h-4" />
                  <span>Following</span>
                </>
              ) : (
                <>
                  <UserPlus className="w-4 h-4" />
                  Follow
                </>
              )}
            </button>
            <button onClick={handleMessage} className="flex-1 py-2.5 bg-white/10 text-white text-sm font-medium rounded-lg hover:bg-white/15 transition-colors flex items-center justify-center gap-2">
              <MessageCircle className="w-4 h-4" /> Message
            </button>
            <button
              onClick={() => handleFollowersClick('followers')}
              className="py-2.5 px-3 bg-white/10 text-gray-400 rounded-lg hover:bg-white/15 transition-colors flex items-center"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        )}

        {/* Mutual followers hint */}
        {!isOwnProfile && followCounts.followers_count > 0 && (
          <button
            onClick={() => handleFollowersClick('followers')}
            className="mt-3 flex items-center gap-2 text-gray-500 hover:text-gray-300 transition-colors"
          >
            <div className="flex -space-x-2">
              <div className="w-5 h-5 rounded-full bg-gradient-to-br from-emerald-500 to-cyan-500 border border-black" />
              {followCounts.followers_count > 1 && (
                <div className="w-5 h-5 rounded-full bg-gradient-to-br from-purple-500 to-pink-500 border border-black" />
              )}
              {followCounts.followers_count > 2 && (
                <div className="w-5 h-5 rounded-full bg-gradient-to-br from-blue-500 to-cyan-500 border border-black" />
              )}
            </div>
            <span className="text-xs">
              {followCounts.followers_count === 1
                ? '1 follower'
                : `${formatCount(followCounts.followers_count)} followers`
              }
            </span>
            <ChevronRight className="w-3 h-3" />
          </button>
        )}
      </div>

      {/* Tabs */}
      <div className="flex border-b border-white/10 sticky top-12 bg-black z-10">
        <button onClick={() => setActiveTab('posts')} className={`flex-1 py-3 flex items-center justify-center gap-2 transition-colors relative ${activeTab === 'posts' ? 'text-white' : 'text-gray-500'}`}>
          <Grid3x3 className="w-4 h-4" />
          {activeTab === 'posts' && <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-8 h-0.5 bg-white rounded-full" />}
        </button>
        <button onClick={() => setActiveTab('liked')} className={`flex-1 py-3 flex items-center justify-center gap-2 transition-colors relative ${activeTab === 'liked' ? 'text-white' : 'text-gray-500'}`}>
          <Heart className="w-4 h-4" />
          {activeTab === 'liked' && <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-8 h-0.5 bg-white rounded-full" />}
        </button>
        {isOwnProfile && (
          <button onClick={() => setActiveTab('saved')} className={`flex-1 py-3 flex items-center justify-center gap-2 transition-colors relative ${activeTab === 'saved' ? 'text-white' : 'text-gray-500'}`}>
            <Bookmark className="w-4 h-4" />
            {activeTab === 'saved' && <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-8 h-0.5 bg-white rounded-full" />}
          </button>
        )}
      </div>

      {/* Posts grid */}
      <div className="flex-1 pb-20">
        {loading && activeTab === 'posts' ? (
          <div className="flex items-center justify-center py-12">
            <div className="w-6 h-6 border-2 border-emerald-400 border-t-transparent rounded-full animate-spin" />
          </div>
        ) : displayPosts.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-16 text-center px-8">
            {activeTab === 'posts' && <Grid3x3 className="w-10 h-10 text-gray-600 mb-3" />}
            {activeTab === 'liked' && <Heart className="w-10 h-10 text-gray-600 mb-3" />}
            {activeTab === 'saved' && <Bookmark className="w-10 h-10 text-gray-600 mb-3" />}
            <p className="text-gray-500 text-sm">
              {activeTab === 'posts' ? 'No posts yet' : activeTab === 'liked' ? 'No liked posts' : 'No saved posts'}
            </p>
            {activeTab === 'posts' && isOwnProfile && (
              <p className="text-gray-600 text-xs mt-1">Share your first moment!</p>
            )}
          </div>
        ) : (
          <div className="grid grid-cols-3 gap-0.5 p-0.5">
            {displayPosts.map((post) => (
              <div
                key={post.id}
                className="aspect-[3/4] bg-gray-900 overflow-hidden relative group"
              >
                <button
                  onClick={() => onPostClick?.(post)}
                  className="w-full h-full"
                >
                  <img
                    src={post.thumbnail_url || post.media_url}
                    alt={post.caption}
                    className="w-full h-full object-cover group-hover:opacity-80 transition-opacity"
                    loading="lazy"
                  />
                </button>
                {/* Hover overlay with counts */}
                <div className="absolute inset-0 bg-black/0 group-hover:bg-black/30 transition-colors flex items-center justify-center opacity-0 group-hover:opacity-100 pointer-events-none">
                  <div className="flex items-center gap-3 text-white text-sm font-semibold">
                    <div className="flex items-center gap-1">
                      <Heart className="w-4 h-4 fill-white" />
                      <span>{post.likes_count}</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <MessageCircle className="w-4 h-4 fill-white" />
                      <span>{post.comments_count}</span>
                    </div>
                  </div>
                </div>
                {/* Video indicator */}
                {post.media_type === 'video' && (
                  <div className="absolute top-1.5 left-1.5 pointer-events-none">
                    <svg className="w-4 h-4 text-white drop-shadow-lg" viewBox="0 0 24 24" fill="currentColor">
                      <path d="M8 5v14l11-7z" />
                    </svg>
                  </div>
                )}
                {/* === POST DELETE: Three-dot menu (own profile, posts tab only) === */}
                {isOwnProfile && activeTab === 'posts' && (
                  <div className="absolute top-1 right-1 z-10">
                    <button
                      type="button"
                      onClick={(e) => {
                        e.preventDefault();
                        e.stopPropagation();
                        setPostMenuOpen(postMenuOpen === post.id ? null : post.id);
                      }}
                      className="w-7 h-7 rounded-full bg-black/50 backdrop-blur-sm flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity hover:bg-black/70 active:scale-90"
                    >
                      <MoreVertical className="w-3.5 h-3.5 text-white" />
                    </button>
                    {/* Dropdown menu */}
                    {postMenuOpen === post.id && (
                      <div className="absolute top-8 right-0 bg-[#1a1a1a] border border-white/10 rounded-lg shadow-xl overflow-hidden min-w-[140px] z-20">
                        <button
                          type="button"
                          onClick={(e) => {
                            e.preventDefault();
                            e.stopPropagation();
                            setDeletePostTarget(post);
                            setPostMenuOpen(null);
                          }}
                          className="w-full flex items-center gap-2.5 px-3 py-2.5 text-red-400 hover:bg-white/5 transition-colors text-left"
                        >
                          <Trash2 className="w-4 h-4" />
                          <span className="text-sm font-medium">Delete</span>
                        </button>
                      </div>
                    )}
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </div>

      {/* === POST DELETE CONFIRMATION MODAL === */}
      {deletePostTarget && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm px-6" onClick={() => { if (!isDeletingPost) { setDeletePostTarget(null); setPostMenuOpen(null); } }}>
          <div className="bg-[#1a1a1a] rounded-2xl border border-white/10 p-5 max-w-sm w-full shadow-2xl" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center gap-3 mb-3">
              <div className="w-10 h-10 rounded-full bg-red-500/10 flex items-center justify-center flex-shrink-0">
                <AlertTriangle className="w-5 h-5 text-red-400" />
              </div>
              <div>
                <h3 className="text-white font-semibold text-sm">Delete this post?</h3>
                <p className="text-gray-500 text-xs mt-0.5">This cannot be undone.</p>
              </div>
            </div>
            {/* Post preview */}
            <div className="flex items-center gap-3 bg-white/5 rounded-lg p-2.5 mb-4">
              <div className="w-12 h-16 rounded-md overflow-hidden bg-gray-800 flex-shrink-0">
                <img src={deletePostTarget.thumbnail_url || deletePostTarget.media_url} alt="" className="w-full h-full object-cover" />
              </div>
              <p className="text-gray-400 text-xs line-clamp-2 flex-1">{deletePostTarget.caption || 'No caption'}</p>
            </div>
            <div className="flex gap-2">
              <button
                type="button"
                onClick={handleDeletePostConfirm}
                disabled={isDeletingPost}
                className="flex-1 py-2.5 bg-red-500 text-white text-sm font-semibold rounded-lg hover:bg-red-600 transition-colors flex items-center justify-center gap-2 disabled:opacity-50"
              >
                {isDeletingPost ? (
                  <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                ) : (
                  <>
                    <Trash2 className="w-4 h-4" />
                    Delete
                  </>
                )}
              </button>
              <button
                type="button"
                onClick={() => { setDeletePostTarget(null); setPostMenuOpen(null); }}
                disabled={isDeletingPost}
                className="flex-1 py-2.5 bg-white/10 text-white text-sm font-medium rounded-lg hover:bg-white/15 transition-colors disabled:opacity-50"
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Close any open menu when clicking elsewhere */}
      {postMenuOpen && (
        <div className="fixed inset-0 z-5" onClick={() => setPostMenuOpen(null)} />
      )}
    </div>
  );
};

export default ProfileScreen;
