import React, { useState, useEffect, useRef } from 'react';
import { X, Heart, MessageCircle, Send, Smile } from 'lucide-react';

import { supabase } from '@/lib/supabase';
import { useFeedStore, type Comment } from '@/stores/feedStore';
import { useAuthStore } from '@/stores/authStore';
import { useToast } from '@/hooks/use-toast';

interface CommentsSheetProps {
  postId: string;
  isOpen: boolean;
  onClose: () => void;
  onAuthRequired?: () => void;
}

const CommentsSheet: React.FC<CommentsSheetProps> = ({ postId, isOpen, onClose, onAuthRequired }) => {
  const [comments, setComments] = useState<Comment[]>([]);
  const [newComment, setNewComment] = useState('');
  const [loading, setLoading] = useState(false);
  const [sending, setSending] = useState(false);
  const [likedComments, setLikedComments] = useState<Set<string>>(new Set());
  const [replyTo, setReplyTo] = useState<{ id: string; username: string } | null>(null);
  const { fetchComments, addComment, updatePostCounts } = useFeedStore();
  const { user, profile, isAuthenticated } = useAuthStore();
  const { toast } = useToast();
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const listRef = useRef<HTMLDivElement>(null);
  const channelRef = useRef<any>(null);
  const sheetRef = useRef<HTMLDivElement>(null);

  // === KEY FIX: Use a ref to always have the latest newComment value ===
  // This prevents stale closure issues in handleSend
  const newCommentRef = useRef(newComment);
  newCommentRef.current = newComment;

  const sendingRef = useRef(sending);
  sendingRef.current = sending;

  // TikTok-style: derived state — has text to send?
  const hasText = newComment.trim().length > 0;

  // Drag-to-close state
  const [dragY, setDragY] = useState(0);
  const [isDragging, setIsDragging] = useState(false);
  const dragStartRef = useRef(0);

  // Snap points
  const [sheetHeight, setSheetHeight] = useState(75);

  useEffect(() => {
    if (isOpen && postId) {
      console.log('[Comments] Opening for post:', postId);
      setSheetHeight(75);
      loadComments();
      subscribeToComments();
      setTimeout(() => {
        textareaRef.current?.focus();
      }, 500);
    } else {
      setComments([]);
      setNewComment('');
      setReplyTo(null);
      setSheetHeight(75);
    }
    return () => {
      unsubscribeFromComments();
    };
  }, [isOpen, postId]);

  const subscribeToComments = () => {
    if (!postId) return;
    unsubscribeFromComments();

    try {
      const channel = supabase
        .channel(`comments-${postId}-${Date.now()}`)
        .on(
          'postgres_changes',
          {
            event: 'INSERT',
            schema: 'public',
            table: 'comments',
            filter: `post_id=eq.${postId}`,
          },
          async (payload: any) => {
            const newCommentData = payload.new;
            console.log('[Comments] Realtime new comment:', newCommentData.id);
            try {
              const { data: profileData } = await supabase
                .from('profiles')
                .select('username, avatar_url')
                .eq('id', newCommentData.user_id)
                .single();

              const commentWithProfile: Comment = {
                ...newCommentData,
                profiles: profileData || { username: 'user', avatar_url: null },
              };

              setComments(prev => {
                if (prev.some(c => c.id === commentWithProfile.id)) return prev;
                // Remove optimistic comment matching content+user
                const filtered = prev.filter(c => {
                  if (c.id.startsWith('temp-') && c.user_id === newCommentData.user_id && c.content === newCommentData.content) {
                    return false;
                  }
                  return true;
                });
                return [commentWithProfile, ...filtered];
              });
            } catch (err) {
              console.error('[Comments] Fetch comment profile error:', err);
            }
          }
        )
        .subscribe((status: string) => {
          console.log('[Comments] Realtime subscription status:', status);
        });

      channelRef.current = channel;
    } catch (err) {
      console.error('[Comments] Subscribe error:', err);
    }
  };

  const unsubscribeFromComments = () => {
    if (channelRef.current) {
      try {
        supabase.removeChannel(channelRef.current);
      } catch (err) {
        console.error('[Comments] Unsubscribe error:', err);
      }
      channelRef.current = null;
    }
  };

  const loadComments = async () => {
    setLoading(true);
    console.log('[Comments] Loading comments for post:', postId);
    const data = await fetchComments(postId);
    console.log('[Comments] Loaded', data.length, 'comments');
    setComments(data);
    setLoading(false);
  };

  // ============================
  // SEND COMMENT — Core handler
  // KEY FIX: NOT wrapped in useCallback — reads from refs to avoid stale closures
  // ============================
  const handleSend = async () => {
    // Read from refs to get the absolute latest values
    const trimmed = newCommentRef.current.trim();
    if (!trimmed) {
      console.log('[Comments] handleSend: empty text, aborting');
      return;
    }
    if (sendingRef.current) {
      console.log('[Comments] handleSend: already sending, aborting');
      return;
    }

    console.log('[Comments] handleSend called, text:', trimmed.substring(0, 50));

    // === RESOLVE USER ID: store first, session fallback ===
    let userId = user?.id;
    if (!userId) {
      try {
        const { data: { session } } = await supabase.auth.getSession();
        userId = session?.user?.id;
      } catch {
        // ignore
      }
    }
    if (!userId) {
      console.warn('[Comments] No user ID found — not authenticated');
      toast({
        title: 'Please sign in',
        description: 'You need to be signed in to comment.',
        variant: 'destructive',
      });
      onAuthRequired?.();
      return;
    }

    console.log('[Comments] Sending as user:', userId);
    setSending(true);
    const content = trimmed;

    // Clear input IMMEDIATELY (TikTok behavior)
    setNewComment('');
    setReplyTo(null);

    // Reset textarea height
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
    }

    // === OPTIMISTIC UPDATE: Add comment to local list immediately ===
    const tempId = `temp-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;
    const optimisticComment: Comment = {
      id: tempId,
      post_id: postId,
      user_id: userId,
      content,
      created_at: new Date().toISOString(),
      profiles: {
        username: profile?.username || user?.email?.split('@')[0] || 'you',
        avatar_url: profile?.avatar_url || null,
      },
    };
    setComments(prev => [optimisticComment, ...prev]);

    // Scroll to top to see new comment
    if (listRef.current) {
      listRef.current.scrollTop = 0;
    }

    // Blur textarea to dismiss keyboard on mobile
    textareaRef.current?.blur();

    // === ACTUAL INSERT — try direct Supabase first for reliability ===
    try {
      console.log('[Comments] Inserting directly to Supabase...');
      const { data: insertData, error: directError } = await supabase
        .from('comments')
        .insert({
          post_id: postId,
          user_id: userId,
          content,
        })
        .select();

      if (directError) {
        console.error('[Comments] Direct insert failed:', directError.message, directError.details, directError.hint);

        // Remove optimistic comment on failure
        setComments(prev => prev.filter(c => c.id !== tempId));
        setNewComment(content); // Restore input
        toast({
          title: 'Failed to post comment',
          description: directError.message || 'Something went wrong. Please try again.',
          variant: 'destructive',
        });
        setSending(false);
        setTimeout(() => textareaRef.current?.focus(), 100);
        return;
      }

      console.log('[Comments] Insert succeeded:', insertData);

      // Update comment count in feed store
      updatePostCounts(postId, 'comments_count', 1);

      // The realtime subscription will replace the optimistic comment with the real one.
      // Fallback: if realtime doesn't fire within 3s, reload comments
      setTimeout(() => {
        setComments(prev => {
          const stillHasTemp = prev.some(c => c.id === tempId);
          if (stillHasTemp) {
            console.log('[Comments] Realtime fallback: reloading comments');
            loadComments();
          }
          return prev;
        });
      }, 3000);
    } catch (err: any) {
      console.error('[Comments] Send error:', err);
      // Remove optimistic comment on exception
      setComments(prev => prev.filter(c => c.id !== tempId));
      setNewComment(content); // Restore input
      toast({
        title: 'Failed to post comment',
        description: err?.message || 'Something went wrong. Check your connection.',
        variant: 'destructive',
      });
    }

    setSending(false);
    // Re-focus textarea after sending
    setTimeout(() => textareaRef.current?.focus(), 100);
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const toggleCommentLike = (commentId: string) => {
    setLikedComments(prev => {
      const next = new Set(prev);
      if (next.has(commentId)) {
        next.delete(commentId);
      } else {
        next.add(commentId);
      }
      return next;
    });
  };

  const handleReply = (commentId: string, username: string) => {
    setReplyTo({ id: commentId, username });
    setNewComment(`@${username} `);
    setTimeout(() => textareaRef.current?.focus(), 100);
  };

  const cancelReply = () => {
    setReplyTo(null);
    setNewComment('');
  };

  // Handle drag to close
  const handleTouchStart = (e: React.TouchEvent) => {
    const target = e.target as HTMLElement;
    if (target.closest('[data-drag-handle]')) {
      dragStartRef.current = e.touches[0].clientY;
      setIsDragging(true);
    }
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    if (!isDragging) return;
    const diff = e.touches[0].clientY - dragStartRef.current;
    if (diff > 0) {
      setDragY(diff);
    }
  };

  const handleTouchEnd = () => {
    if (!isDragging) return;
    setIsDragging(false);
    if (dragY > 120) {
      onClose();
    }
    setDragY(0);
  };

  // Mouse drag support for desktop
  const handleMouseDown = (e: React.MouseEvent) => {
    const target = e.target as HTMLElement;
    if (target.closest('[data-drag-handle]')) {
      dragStartRef.current = e.clientY;
      setIsDragging(true);
    }
  };

  useEffect(() => {
    if (!isDragging) return;

    const handleMouseMove = (e: MouseEvent) => {
      const diff = e.clientY - dragStartRef.current;
      if (diff > 0) {
        setDragY(diff);
      }
    };

    const handleMouseUp = () => {
      setIsDragging(false);
      if (dragY > 120) {
        onClose();
      }
      setDragY(0);
    };

    window.addEventListener('mousemove', handleMouseMove);
    window.addEventListener('mouseup', handleMouseUp);
    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mouseup', handleMouseUp);
    };
  }, [isDragging, dragY, onClose]);

  if (!isOpen) return null;

  const timeAgo = (date: string) => {
    const seconds = Math.floor((Date.now() - new Date(date).getTime()) / 1000);
    if (seconds < 60) return 'just now';
    if (seconds < 3600) return `${Math.floor(seconds / 60)}m`;
    if (seconds < 86400) return `${Math.floor(seconds / 3600)}h`;
    if (seconds < 604800) return `${Math.floor(seconds / 86400)}d`;
    return `${Math.floor(seconds / 604800)}w`;
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-end justify-center"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      {/* Backdrop */}
      <div
        className="absolute inset-0 bg-black/60 backdrop-blur-sm animate-[fadeIn_0.2s_ease-out]"
        onClick={onClose}
      />

      {/* Sheet container */}
      <div
        ref={sheetRef}
        className="relative w-full max-w-lg flex flex-col animate-[slideUp_0.3s_ease-out]"
        style={{
          height: `${sheetHeight}vh`,
          maxHeight: `${sheetHeight}vh`,
          transform: dragY > 0 ? `translateY(${dragY}px)` : undefined,
          transition: isDragging ? 'none' : 'transform 0.3s ease-out',
        }}
        onTouchStart={handleTouchStart}
        onTouchMove={handleTouchMove}
        onTouchEnd={handleTouchEnd}
        onMouseDown={handleMouseDown}
        onClick={(e) => e.stopPropagation()}
      >
        {/* Sheet body with rounded top */}
        <div className="flex-1 bg-[#0a0a0a] rounded-t-2xl flex flex-col overflow-hidden border-t border-white/5">
          {/* Drag handle */}
          <div
            data-drag-handle
            className="flex justify-center pt-3 pb-1 cursor-grab active:cursor-grabbing flex-shrink-0"
          >
            <div className="w-12 h-1.5 bg-gray-600 rounded-full hover:bg-gray-500 transition-colors" />
          </div>

          {/* Header */}
          <div className="flex items-center justify-between px-4 py-2 border-b border-white/10 flex-shrink-0">
            <div className="flex items-center gap-2">
              <MessageCircle className="w-[18px] h-[18px] text-emerald-400" />
              <span className="text-white font-semibold text-base">
                {loading ? 'Comments' : `${comments.length} ${comments.length === 1 ? 'Comment' : 'Comments'}`}
              </span>
            </div>
            <button
              onClick={onClose}
              className="p-2 hover:bg-white/10 rounded-full transition-colors active:scale-90"
            >
              <X className="w-5 h-5 text-gray-400" />
            </button>
          </div>

          {/* INPUT AREA — AT THE TOP */}
          <div className="flex-shrink-0 border-b border-white/10 bg-[#111111]">
            {/* Reply indicator bar */}
            {replyTo && (
              <div className="flex items-center justify-between px-4 py-2 bg-emerald-500/10 border-b border-emerald-500/20">
                <span className="text-gray-300 text-xs">
                  Replying to <span className="text-emerald-400 font-semibold">@{replyTo.username}</span>
                </span>
                <button onClick={cancelReply} className="text-gray-500 hover:text-white transition-colors p-0.5">
                  <X className="w-3.5 h-3.5" />
                </button>
              </div>
            )}

            {isAuthenticated ? (
              <div className="px-3 py-3">
                {/* Top input row: avatar + textarea + TikTok send button */}
                <div className="flex items-end gap-2.5">
                  {/* User avatar */}
                  <div className="w-9 h-9 rounded-full bg-gradient-to-br from-emerald-500 to-cyan-500 flex-shrink-0 flex items-center justify-center overflow-hidden mb-0.5">
                    {profile?.avatar_url ? (
                      <img src={profile.avatar_url} className="w-full h-full object-cover" alt="" />
                    ) : (
                      <span className="text-white text-sm font-bold">
                        {profile?.username?.[0]?.toUpperCase() || user?.email?.[0]?.toUpperCase() || 'U'}
                      </span>
                    )}
                  </div>

                  {/* Textarea input */}
                  <div className="flex-1 relative">
                    <textarea
                      ref={textareaRef}
                      value={newComment}
                      onChange={(e) => {
                        setNewComment(e.target.value);
                        e.target.style.height = 'auto';
                        e.target.style.height = Math.min(e.target.scrollHeight, 100) + 'px';
                      }}
                      onKeyDown={handleKeyDown}
                      placeholder="Add a comment..."
                      rows={1}
                      className="w-full bg-white/[0.08] border border-white/[0.15] rounded-2xl px-4 py-2.5 pr-10 text-white text-sm placeholder-gray-500 outline-none focus:ring-2 focus:ring-emerald-500/60 focus:bg-white/10 focus:border-emerald-500/40 transition-all resize-none min-h-[42px] max-h-[100px] leading-5"
                      maxLength={500}
                      autoComplete="off"
                    />
                    {/* Smile icon inside input right side — visible only when empty */}
                    {!hasText && (
                      <div className="absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none">
                        <Smile className="w-5 h-5 text-gray-600" />
                      </div>
                    )}
                    {/* Character count when approaching limit */}
                    {newComment.length > 400 && (
                      <span className="absolute bottom-1.5 right-3 text-[10px] text-gray-500">
                        {newComment.length}/500
                      </span>
                    )}
                  </div>

                  {/* SEND BUTTON — TikTok style: hidden when empty, slides in when typing */}
                  <div
                    className={`transition-all duration-200 ease-out flex-shrink-0 mb-0.5 ${
                      hasText ? 'w-10 opacity-100' : 'w-0 opacity-0 overflow-hidden'
                    }`}
                  >
                    <button
                      type="button"
                      onClick={(e) => {
                        e.preventDefault();
                        e.stopPropagation();
                        console.log('[Comments] Send button clicked, hasText:', hasText, 'sending:', sending);
                        handleSend();
                      }}
                      disabled={!hasText || sending}
                      aria-label="Send comment"
                      className={`w-10 h-10 rounded-full flex items-center justify-center transition-all duration-150 active:scale-[0.85] ${
                        hasText && !sending
                          ? 'bg-gradient-to-br from-emerald-500 to-cyan-500 shadow-lg shadow-emerald-500/30 hover:shadow-emerald-500/50 hover:from-emerald-400 hover:to-cyan-400'
                          : 'bg-gray-700'
                      }`}
                    >
                      {sending ? (
                        <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                      ) : (
                        <Send className="w-[18px] h-[18px] text-white" style={{ transform: 'rotate(-45deg)', marginLeft: '2px', marginTop: '-1px' }} />
                      )}
                    </button>
                  </div>
                </div>

                {/* Hint text below input */}
                <p className="text-gray-600 text-[10px] mt-1.5 ml-[46px]">
                  Press Enter to send{hasText ? '' : ' — start typing above'}
                </p>
              </div>
            ) : (
              /* Not authenticated — show sign-in prompt at top */
              <div className="px-4 py-4 text-center">
                <button
                  onClick={onAuthRequired}
                  className="w-full py-3.5 bg-gradient-to-r from-emerald-500 to-cyan-500 text-white text-sm font-semibold rounded-xl hover:shadow-lg hover:shadow-emerald-500/20 transition-all active:scale-[0.98]"
                >
                  Sign in to comment
                </button>
              </div>
            )}
          </div>

          {/* COMMENTS LIST — Scrollable area BELOW the input */}
          <div
            ref={listRef}
            className="flex-1 overflow-y-auto px-4 py-3 space-y-5 scrollbar-hide overscroll-contain"
          >
            {loading ? (
              <div className="flex flex-col items-center justify-center py-12">
                <div className="w-8 h-8 border-2 border-emerald-400 border-t-transparent rounded-full animate-spin" />
                <p className="text-gray-500 text-xs mt-3">Loading comments...</p>
              </div>
            ) : comments.length === 0 ? (
              <div className="flex flex-col items-center justify-center py-16 text-gray-500">
                <div className="w-16 h-16 rounded-full bg-white/5 flex items-center justify-center mb-4">
                  <MessageCircle className="w-8 h-8 opacity-30" />
                </div>
                <p className="text-sm font-medium">No comments yet</p>
                <p className="text-xs mt-1.5 text-gray-600">Be the first to comment!</p>
              </div>
            ) : (
              comments.map((comment) => {
                const isCommentLiked = likedComments.has(comment.id);
                const isOptimistic = comment.id.startsWith('temp-');
                return (
                  <div key={comment.id} className={`flex gap-3 group ${isOptimistic ? 'opacity-60' : ''}`}>
                    {/* Comment avatar */}
                    <div className="w-9 h-9 rounded-full bg-gradient-to-br from-emerald-500 to-cyan-500 flex-shrink-0 flex items-center justify-center overflow-hidden mt-0.5">
                      {comment.profiles?.avatar_url ? (
                        <img src={comment.profiles.avatar_url} className="w-full h-full object-cover" alt="" />
                      ) : (
                        <span className="text-white text-xs font-bold">
                          {comment.profiles?.username?.[0]?.toUpperCase() || '?'}
                        </span>
                      )}
                    </div>

                    {/* Comment content */}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <span className="text-white text-xs font-semibold truncate">
                          @{comment.profiles?.username || 'user'}
                        </span>
                        <span className="text-gray-600 text-[10px] flex-shrink-0">
                          {isOptimistic ? 'sending...' : timeAgo(comment.created_at)}
                        </span>
                      </div>
                      <p className="text-gray-300 text-[13px] mt-1 break-words leading-5">{comment.content}</p>
                      {!isOptimistic && (
                        <div className="flex items-center gap-4 mt-2">
                          <button
                            onClick={() => toggleCommentLike(comment.id)}
                            className="flex items-center gap-1 text-gray-500 hover:text-red-400 transition-colors active:scale-90"
                          >
                            <Heart className={`w-3.5 h-3.5 ${isCommentLiked ? 'text-red-500 fill-red-500' : ''}`} />
                            {isCommentLiked && <span className="text-[10px] text-red-400">1</span>}
                          </button>
                          <button
                            onClick={() => handleReply(comment.id, comment.profiles?.username || 'user')}
                            className="text-gray-500 text-[11px] font-medium hover:text-gray-300 transition-colors"
                          >
                            Reply
                          </button>
                        </div>
                      )}
                    </div>

                    {/* Like button on right side (hover reveal) */}
                    {!isOptimistic && (
                      <button
                        onClick={() => toggleCommentLike(comment.id)}
                        className="flex-shrink-0 self-center opacity-0 group-hover:opacity-100 transition-opacity p-1"
                      >
                        <Heart className={`w-4 h-4 ${isCommentLiked ? 'text-red-500 fill-red-500' : 'text-gray-600'}`} />
                      </button>
                    )}
                  </div>
                );
              })
            )}
          </div>

          {/* Safe area padding for mobile devices */}
          <div className="flex-shrink-0 h-[env(safe-area-inset-bottom,0px)] bg-[#0a0a0a]" />
        </div>
      </div>
    </div>
  );
};

export default CommentsSheet;
