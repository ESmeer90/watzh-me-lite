import React, { useState, useCallback } from 'react';
import {
  ArrowLeft, Shield, Mail, MapPin, Calendar, ChevronDown, ChevronUp,
  Lock, Eye, Trash2, FileText, Globe, Server, Users, AlertCircle,
  Database, Share2, Clock, Baby, Plane, Bell, CheckCircle, XCircle,
  ExternalLink, ChevronsDown, ChevronsUp
} from 'lucide-react';

interface PrivacyPolicyProps {
  onBack: () => void;
}

interface SectionProps {
  id: string;
  title: string;
  icon: React.ReactNode;
  children: React.ReactNode;
  isOpen: boolean;
  onToggle: (id: string) => void;
}

const CollapsibleSection: React.FC<SectionProps> = ({ id, title, icon, children, isOpen, onToggle }) => {
  return (
    <div className="border border-white/5 rounded-xl overflow-hidden bg-white/[0.02]">
      <button
        onClick={() => onToggle(id)}
        className="w-full flex items-center gap-3 px-4 py-3.5 hover:bg-white/5 transition-colors text-left"
        aria-expanded={isOpen}
        aria-controls={`section-${id}`}
      >
        <div className="w-8 h-8 rounded-lg bg-emerald-500/10 flex items-center justify-center flex-shrink-0">
          {icon}
        </div>
        <span className="text-white font-semibold text-sm flex-1">{title}</span>
        {isOpen ? (
          <ChevronUp className="w-4 h-4 text-gray-500 flex-shrink-0" />
        ) : (
          <ChevronDown className="w-4 h-4 text-gray-500 flex-shrink-0" />
        )}
      </button>
      {isOpen && (
        <div
          id={`section-${id}`}
          className="px-4 pb-4 pt-1 text-gray-300 text-sm leading-relaxed space-y-3 border-t border-white/5"
        >
          {children}
        </div>
      )}
    </div>
  );
};

const DataRow: React.FC<{ label: string; value: string; collected: boolean; shared: boolean; purpose: string }> = ({
  label, value, collected, shared, purpose
}) => (
  <div className="flex flex-col gap-1 py-2.5 border-b border-white/5 last:border-0">
    <div className="flex items-center justify-between">
      <span className="text-white text-xs font-medium">{label}</span>
      <div className="flex items-center gap-3">
        <div className="flex items-center gap-1">
          {collected ? (
            <CheckCircle className="w-3.5 h-3.5 text-emerald-400" />
          ) : (
            <XCircle className="w-3.5 h-3.5 text-gray-600" />
          )}
          <span className="text-[10px] text-gray-500">Collected</span>
        </div>
        <div className="flex items-center gap-1">
          {shared ? (
            <CheckCircle className="w-3.5 h-3.5 text-orange-400" />
          ) : (
            <XCircle className="w-3.5 h-3.5 text-gray-600" />
          )}
          <span className="text-[10px] text-gray-500">Shared</span>
        </div>
      </div>
    </div>
    <p className="text-gray-500 text-[11px]">{value}</p>
    <p className="text-gray-600 text-[10px]">Purpose: {purpose}</p>
  </div>
);

const PrivacyPolicy: React.FC<PrivacyPolicyProps> = ({ onBack }) => {
  const effectiveDate = 'February 11, 2026';
  const lastReviewed = 'February 11, 2026';
  const policyVersion = '1.1';

  const allSectionIds = [
    'intro', 'officer', 'collected', 'usage', 'legal-basis', 'sharing',
    'rights', 'security', 'retention', 'children', 'transfers',
    'changes', 'malabo', 'data-safety', 'contact'
  ];

  const [openSections, setOpenSections] = useState<Set<string>>(new Set(['intro']));

  const toggleSection = useCallback((id: string) => {
    setOpenSections(prev => {
      const next = new Set(prev);
      if (next.has(id)) {
        next.delete(id);
      } else {
        next.add(id);
      }
      return next;
    });
  }, []);

  const expandAll = () => setOpenSections(new Set(allSectionIds));
  const collapseAll = () => setOpenSections(new Set());
  const allExpanded = openSections.size === allSectionIds.length;

  return (
    <div className="h-full w-full bg-black flex flex-col overflow-y-auto scrollbar-hide">
      {/* Sticky Header */}
      <div className="flex items-center gap-3 px-4 py-3 sticky top-0 bg-black/95 backdrop-blur-sm z-10 border-b border-white/10">
        <button
          onClick={onBack}
          className="p-1.5 hover:bg-white/10 rounded-full transition-colors"
          aria-label="Go back"
        >
          <ArrowLeft className="w-5 h-5 text-white" />
        </button>
        <h2 className="text-white font-bold text-base flex-1">Privacy Policy</h2>
        <button
          onClick={allExpanded ? collapseAll : expandAll}
          className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-white/5 hover:bg-white/10 transition-colors"
          aria-label={allExpanded ? 'Collapse all sections' : 'Expand all sections'}
        >
          {allExpanded ? (
            <ChevronsUp className="w-3.5 h-3.5 text-gray-400" />
          ) : (
            <ChevronsDown className="w-3.5 h-3.5 text-gray-400" />
          )}
          <span className="text-gray-400 text-[10px] font-medium">
            {allExpanded ? 'Collapse' : 'Expand'}
          </span>
        </button>
      </div>

      <div className="px-4 py-5 pb-24 space-y-4">
        {/* Hero Card */}
        <div className="bg-gradient-to-br from-emerald-500/10 via-emerald-500/5 to-cyan-500/10 rounded-2xl p-5 border border-emerald-500/20">
          <div className="flex items-center gap-3 mb-3">
            <div className="w-12 h-12 rounded-xl bg-emerald-500/20 flex items-center justify-center shadow-lg shadow-emerald-500/10">
              <Shield className="w-6 h-6 text-emerald-400" />
            </div>
            <div>
              <h1 className="text-white font-bold text-lg">WATZHMe Lite</h1>
              <p className="text-gray-400 text-xs">Privacy Policy & Data Protection Notice</p>
            </div>
          </div>
          <div className="flex flex-wrap gap-x-4 gap-y-1.5 mt-3">
            <div className="flex items-center gap-1.5 text-gray-400 text-xs">
              <Calendar className="w-3.5 h-3.5 flex-shrink-0" />
              <span>Effective: {effectiveDate}</span>
            </div>
            <div className="flex items-center gap-1.5 text-gray-400 text-xs">
              <Clock className="w-3.5 h-3.5 flex-shrink-0" />
              <span>Reviewed: {lastReviewed}</span>
            </div>
            <div className="flex items-center gap-1.5 text-gray-400 text-xs">
              <MapPin className="w-3.5 h-3.5 flex-shrink-0" />
              <span>Kimberley, Northern Cape, SA</span>
            </div>
            <div className="flex items-center gap-1.5 text-gray-400 text-xs">
              <FileText className="w-3.5 h-3.5 flex-shrink-0" />
              <span>Version {policyVersion}</span>
            </div>
          </div>
        </div>

        {/* Quick Summary */}
        <div className="bg-cyan-500/5 rounded-xl p-4 border border-cyan-500/10">
          <p className="text-cyan-400 text-xs font-semibold mb-2.5 uppercase tracking-wider">
            Your Privacy at a Glance
          </p>
          <div className="space-y-2">
            <div className="flex items-start gap-2.5">
              <Lock className="w-3.5 h-3.5 text-emerald-400 mt-0.5 flex-shrink-0" />
              <span className="text-gray-300 text-sm">Your data is encrypted in transit (TLS 1.3) and at rest (AES-256)</span>
            </div>
            <div className="flex items-start gap-2.5">
              <Eye className="w-3.5 h-3.5 text-emerald-400 mt-0.5 flex-shrink-0" />
              <span className="text-gray-300 text-sm">We collect only what is necessary to operate the app</span>
            </div>
            <div className="flex items-start gap-2.5">
              <Trash2 className="w-3.5 h-3.5 text-emerald-400 mt-0.5 flex-shrink-0" />
              <span className="text-gray-300 text-sm">You can request deletion of all your data at any time</span>
            </div>
            <div className="flex items-start gap-2.5">
              <Globe className="w-3.5 h-3.5 text-emerald-400 mt-0.5 flex-shrink-0" />
              <span className="text-gray-300 text-sm">We do not sell, rent, or trade your personal information</span>
            </div>
            <div className="flex items-start gap-2.5">
              <XCircle className="w-3.5 h-3.5 text-emerald-400 mt-0.5 flex-shrink-0" />
              <span className="text-gray-300 text-sm">No targeted advertising, no profiling, no tracking</span>
            </div>
            <div className="flex items-start gap-2.5">
              <Shield className="w-3.5 h-3.5 text-emerald-400 mt-0.5 flex-shrink-0" />
              <span className="text-gray-300 text-sm">Fully compliant with POPIA, Malabo Convention, and GDPR</span>
            </div>
          </div>
        </div>

        {/* All Sections */}
        <div className="space-y-2">

          {/* 1. Introduction */}
          <CollapsibleSection
            id="intro"
            title="1. Introduction & Scope"
            icon={<FileText className="w-4 h-4 text-emerald-400" />}
            isOpen={openSections.has('intro')}
            onToggle={toggleSection}
          >
            <p>
              WATZHMe Lite (&quot;WATZHMe&quot;, &quot;we&quot;, &quot;us&quot;, &quot;our&quot;) is a social media 
              platform operated from <strong className="text-white">Kimberley, Northern Cape, South Africa</strong>. 
              This Privacy Policy explains how we collect, use, store, share, and protect your personal information 
              when you use our mobile application and related services (collectively, the &quot;Service&quot;).
            </p>
            <p>This policy is designed to comply with the following legislation and standards:</p>
            <ul className="list-disc list-inside space-y-1.5 text-gray-400 ml-2">
              <li>
                <strong className="text-gray-300">POPIA</strong> — Protection of Personal Information Act 4 of 2013 
                (South Africa), effective 1 July 2021
              </li>
              <li>
                <strong className="text-gray-300">Malabo Convention</strong> — African Union Convention on Cyber 
                Security and Personal Data Protection (2014)
              </li>
              <li>
                <strong className="text-gray-300">GDPR</strong> — General Data Protection Regulation (EU) 2016/679, 
                where applicable to EU/EEA data subjects
              </li>
              <li>
                <strong className="text-gray-300">Google Play Developer Policies</strong> — User Data policy, 
                Data Safety section requirements, and Families Policy
              </li>
            </ul>
            <p>
              By creating an account or using WATZHMe, you acknowledge that you have read, understood, and consent 
              to the collection and processing of your personal information as described in this policy. If you do 
              not agree with any part of this policy, please do not use the Service.
            </p>
            <div className="bg-white/5 rounded-lg p-3 mt-2">
              <p className="text-gray-400 text-xs">
                <strong className="text-gray-300">Responsible Party (POPIA):</strong> WATZHMe Lite, 
                Kimberley, Northern Cape, South Africa. Contact: watzhme@gmail.com
              </p>
            </div>
          </CollapsibleSection>

          {/* 2. Information Officer */}
          <CollapsibleSection
            id="officer"
            title="2. Information Officer (POPIA s55)"
            icon={<Users className="w-4 h-4 text-emerald-400" />}
            isOpen={openSections.has('officer')}
            onToggle={toggleSection}
          >
            <p>
              In accordance with Section 55 of the Protection of Personal Information Act (POPIA), we have 
              designated an Information Officer who is responsible for ensuring compliance with data protection 
              legislation and handling all privacy-related matters.
            </p>
            <div className="bg-white/5 rounded-lg p-4 space-y-2.5 mt-1">
              <p className="text-white text-xs font-semibold uppercase tracking-wider mb-2">Information Officer Details</p>
              <div className="flex items-center gap-2.5">
                <Mail className="w-4 h-4 text-emerald-400 flex-shrink-0" />
                <div>
                  <p className="text-gray-500 text-[10px] uppercase tracking-wider">Email</p>
                  <a href="mailto:watzhme@gmail.com" className="text-emerald-400 text-sm hover:underline">
                    watzhme@gmail.com
                  </a>
                </div>
              </div>
              <div className="flex items-center gap-2.5">
                <MapPin className="w-4 h-4 text-gray-500 flex-shrink-0" />
                <div>
                  <p className="text-gray-500 text-[10px] uppercase tracking-wider">Address</p>
                  <span className="text-gray-300 text-sm">Kimberley, Northern Cape, South Africa</span>
                </div>
              </div>
              <div className="flex items-center gap-2.5">
                <Clock className="w-4 h-4 text-gray-500 flex-shrink-0" />
                <div>
                  <p className="text-gray-500 text-[10px] uppercase tracking-wider">Response Time</p>
                  <span className="text-gray-300 text-sm">Within 30 days (as required by POPIA)</span>
                </div>
              </div>
            </div>
            <p className="text-gray-400 text-xs mt-2">
              For any privacy-related queries, data subject access requests (DSARs), objections to processing, 
              or complaints, please contact our Information Officer using the details above. You may also lodge 
              a complaint directly with the Information Regulator of South Africa.
            </p>
          </CollapsibleSection>

          {/* 3. Data We Collect */}
          <CollapsibleSection
            id="collected"
            title="3. Data We Collect"
            icon={<Database className="w-4 h-4 text-emerald-400" />}
            isOpen={openSections.has('collected')}
            onToggle={toggleSection}
          >
            <p>
              We collect and process the following categories of personal information. Each category 
              is collected for a specific, lawful purpose as outlined below.
            </p>

            <p className="font-medium text-white text-xs uppercase tracking-wider mt-3 mb-2">
              A. Account Information (Required for Service)
            </p>
            <ul className="list-disc list-inside space-y-1 text-gray-400 ml-2 mb-3">
              <li><strong className="text-gray-300">Email address</strong> — Authentication, account recovery, and essential communications</li>
              <li><strong className="text-gray-300">Username</strong> — Your unique public identity on the platform</li>
              <li><strong className="text-gray-300">Password</strong> — Stored as a bcrypt hash with salt; we never store or see your plain-text password</li>
            </ul>

            <p className="font-medium text-white text-xs uppercase tracking-wider mb-2">
              B. Profile Information (Optional, User-Provided)
            </p>
            <ul className="list-disc list-inside space-y-1 text-gray-400 ml-2 mb-3">
              <li><strong className="text-gray-300">Full name</strong> — Displayed on your public profile</li>
              <li><strong className="text-gray-300">Profile photo</strong> — Uploaded avatar image, stored in secure cloud storage</li>
              <li><strong className="text-gray-300">Bio</strong> — Short description you write about yourself (max 150 characters)</li>
            </ul>

            <p className="font-medium text-white text-xs uppercase tracking-wider mb-2">
              C. User-Generated Content
            </p>
            <ul className="list-disc list-inside space-y-1 text-gray-400 ml-2 mb-3">
              <li><strong className="text-gray-300">Photos and videos</strong> — Media you upload to share with others</li>
              <li><strong className="text-gray-300">Captions</strong> — Text content accompanying your posts</li>
              <li><strong className="text-gray-300">Comments</strong> — Text you write on other users&apos; posts</li>
              <li><strong className="text-gray-300">Direct messages</strong> — Private messages between you and other users</li>
              <li><strong className="text-gray-300">Social interactions</strong> — Likes, follows, bookmarks, and shares</li>
            </ul>

            <p className="font-medium text-white text-xs uppercase tracking-wider mb-2">
              D. Automatically Collected Data
            </p>
            <ul className="list-disc list-inside space-y-1 text-gray-400 ml-2 mb-3">
              <li><strong className="text-gray-300">Device information</strong> — Device type, operating system, and version</li>
              <li><strong className="text-gray-300">App diagnostics</strong> — Crash reports and performance data (via Sentry)</li>
              <li><strong className="text-gray-300">Usage patterns</strong> — Anonymized and aggregated interaction data</li>
            </ul>

            <div className="bg-emerald-500/5 rounded-lg p-3 border border-emerald-500/10">
              <p className="text-emerald-400 text-xs font-semibold mb-1.5">Data We Do NOT Collect</p>
              <p className="text-emerald-400/80 text-xs leading-relaxed">
                We do NOT collect: precise GPS location, contacts or address book, call logs, SMS/MMS, 
                financial or payment data, health or fitness data, browsing history, data from other apps 
                on your device, advertising identifiers, or any biometric data.
              </p>
            </div>
          </CollapsibleSection>

          {/* 4. How We Use Your Data */}
          <CollapsibleSection
            id="usage"
            title="4. How We Use Your Data"
            icon={<Eye className="w-4 h-4 text-emerald-400" />}
            isOpen={openSections.has('usage')}
            onToggle={toggleSection}
          >
            <p>
              We process your personal information strictly for the following purposes, in accordance 
              with POPIA Section 13 (purpose limitation) and Section 10 (minimality):
            </p>
            <ul className="space-y-2.5 mt-2">
              <li className="flex items-start gap-2.5">
                <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 mt-2 flex-shrink-0" />
                <div>
                  <strong className="text-gray-200 text-sm">Account Management</strong>
                  <p className="text-gray-400 text-xs mt-0.5">Create, authenticate, maintain, and secure your account</p>
                </div>
              </li>
              <li className="flex items-start gap-2.5">
                <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 mt-2 flex-shrink-0" />
                <div>
                  <strong className="text-gray-200 text-sm">Service Delivery</strong>
                  <p className="text-gray-400 text-xs mt-0.5">Display your content, enable social interactions (likes, comments, follows, messages), and deliver the core app experience</p>
                </div>
              </li>
              <li className="flex items-start gap-2.5">
                <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 mt-2 flex-shrink-0" />
                <div>
                  <strong className="text-gray-200 text-sm">Content Discovery</strong>
                  <p className="text-gray-400 text-xs mt-0.5">Show your public posts in the feed and search results for other users to discover</p>
                </div>
              </li>
              <li className="flex items-start gap-2.5">
                <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 mt-2 flex-shrink-0" />
                <div>
                  <strong className="text-gray-200 text-sm">Notifications</strong>
                  <p className="text-gray-400 text-xs mt-0.5">Alert you about likes, comments, follows, messages, and important account updates</p>
                </div>
              </li>
              <li className="flex items-start gap-2.5">
                <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 mt-2 flex-shrink-0" />
                <div>
                  <strong className="text-gray-200 text-sm">Safety & Security</strong>
                  <p className="text-gray-400 text-xs mt-0.5">Detect and prevent fraud, abuse, spam, or violations of our Terms of Service</p>
                </div>
              </li>
              <li className="flex items-start gap-2.5">
                <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 mt-2 flex-shrink-0" />
                <div>
                  <strong className="text-gray-200 text-sm">App Improvement</strong>
                  <p className="text-gray-400 text-xs mt-0.5">Analyze anonymized, aggregated usage data and crash reports to fix bugs and improve performance</p>
                </div>
              </li>
              <li className="flex items-start gap-2.5">
                <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 mt-2 flex-shrink-0" />
                <div>
                  <strong className="text-gray-200 text-sm">Legal Compliance</strong>
                  <p className="text-gray-400 text-xs mt-0.5">Comply with applicable South African laws, court orders, and regulatory requirements</p>
                </div>
              </li>
            </ul>
            <div className="bg-white/5 rounded-lg p-3 mt-3">
              <p className="text-gray-400 text-xs">
                <strong className="text-gray-300">Important:</strong> We do NOT use your data for targeted advertising, 
                behavioural profiling, automated decision-making, or selling to third parties. Your data is used 
                exclusively to provide and improve the WATZHMe service.
              </p>
            </div>
          </CollapsibleSection>

          {/* 5. Legal Basis */}
          <CollapsibleSection
            id="legal-basis"
            title="5. Legal Basis for Processing"
            icon={<FileText className="w-4 h-4 text-emerald-400" />}
            isOpen={openSections.has('legal-basis')}
            onToggle={toggleSection}
          >
            <p>Under POPIA, the Malabo Convention, and GDPR (where applicable), we process your data based on:</p>
            <ul className="space-y-2.5 mt-2">
              <li className="flex items-start gap-2.5">
                <div className="w-1.5 h-1.5 rounded-full bg-cyan-500 mt-2 flex-shrink-0" />
                <div>
                  <strong className="text-gray-200 text-sm">Consent — POPIA s11(1)(a)</strong>
                  <p className="text-gray-400 text-xs mt-0.5">
                    You provide explicit, informed consent during registration by accepting this Privacy Policy 
                    and checking the POPIA consent checkbox. You may withdraw consent at any time.
                  </p>
                </div>
              </li>
              <li className="flex items-start gap-2.5">
                <div className="w-1.5 h-1.5 rounded-full bg-cyan-500 mt-2 flex-shrink-0" />
                <div>
                  <strong className="text-gray-200 text-sm">Contractual Necessity — POPIA s11(1)(b)</strong>
                  <p className="text-gray-400 text-xs mt-0.5">
                    Processing necessary to provide the Service you requested (e.g., creating your account, 
                    displaying your posts, delivering messages).
                  </p>
                </div>
              </li>
              <li className="flex items-start gap-2.5">
                <div className="w-1.5 h-1.5 rounded-full bg-cyan-500 mt-2 flex-shrink-0" />
                <div>
                  <strong className="text-gray-200 text-sm">Legitimate Interest — POPIA s11(1)(f)</strong>
                  <p className="text-gray-400 text-xs mt-0.5">
                    Maintaining platform safety, preventing abuse, and improving the Service, balanced 
                    against your rights and interests.
                  </p>
                </div>
              </li>
              <li className="flex items-start gap-2.5">
                <div className="w-1.5 h-1.5 rounded-full bg-cyan-500 mt-2 flex-shrink-0" />
                <div>
                  <strong className="text-gray-200 text-sm">Legal Obligation — POPIA s11(1)(c)</strong>
                  <p className="text-gray-400 text-xs mt-0.5">
                    Compliance with South African law, including responding to lawful court orders or 
                    regulatory requests.
                  </p>
                </div>
              </li>
            </ul>
          </CollapsibleSection>

          {/* 6. Data Sharing */}
          <CollapsibleSection
            id="sharing"
            title="6. Data Sharing & Third Parties"
            icon={<Share2 className="w-4 h-4 text-emerald-400" />}
            isOpen={openSections.has('sharing')}
            onToggle={toggleSection}
          >
            <p>We share your data only in these strictly limited circumstances:</p>
            <ul className="space-y-2.5 mt-2">
              <li className="flex items-start gap-2.5">
                <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 mt-2 flex-shrink-0" />
                <div>
                  <strong className="text-gray-200 text-sm">Public Content (by design)</strong>
                  <p className="text-gray-400 text-xs mt-0.5">
                    Posts, profile information, comments, and follower lists are publicly visible as part 
                    of the social media experience. Direct messages are private and only visible to participants.
                  </p>
                </div>
              </li>
              <li className="flex items-start gap-2.5">
                <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 mt-2 flex-shrink-0" />
                <div>
                  <strong className="text-gray-200 text-sm">Service Providers (Data Processors)</strong>
                  <p className="text-gray-400 text-xs mt-0.5">
                    We use the following third-party services, each bound by data processing agreements:
                  </p>
                  <ul className="list-disc list-inside space-y-1 text-gray-500 text-xs ml-2 mt-1">
                    <li><strong className="text-gray-400">Supabase</strong> — Database hosting, authentication, and file storage (PostgreSQL on AWS)</li>
                    <li><strong className="text-gray-400">Sentry</strong> — Crash reporting and app diagnostics (anonymized error data only)</li>
                    <li><strong className="text-gray-400">Expo / EAS</strong> — App build and update delivery infrastructure</li>
                  </ul>
                </div>
              </li>
              <li className="flex items-start gap-2.5">
                <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 mt-2 flex-shrink-0" />
                <div>
                  <strong className="text-gray-200 text-sm">Legal Requirements</strong>
                  <p className="text-gray-400 text-xs mt-0.5">
                    When required by South African law, a valid court order, subpoena, or a lawful request 
                    from a government authority with jurisdiction.
                  </p>
                </div>
              </li>
            </ul>
            <div className="bg-emerald-500/5 rounded-lg p-3 border border-emerald-500/10 mt-3">
              <p className="text-emerald-400 text-xs font-semibold mb-1">Our Commitment</p>
              <p className="text-emerald-400/80 text-xs leading-relaxed">
                We do NOT sell, rent, lease, or trade your personal information to any third party. 
                We do NOT share data with advertisers, data brokers, or marketing companies. 
                We do NOT monetize your data in any way.
              </p>
            </div>
          </CollapsibleSection>

          {/* 7. User Rights */}
          <CollapsibleSection
            id="rights"
            title="7. Your Rights (POPIA Chapter 3)"
            icon={<Users className="w-4 h-4 text-emerald-400" />}
            isOpen={openSections.has('rights')}
            onToggle={toggleSection}
          >
            <p>
              Under POPIA, the Malabo Convention, and GDPR (where applicable), you have the following 
              enforceable rights regarding your personal information:
            </p>
            <ul className="space-y-2.5 mt-2">
              <li className="flex items-start gap-2.5">
                <CheckCircle className="w-4 h-4 text-emerald-400 mt-0.5 flex-shrink-0" />
                <div>
                  <strong className="text-gray-200 text-sm">Right of Access (POPIA s23)</strong>
                  <p className="text-gray-400 text-xs mt-0.5">
                    Request a complete copy of all personal data we hold about you, free of charge. 
                    We will provide this in a commonly used electronic format.
                  </p>
                </div>
              </li>
              <li className="flex items-start gap-2.5">
                <CheckCircle className="w-4 h-4 text-emerald-400 mt-0.5 flex-shrink-0" />
                <div>
                  <strong className="text-gray-200 text-sm">Right to Correction (POPIA s24)</strong>
                  <p className="text-gray-400 text-xs mt-0.5">
                    Request correction or updating of inaccurate, incomplete, or misleading personal data. 
                    You can also edit your profile directly within the app.
                  </p>
                </div>
              </li>
              <li className="flex items-start gap-2.5">
                <CheckCircle className="w-4 h-4 text-emerald-400 mt-0.5 flex-shrink-0" />
                <div>
                  <strong className="text-gray-200 text-sm">Right to Deletion (POPIA s24)</strong>
                  <p className="text-gray-400 text-xs mt-0.5">
                    Request deletion of your personal data and account. You can initiate this from your 
                    Profile Settings or by emailing us. Deletion is processed within 30 days.
                  </p>
                </div>
              </li>
              <li className="flex items-start gap-2.5">
                <CheckCircle className="w-4 h-4 text-emerald-400 mt-0.5 flex-shrink-0" />
                <div>
                  <strong className="text-gray-200 text-sm">Right to Object (POPIA s11(3))</strong>
                  <p className="text-gray-400 text-xs mt-0.5">
                    Object to the processing of your personal data on reasonable grounds relating to your 
                    particular situation.
                  </p>
                </div>
              </li>
              <li className="flex items-start gap-2.5">
                <CheckCircle className="w-4 h-4 text-emerald-400 mt-0.5 flex-shrink-0" />
                <div>
                  <strong className="text-gray-200 text-sm">Right to Withdraw Consent</strong>
                  <p className="text-gray-400 text-xs mt-0.5">
                    Withdraw your consent at any time. This will not affect the lawfulness of processing 
                    based on consent before its withdrawal. Note: withdrawing consent may affect your 
                    ability to use certain features of the Service.
                  </p>
                </div>
              </li>
              <li className="flex items-start gap-2.5">
                <CheckCircle className="w-4 h-4 text-emerald-400 mt-0.5 flex-shrink-0" />
                <div>
                  <strong className="text-gray-200 text-sm">Right to Data Portability</strong>
                  <p className="text-gray-400 text-xs mt-0.5">
                    Request your data in a structured, commonly used, machine-readable format (JSON/CSV) 
                    so you can transfer it to another service.
                  </p>
                </div>
              </li>
              <li className="flex items-start gap-2.5">
                <CheckCircle className="w-4 h-4 text-emerald-400 mt-0.5 flex-shrink-0" />
                <div>
                  <strong className="text-gray-200 text-sm">Right to Lodge a Complaint</strong>
                  <p className="text-gray-400 text-xs mt-0.5">
                    Lodge a complaint with the Information Regulator of South Africa if you believe your 
                    rights have been infringed.
                  </p>
                </div>
              </li>
            </ul>

            <div className="bg-white/5 rounded-lg p-3 mt-3">
              <p className="text-white text-xs font-semibold mb-2">How to Exercise Your Rights</p>
              <p className="text-gray-400 text-xs leading-relaxed">
                To exercise any of the above rights, email our Information Officer at{' '}
                <a href="mailto:watzhme@gmail.com" className="text-emerald-400 hover:underline font-medium">
                  watzhme@gmail.com
                </a>{' '}
                with the subject line &quot;Data Subject Request&quot;. Please include your username and a 
                description of your request. We will verify your identity and respond within 30 days 
                as required by POPIA.
              </p>
            </div>
          </CollapsibleSection>

          {/* 8. Security */}
          <CollapsibleSection
            id="security"
            title="8. Data Storage & Security"
            icon={<Lock className="w-4 h-4 text-emerald-400" />}
            isOpen={openSections.has('security')}
            onToggle={toggleSection}
          >
            <p>
              We implement industry-standard technical and organizational measures to protect your 
              personal information against unauthorized access, alteration, disclosure, or destruction:
            </p>
            <ul className="space-y-2 mt-2">
              <li className="flex items-start gap-2.5">
                <Server className="w-4 h-4 text-cyan-400 mt-0.5 flex-shrink-0" />
                <div>
                  <strong className="text-gray-200 text-xs">Infrastructure</strong>
                  <p className="text-gray-400 text-xs">Hosted on Supabase (backed by AWS) with enterprise-grade physical and network security, SOC 2 Type II compliance</p>
                </div>
              </li>
              <li className="flex items-start gap-2.5">
                <Lock className="w-4 h-4 text-cyan-400 mt-0.5 flex-shrink-0" />
                <div>
                  <strong className="text-gray-200 text-xs">Encryption</strong>
                  <p className="text-gray-400 text-xs">All data encrypted in transit (TLS 1.3) and at rest (AES-256). Database connections use SSL.</p>
                </div>
              </li>
              <li className="flex items-start gap-2.5">
                <Shield className="w-4 h-4 text-cyan-400 mt-0.5 flex-shrink-0" />
                <div>
                  <strong className="text-gray-200 text-xs">Authentication</strong>
                  <p className="text-gray-400 text-xs">Passwords hashed using bcrypt with per-user salt. JWT tokens with short expiry for session management.</p>
                </div>
              </li>
              <li className="flex items-start gap-2.5">
                <Database className="w-4 h-4 text-cyan-400 mt-0.5 flex-shrink-0" />
                <div>
                  <strong className="text-gray-200 text-xs">Access Control</strong>
                  <p className="text-gray-400 text-xs">Row Level Security (RLS) policies on all database tables ensure users can only access data they are authorized to see.</p>
                </div>
              </li>
              <li className="flex items-start gap-2.5">
                <Eye className="w-4 h-4 text-cyan-400 mt-0.5 flex-shrink-0" />
                <div>
                  <strong className="text-gray-200 text-xs">Monitoring</strong>
                  <p className="text-gray-400 text-xs">Automated security monitoring, crash reporting via Sentry, and regular security reviews.</p>
                </div>
              </li>
            </ul>
            <div className="bg-orange-500/5 rounded-lg p-3 border border-orange-500/10 mt-3">
              <p className="text-orange-400 text-xs font-semibold mb-1">Breach Notification</p>
              <p className="text-orange-400/80 text-xs leading-relaxed">
                While we implement robust security measures, no system is 100% secure. In the event of a 
                personal data breach, we will notify affected data subjects and the Information Regulator 
                of South Africa within 72 hours, as required by POPIA Section 22. The notification will 
                include the nature of the breach, likely consequences, and measures taken to address it.
              </p>
            </div>
          </CollapsibleSection>

          {/* 9. Data Retention */}
          <CollapsibleSection
            id="retention"
            title="9. Data Retention"
            icon={<Clock className="w-4 h-4 text-emerald-400" />}
            isOpen={openSections.has('retention')}
            onToggle={toggleSection}
          >
            <p>
              In accordance with POPIA Section 14 (retention limitation), we retain personal information 
              only for as long as necessary to fulfill the purposes for which it was collected:
            </p>
            <ul className="space-y-2 mt-2">
              <li className="flex items-start gap-2.5">
                <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 mt-2 flex-shrink-0" />
                <div>
                  <strong className="text-gray-200 text-xs">Active Account Data</strong>
                  <p className="text-gray-400 text-xs">Retained while your account is active and you continue to use the Service</p>
                </div>
              </li>
              <li className="flex items-start gap-2.5">
                <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 mt-2 flex-shrink-0" />
                <div>
                  <strong className="text-gray-200 text-xs">Deleted Account Data</strong>
                  <p className="text-gray-400 text-xs">Permanently deleted within 30 days of account deletion request</p>
                </div>
              </li>
              <li className="flex items-start gap-2.5">
                <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 mt-2 flex-shrink-0" />
                <div>
                  <strong className="text-gray-200 text-xs">User Content</strong>
                  <p className="text-gray-400 text-xs">Posts, comments, and media are deleted when you delete them individually or when your account is deleted</p>
                </div>
              </li>
              <li className="flex items-start gap-2.5">
                <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 mt-2 flex-shrink-0" />
                <div>
                  <strong className="text-gray-200 text-xs">Direct Messages</strong>
                  <p className="text-gray-400 text-xs">Retained while both participants&apos; accounts are active; deleted when either account is deleted</p>
                </div>
              </li>
              <li className="flex items-start gap-2.5">
                <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 mt-2 flex-shrink-0" />
                <div>
                  <strong className="text-gray-200 text-xs">Crash Reports</strong>
                  <p className="text-gray-400 text-xs">Anonymized diagnostic data retained for up to 90 days, then automatically purged</p>
                </div>
              </li>
              <li className="flex items-start gap-2.5">
                <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 mt-2 flex-shrink-0" />
                <div>
                  <strong className="text-gray-200 text-xs">Encrypted Backups</strong>
                  <p className="text-gray-400 text-xs">Encrypted database backups may retain data for up to 30 days after deletion before being overwritten</p>
                </div>
              </li>
            </ul>
          </CollapsibleSection>

          {/* 10. Children's Privacy */}
          <CollapsibleSection
            id="children"
            title="10. Children's Privacy"
            icon={<Baby className="w-4 h-4 text-emerald-400" />}
            isOpen={openSections.has('children')}
            onToggle={toggleSection}
          >
            <p>
              WATZHMe is not directed at or intended for use by children under the age of 13. We do not 
              knowingly collect personal information from children under 13 years of age.
            </p>
            <p>
              If you are a parent or guardian and believe your child has provided us with personal 
              information without your consent, please contact us immediately at{' '}
              <a href="mailto:watzhme@gmail.com" className="text-emerald-400 hover:underline">
                watzhme@gmail.com
              </a>
              . We will take steps to promptly delete such information from our systems.
            </p>
            <p>
              Users between the ages of 13 and 18 should obtain parental or guardian consent before 
              creating an account, in accordance with POPIA Section 35 (processing of personal 
              information of children).
            </p>
            <div className="bg-white/5 rounded-lg p-3 mt-1">
              <p className="text-gray-400 text-xs">
                <strong className="text-gray-300">Google Play Families Policy:</strong> WATZHMe is rated for 
                users aged 13+ and does not participate in the Google Play Designed for Families program. 
                The app does not contain ads or in-app purchases directed at children.
              </p>
            </div>
          </CollapsibleSection>

          {/* 11. International Transfers */}
          <CollapsibleSection
            id="transfers"
            title="11. International Data Transfers"
            icon={<Plane className="w-4 h-4 text-emerald-400" />}
            isOpen={openSections.has('transfers')}
            onToggle={toggleSection}
          >
            <p>
              Our service infrastructure (Supabase/AWS) may process and store data in regions outside 
              of South Africa. In accordance with POPIA Section 72 (transborder information flows), 
              we ensure that any cross-border transfer of personal information is subject to at least 
              one of the following safeguards:
            </p>
            <ul className="list-disc list-inside space-y-1.5 text-gray-400 ml-2 mt-2">
              <li>The recipient country has adequate data protection laws recognized by the Information Regulator</li>
              <li>Binding contractual obligations (Data Processing Agreements) provide equivalent protection</li>
              <li>The transfer is necessary for the performance of the contract between you and WATZHMe</li>
              <li>You have provided explicit consent to the transfer</li>
            </ul>
            <p className="text-gray-400 text-xs mt-3">
              Our primary hosting provider (Supabase/AWS) maintains SOC 2 Type II compliance, ISO 27001 
              certification, and adheres to international data protection standards including EU Standard 
              Contractual Clauses (SCCs).
            </p>
          </CollapsibleSection>

          {/* 12. Changes */}
          <CollapsibleSection
            id="changes"
            title="12. Changes to This Policy"
            icon={<Bell className="w-4 h-4 text-emerald-400" />}
            isOpen={openSections.has('changes')}
            onToggle={toggleSection}
          >
            <p>
              We may update this Privacy Policy from time to time to reflect changes in our practices, 
              technology, legal requirements, or other factors. When we make changes:
            </p>
            <ul className="list-disc list-inside space-y-1.5 text-gray-400 ml-2 mt-2">
              <li>We will update the &quot;Effective&quot; and &quot;Reviewed&quot; dates at the top of this policy</li>
              <li>We will increment the version number</li>
              <li>For <strong className="text-gray-300">material changes</strong>, we will notify you via in-app notification or email at least 14 days before the changes take effect</li>
              <li>If changes affect how we process your data, we will request renewed consent</li>
            </ul>
            <p className="text-gray-400 text-xs mt-2">
              Continued use of the Service after the effective date of changes constitutes your acceptance 
              of the updated policy. If you do not agree with the changes, you should stop using the 
              Service and may request deletion of your account and data.
            </p>
          </CollapsibleSection>

          {/* 13. Malabo Convention */}
          <CollapsibleSection
            id="malabo"
            title="13. Malabo Convention Compliance"
            icon={<Globe className="w-4 h-4 text-emerald-400" />}
            isOpen={openSections.has('malabo')}
            onToggle={toggleSection}
          >
            <p>
              In addition to POPIA, WATZHMe is committed to compliance with the African Union Convention 
              on Cyber Security and Personal Data Protection (the &quot;Malabo Convention&quot;, adopted 27 June 2014), 
              which establishes a harmonized framework for data protection across Africa:
            </p>
            <ul className="space-y-2 mt-2">
              <li className="flex items-start gap-2.5">
                <div className="w-1.5 h-1.5 rounded-full bg-cyan-500 mt-2 flex-shrink-0" />
                <div>
                  <strong className="text-gray-200 text-xs">Data Minimization (Art. 13)</strong>
                  <p className="text-gray-400 text-xs">We collect only the minimum data necessary for the Service to function</p>
                </div>
              </li>
              <li className="flex items-start gap-2.5">
                <div className="w-1.5 h-1.5 rounded-full bg-cyan-500 mt-2 flex-shrink-0" />
                <div>
                  <strong className="text-gray-200 text-xs">Purpose Limitation (Art. 13)</strong>
                  <p className="text-gray-400 text-xs">Data is used only for the specific, stated purposes described in this policy</p>
                </div>
              </li>
              <li className="flex items-start gap-2.5">
                <div className="w-1.5 h-1.5 rounded-full bg-cyan-500 mt-2 flex-shrink-0" />
                <div>
                  <strong className="text-gray-200 text-xs">Transparency (Art. 14)</strong>
                  <p className="text-gray-400 text-xs">This policy clearly and comprehensively explains all data practices in plain language</p>
                </div>
              </li>
              <li className="flex items-start gap-2.5">
                <div className="w-1.5 h-1.5 rounded-full bg-cyan-500 mt-2 flex-shrink-0" />
                <div>
                  <strong className="text-gray-200 text-xs">Security (Art. 16)</strong>
                  <p className="text-gray-400 text-xs">Appropriate technical and organizational measures protect personal data</p>
                </div>
              </li>
              <li className="flex items-start gap-2.5">
                <div className="w-1.5 h-1.5 rounded-full bg-cyan-500 mt-2 flex-shrink-0" />
                <div>
                  <strong className="text-gray-200 text-xs">Accountability (Art. 17)</strong>
                  <p className="text-gray-400 text-xs">We maintain records of processing activities and can demonstrate compliance</p>
                </div>
              </li>
              <li className="flex items-start gap-2.5">
                <div className="w-1.5 h-1.5 rounded-full bg-cyan-500 mt-2 flex-shrink-0" />
                <div>
                  <strong className="text-gray-200 text-xs">Cross-border Protection (Art. 14(6))</strong>
                  <p className="text-gray-400 text-xs">International transfers are subject to adequate safeguards</p>
                </div>
              </li>
            </ul>
          </CollapsibleSection>

          {/* 14. Google Play Data Safety */}
          <CollapsibleSection
            id="data-safety"
            title="14. Google Play Data Safety Declaration"
            icon={<Shield className="w-4 h-4 text-emerald-400" />}
            isOpen={openSections.has('data-safety')}
            onToggle={toggleSection}
          >
            <p>
              The following declaration corresponds to the Google Play Data Safety section and accurately 
              reflects our data practices:
            </p>

            <div className="mt-3 space-y-0 rounded-lg overflow-hidden border border-white/10">
              <DataRow
                label="Email Address"
                value="Used for authentication, account recovery, and essential service communications"
                collected={true}
                shared={false}
                purpose="Account management, Authentication"
              />
              <DataRow
                label="Username"
                value="Your unique public identity on WATZHMe"
                collected={true}
                shared={false}
                purpose="App functionality, Account management"
              />
              <DataRow
                label="Name"
                value="Optional display name shown on your profile"
                collected={true}
                shared={false}
                purpose="App functionality, Personalization"
              />
              <DataRow
                label="Profile Photo"
                value="Optional avatar image uploaded by you"
                collected={true}
                shared={false}
                purpose="App functionality, Personalization"
              />
              <DataRow
                label="Photos & Videos"
                value="Media content you choose to upload and share"
                collected={true}
                shared={false}
                purpose="App functionality (content sharing)"
              />
              <DataRow
                label="Messages"
                value="Private direct messages between users"
                collected={true}
                shared={false}
                purpose="App functionality (messaging)"
              />
              <DataRow
                label="Social Interactions"
                value="Likes, comments, follows, bookmarks"
                collected={true}
                shared={false}
                purpose="App functionality (social features)"
              />
              <DataRow
                label="Crash Logs"
                value="Anonymized crash reports and diagnostics via Sentry"
                collected={true}
                shared={true}
                purpose="App diagnostics, Performance monitoring"
              />
              <DataRow
                label="Device Info"
                value="Device type and OS version (for crash reports only)"
                collected={true}
                shared={true}
                purpose="App diagnostics"
              />
              <DataRow
                label="Location"
                value="We do NOT collect any location data"
                collected={false}
                shared={false}
                purpose="N/A"
              />
              <DataRow
                label="Financial Info"
                value="We do NOT collect any financial or payment data"
                collected={false}
                shared={false}
                purpose="N/A"
              />
              <DataRow
                label="Contacts"
                value="We do NOT access your contacts or address book"
                collected={false}
                shared={false}
                purpose="N/A"
              />
            </div>

            <div className="bg-white/5 rounded-lg p-3 mt-3 space-y-2">
              <div className="flex items-start gap-2">
                <CheckCircle className="w-3.5 h-3.5 text-emerald-400 mt-0.5 flex-shrink-0" />
                <span className="text-gray-300 text-xs">Data is encrypted in transit (TLS 1.3) and at rest (AES-256)</span>
              </div>
              <div className="flex items-start gap-2">
                <CheckCircle className="w-3.5 h-3.5 text-emerald-400 mt-0.5 flex-shrink-0" />
                <span className="text-gray-300 text-xs">Users can request data deletion via app settings or email</span>
              </div>
              <div className="flex items-start gap-2">
                <CheckCircle className="w-3.5 h-3.5 text-emerald-400 mt-0.5 flex-shrink-0" />
                <span className="text-gray-300 text-xs">No data is shared with third parties for advertising or marketing</span>
              </div>
              <div className="flex items-start gap-2">
                <CheckCircle className="w-3.5 h-3.5 text-emerald-400 mt-0.5 flex-shrink-0" />
                <span className="text-gray-300 text-xs">No data is sold to third parties</span>
              </div>
              <div className="flex items-start gap-2">
                <CheckCircle className="w-3.5 h-3.5 text-emerald-400 mt-0.5 flex-shrink-0" />
                <span className="text-gray-300 text-xs">App complies with Google Play Families Policy (13+ age rating)</span>
              </div>
            </div>
          </CollapsibleSection>

          {/* 15. Contact */}
          <CollapsibleSection
            id="contact"
            title="15. Contact Information"
            icon={<Mail className="w-4 h-4 text-emerald-400" />}
            isOpen={openSections.has('contact')}
            onToggle={toggleSection}
          >
            <p>
              If you have any questions, concerns, or requests regarding this Privacy Policy or our 
              data practices, please contact us:
            </p>
            <div className="bg-white/5 rounded-lg p-4 space-y-3 mt-2">
              <div className="flex items-center gap-3">
                <Mail className="w-4 h-4 text-emerald-400 flex-shrink-0" />
                <div>
                  <p className="text-gray-500 text-[10px] uppercase tracking-wider">Email</p>
                  <a href="mailto:watzhme@gmail.com" className="text-emerald-400 text-sm hover:underline font-medium">
                    watzhme@gmail.com
                  </a>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <MapPin className="w-4 h-4 text-gray-500 flex-shrink-0" />
                <div>
                  <p className="text-gray-500 text-[10px] uppercase tracking-wider">Physical Address</p>
                  <span className="text-gray-300 text-sm">Kimberley, Northern Cape, South Africa</span>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <FileText className="w-4 h-4 text-gray-500 flex-shrink-0" />
                <div>
                  <p className="text-gray-500 text-[10px] uppercase tracking-wider">Subject Line for Requests</p>
                  <span className="text-gray-300 text-sm">&quot;Data Subject Request — [Your Username]&quot;</span>
                </div>
              </div>
            </div>

            <div className="mt-3 pt-3 border-t border-white/5">
              <p className="text-gray-400 text-xs font-medium mb-2">Information Regulator (South Africa)</p>
              <p className="text-gray-500 text-xs leading-relaxed">
                If you are not satisfied with our response to your privacy concern, you have the right 
                to lodge a complaint with the Information Regulator:
              </p>
              <div className="bg-white/5 rounded-lg p-3 mt-2 space-y-1.5">
                <a
                  href="https://inforegulator.org.za"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-2 text-emerald-400 text-xs hover:underline"
                >
                  <ExternalLink className="w-3 h-3 flex-shrink-0" />
                  <span>inforegulator.org.za</span>
                </a>
                <p className="text-gray-500 text-xs">
                  Email: complaints.IR@justice.gov.za
                </p>
                <p className="text-gray-500 text-xs">
                  Tel: +27 (0)10 023 5207
                </p>
              </div>
            </div>
          </CollapsibleSection>
        </div>

        {/* Footer */}
        <div className="text-center pt-6 pb-4 space-y-1">
          <p className="text-gray-600 text-[10px]">
            WATZHMe Lite v1.0.0 | Privacy Policy v{policyVersion}
          </p>
          <p className="text-gray-600 text-[10px]">
            Effective {effectiveDate} | Kimberley, Northern Cape, South Africa
          </p>
          <p className="text-gray-700 text-[10px] mt-1">
            &copy; 2026 WATZHMe. All rights reserved.
          </p>
        </div>
      </div>
    </div>
  );
};

export default PrivacyPolicy;
