import React, { useState, useEffect, useRef, useCallback } from 'react';
import { Search, TrendingUp, Hash, X, Play, Heart, Users, FileText, Flame, UserPlus, UserCheck, Sparkles } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useAuthStore } from '@/stores/authStore';
import { useFeedStore, type Post } from '@/stores/feedStore';

interface SearchScreenProps {
  onPostClick?: (post: Post) => void;
  onProfileClick?: (userId: string) => void;
}

interface SuggestedUser {
  id: string;
  username: string;
  full_name: string | null;
  avatar_url: string | null;
  bio: string | null;
  followers_count: number;
}

const SearchScreen: React.FC<SearchScreenProps> = ({ onPostClick, onProfileClick }) => {
  const { user, isAuthenticated } = useAuthStore();
  const { followingUsers, toggleFollow } = useFeedStore();
  const [query, setQuery] = useState('');
  const [trendingPosts, setTrendingPosts] = useState<Post[]>([]);
  const [recentPosts, setRecentPosts] = useState<Post[]>([]);
  const [suggestedUsers, setSuggestedUsers] = useState<SuggestedUser[]>([]);
  const [userResults, setUserResults] = useState<any[]>([]);
  const [postResults, setPostResults] = useState<Post[]>([]);
  const [loading, setLoading] = useState(true);
  const [loadingSuggested, setLoadingSuggested] = useState(false);
  const [searching, setSearching] = useState(false);
  const [searchTab, setSearchTab] = useState<'all' | 'users' | 'posts'>('all');
  const [followingInProgress, setFollowingInProgress] = useState<Set<string>>(new Set());
  const debounceRef = useRef<NodeJS.Timeout | null>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    loadTrending();
    if (isAuthenticated && user?.id) {
      loadSuggestedUsers();
    }
  }, [isAuthenticated, user?.id]);

  const loadTrending = async () => {
    setLoading(true);
    try {
      const [trendingRes, recentRes] = await Promise.all([
        supabase
          .from('posts')
          .select('*, profiles(id, username, avatar_url)')
          .order('likes_count', { ascending: false })
          .limit(12),
        supabase
          .from('posts')
          .select('*, profiles(id, username, avatar_url)')
          .order('created_at', { ascending: false })
          .limit(6),
      ]);
      if (trendingRes.data) setTrendingPosts(trendingRes.data as Post[]);
      if (recentRes.data) setRecentPosts(recentRes.data as Post[]);
    } catch (err) {
      console.error('[Search] Load trending error:', err);
    }
    setLoading(false);
  };

  const loadSuggestedUsers = async () => {
    if (!user?.id) return;
    setLoadingSuggested(true);
    try {
      // Get who the user already follows
      const { data: currentFollowing } = await supabase
        .from('follows')
        .select('following_id')
        .eq('follower_id', user.id);

      const followingIds = (currentFollowing || []).map((f: any) => f.following_id);
      followingIds.push(user.id); // Exclude self

      // Get profiles not in following list
      const { data: profiles } = await supabase
        .from('profiles')
        .select('id, username, full_name, avatar_url, bio')
        .not('id', 'in', `(${followingIds.join(',')})`)
        .limit(10);

      if (profiles && profiles.length > 0) {
        // Get follower counts
        const withCounts = await Promise.all(
          profiles.map(async (p: any) => {
            const { count } = await supabase
              .from('follows')
              .select('id', { count: 'exact', head: true })
              .eq('following_id', p.id);
            return { ...p, followers_count: count || 0 };
          })
        );
        withCounts.sort((a, b) => b.followers_count - a.followers_count);
        setSuggestedUsers(withCounts);
      }
    } catch (err) {
      console.error('[Search] Load suggested error:', err);
    }
    setLoadingSuggested(false);
  };

  const performSearch = useCallback(async (text: string) => {
    if (!text.trim()) {
      setUserResults([]);
      setPostResults([]);
      setSearching(false);
      return;
    }

    setSearching(true);
    console.log('[Search] Searching for:', text);

    try {
      const [usersRes, postsRes] = await Promise.all([
        supabase
          .from('profiles')
          .select('*')
          .or(`username.ilike.%${text}%,full_name.ilike.%${text}%`)
          .limit(20),
        supabase
          .from('posts')
          .select('*, profiles(id, username, avatar_url)')
          .ilike('caption', `%${text}%`)
          .order('likes_count', { ascending: false })
          .limit(20),
      ]);

      if (usersRes.data) setUserResults(usersRes.data);
      if (postsRes.data) setPostResults(postsRes.data as Post[]);
    } catch (err) {
      console.error('[Search] Search error:', err);
    }
    setSearching(false);
  }, []);

  const handleSearch = (text: string) => {
    setQuery(text);
    if (debounceRef.current) clearTimeout(debounceRef.current);
    debounceRef.current = setTimeout(() => {
      performSearch(text);
    }, 400);
  };

  const clearSearch = () => {
    setQuery('');
    setUserResults([]);
    setPostResults([]);
    inputRef.current?.focus();
  };

  const handleFollow = async (targetUserId: string) => {
    if (!isAuthenticated || !user?.id) return;
    setFollowingInProgress(prev => new Set(prev).add(targetUserId));
    await toggleFollow(targetUserId, user.id);
    setFollowingInProgress(prev => {
      const next = new Set(prev);
      next.delete(targetUserId);
      return next;
    });
  };

  const handleDismissSuggested = (userId: string) => {
    setSuggestedUsers(prev => prev.filter(u => u.id !== userId));
  };

  const trendingTags = [
    { tag: 'ShareEveryMoment', color: 'from-emerald-500 to-cyan-500' },
    { tag: 'WATZHMe', color: 'from-purple-500 to-pink-500' },
    { tag: 'CapeTown', color: 'from-blue-500 to-cyan-500' },
    { tag: 'SouthAfrica', color: 'from-green-500 to-yellow-500' },
    { tag: 'Kimberley', color: 'from-orange-500 to-red-500' },
    { tag: 'StreetStyle', color: 'from-pink-500 to-purple-500' },
    { tag: 'NightLife', color: 'from-indigo-500 to-blue-500' },
    { tag: 'GoldenHour', color: 'from-yellow-500 to-orange-500' },
    { tag: 'Vibes', color: 'from-cyan-500 to-emerald-500' },
    { tag: 'Creative', color: 'from-red-500 to-pink-500' },
  ];

  const isSearching = query.trim().length > 0;

  return (
    <div className="h-full w-full bg-black flex flex-col overflow-hidden">
      {/* Search bar */}
      <div className="px-4 pt-4 pb-2 sticky top-0 bg-black z-10">
        <div className="relative">
          <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
          <input
            ref={inputRef}
            type="text"
            value={query}
            onChange={(e) => handleSearch(e.target.value)}
            placeholder="Search users, posts, captions..."
            className="w-full bg-white/5 border border-white/10 rounded-xl pl-10 pr-10 py-3 text-white text-sm placeholder-gray-600 outline-none focus:border-emerald-500/50 focus:ring-1 focus:ring-emerald-500/20 transition-all"
          />
          {query && (
            <button
              onClick={clearSearch}
              className="absolute right-3 top-1/2 -translate-y-1/2 p-0.5 hover:bg-white/10 rounded-full"
            >
              <X className="w-4 h-4 text-gray-400" />
            </button>
          )}
        </div>

        {/* Search tabs when searching */}
        {isSearching && (
          <div className="flex gap-2 mt-3">
            {[
              { key: 'all' as const, label: 'All', icon: Search },
              { key: 'users' as const, label: 'Users', icon: Users },
              { key: 'posts' as const, label: 'Posts', icon: FileText },
            ].map(tab => (
              <button
                key={tab.key}
                onClick={() => setSearchTab(tab.key)}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-medium transition-all ${
                  searchTab === tab.key
                    ? 'bg-emerald-500 text-white'
                    : 'bg-white/5 text-gray-400 hover:bg-white/10'
                }`}
              >
                <tab.icon className="w-3 h-3" />
                {tab.label}
              </button>
            ))}
          </div>
        )}
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto pb-20 scrollbar-hide">
        {isSearching ? (
          /* Search Results */
          <div className="px-4">
            {searching ? (
              <div className="flex items-center justify-center py-12">
                <div className="w-6 h-6 border-2 border-emerald-400 border-t-transparent rounded-full animate-spin" />
              </div>
            ) : (
              <>
                {/* Users section */}
                {(searchTab === 'all' || searchTab === 'users') && userResults.length > 0 && (
                  <div className="mb-6">
                    {searchTab === 'all' && (
                      <div className="flex items-center gap-2 mb-3">
                        <Users className="w-4 h-4 text-emerald-400" />
                        <span className="text-white text-sm font-semibold">Users</span>
                        <span className="text-gray-600 text-xs">({userResults.length})</span>
                      </div>
                    )}
                    <div className="space-y-1">
                      {userResults.map((searchUser) => {
                        const isFollowingThis = followingUsers.has(searchUser.id);
                        const isMe = searchUser.id === user?.id;
                        return (
                          <div
                            key={searchUser.id}
                            className="w-full flex items-center gap-3 p-3 rounded-xl hover:bg-white/5 transition-colors"
                          >
                            <button
                              onClick={() => onProfileClick?.(searchUser.id)}
                              className="flex items-center gap-3 flex-1 min-w-0"
                            >
                              <div className="w-11 h-11 rounded-full overflow-hidden bg-gray-800 flex-shrink-0">
                                {searchUser.avatar_url ? (
                                  <img src={searchUser.avatar_url} className="w-full h-full object-cover" alt="" />
                                ) : (
                                  <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-emerald-500 to-cyan-500 text-white font-bold">
                                    {searchUser.username?.[0]?.toUpperCase() || '?'}
                                  </div>
                                )}
                              </div>
                              <div className="text-left min-w-0">
                                <p className="text-white text-sm font-semibold truncate">@{searchUser.username}</p>
                                {searchUser.full_name && (
                                  <p className="text-gray-500 text-xs truncate">{searchUser.full_name}</p>
                                )}
                              </div>
                            </button>
                            {/* Follow button */}
                            {isAuthenticated && !isMe && (
                              <button
                                onClick={() => handleFollow(searchUser.id)}
                                disabled={followingInProgress.has(searchUser.id)}
                                className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-all active:scale-95 flex-shrink-0 flex items-center gap-1 ${
                                  isFollowingThis
                                    ? 'bg-white/10 text-gray-300 hover:bg-white/15'
                                    : 'bg-emerald-500 text-white hover:bg-emerald-400'
                                }`}
                              >
                                {followingInProgress.has(searchUser.id) ? (
                                  <div className="w-3 h-3 border-2 border-current border-t-transparent rounded-full animate-spin" />
                                ) : isFollowingThis ? (
                                  <UserCheck className="w-3 h-3" />
                                ) : (
                                  <UserPlus className="w-3 h-3" />
                                )}
                                {isFollowingThis ? 'Following' : 'Follow'}
                              </button>
                            )}
                          </div>
                        );
                      })}
                    </div>
                  </div>
                )}

                {/* Posts section */}
                {(searchTab === 'all' || searchTab === 'posts') && postResults.length > 0 && (
                  <div className="mb-6">
                    {searchTab === 'all' && (
                      <div className="flex items-center gap-2 mb-3">
                        <FileText className="w-4 h-4 text-cyan-400" />
                        <span className="text-white text-sm font-semibold">Posts</span>
                        <span className="text-gray-600 text-xs">({postResults.length})</span>
                      </div>
                    )}
                    <div className="grid grid-cols-3 gap-0.5">
                      {postResults.map((post) => (
                        <PostGridItem key={post.id} post={post} onClick={() => onPostClick?.(post)} />
                      ))}
                    </div>
                  </div>
                )}

                {/* No results */}
                {userResults.length === 0 && postResults.length === 0 && !searching && (
                  <div className="text-center py-16">
                    <Search className="w-12 h-12 text-gray-700 mx-auto mb-3" />
                    <p className="text-gray-500 text-sm">No results for "{query}"</p>
                    <p className="text-gray-700 text-xs mt-1">Try different keywords</p>
                  </div>
                )}
              </>
            )}
          </div>
        ) : (
          /* Discover content */
          <>
            {/* Suggested Users (for logged-in users) */}
            {isAuthenticated && suggestedUsers.length > 0 && (
              <div className="px-1 mb-5">
                <div className="flex items-center gap-2 px-3 mb-3">
                  <Sparkles className="w-4 h-4 text-yellow-400" />
                  <span className="text-white text-sm font-semibold">Suggested for you</span>
                </div>
                <div className="flex gap-3 overflow-x-auto px-3 scrollbar-hide pb-1">
                  {suggestedUsers.slice(0, 8).map((sugUser) => {
                    const isFollowingThis = followingUsers.has(sugUser.id);
                    return (
                      <div
                        key={sugUser.id}
                        className="flex-shrink-0 w-36 bg-white/5 rounded-2xl p-3 border border-white/5 relative group"
                      >
                        {/* Dismiss button */}
                        <button
                          onClick={() => handleDismissSuggested(sugUser.id)}
                          className="absolute top-2 right-2 p-0.5 hover:bg-white/10 rounded-full opacity-0 group-hover:opacity-100 transition-opacity"
                        >
                          <X className="w-3 h-3 text-gray-500" />
                        </button>

                        <button
                          onClick={() => onProfileClick?.(sugUser.id)}
                          className="flex flex-col items-center w-full"
                        >
                          <div className="w-14 h-14 rounded-full overflow-hidden bg-gray-800 mb-2 ring-2 ring-emerald-500/20">
                            {sugUser.avatar_url ? (
                              <img src={sugUser.avatar_url} className="w-full h-full object-cover" alt="" />
                            ) : (
                              <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-emerald-500 to-cyan-500 text-white font-bold text-lg">
                                {sugUser.username[0]?.toUpperCase()}
                              </div>
                            )}
                          </div>
                          <p className="text-white text-xs font-semibold truncate w-full text-center">@{sugUser.username}</p>
                          {sugUser.full_name && (
                            <p className="text-gray-500 text-[10px] truncate w-full text-center">{sugUser.full_name}</p>
                          )}
                          {sugUser.followers_count > 0 && (
                            <p className="text-gray-600 text-[9px] mt-0.5">{sugUser.followers_count} followers</p>
                          )}
                        </button>

                        <button
                          onClick={() => handleFollow(sugUser.id)}
                          disabled={followingInProgress.has(sugUser.id)}
                          className={`w-full mt-2 py-1.5 text-[10px] font-semibold rounded-lg transition-all active:scale-95 flex items-center justify-center gap-1 ${
                            isFollowingThis
                              ? 'bg-white/10 text-gray-300'
                              : 'bg-emerald-500 text-white hover:bg-emerald-400'
                          }`}
                        >
                          {followingInProgress.has(sugUser.id) ? (
                            <div className="w-2.5 h-2.5 border border-current border-t-transparent rounded-full animate-spin" />
                          ) : isFollowingThis ? (
                            <>
                              <UserCheck className="w-2.5 h-2.5" />
                              Following
                            </>
                          ) : (
                            <>
                              <UserPlus className="w-2.5 h-2.5" />
                              Follow
                            </>
                          )}
                        </button>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

            {/* Trending tags */}
            <div className="px-4 mb-5">
              <div className="flex items-center gap-2 mb-3">
                <Flame className="w-4 h-4 text-orange-400" />
                <span className="text-white text-sm font-semibold">Trending Tags</span>
              </div>
              <div className="flex flex-wrap gap-2">
                {trendingTags.map(({ tag, color }) => (
                  <button
                    key={tag}
                    onClick={() => handleSearch(tag)}
                    className="flex items-center gap-1.5 px-3 py-1.5 bg-white/5 rounded-full hover:bg-white/10 transition-colors group"
                  >
                    <div className={`w-4 h-4 rounded-full bg-gradient-to-br ${color} flex items-center justify-center`}>
                      <Hash className="w-2.5 h-2.5 text-white" />
                    </div>
                    <span className="text-gray-300 text-xs group-hover:text-white transition-colors">{tag}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Recent posts */}
            {recentPosts.length > 0 && (
              <div className="px-1 mb-5">
                <div className="flex items-center gap-2 px-3 mb-3">
                  <TrendingUp className="w-4 h-4 text-cyan-400" />
                  <span className="text-white text-sm font-semibold">New & Fresh</span>
                </div>
                <div className="flex gap-2 overflow-x-auto px-3 scrollbar-hide">
                  {recentPosts.map((post) => (
                    <button
                      key={post.id}
                      onClick={() => onPostClick?.(post)}
                      className="flex-shrink-0 w-32 rounded-xl overflow-hidden relative group"
                    >
                      <div className="aspect-[3/4]">
                        <img
                          src={post.thumbnail_url || post.media_url}
                          alt=""
                          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                        />
                      </div>
                      <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-transparent" />
                      <div className="absolute bottom-2 left-2 right-2">
                        <p className="text-white text-[10px] font-medium truncate">@{post.profiles?.username}</p>
                      </div>
                      {post.media_type === 'video' && (
                        <div className="absolute top-2 right-2 w-5 h-5 rounded-full bg-black/50 flex items-center justify-center">
                          <Play className="w-3 h-3 text-white" fill="white" />
                        </div>
                      )}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Trending posts grid */}
            <div className="px-1">
              <div className="flex items-center gap-2 px-3 mb-3">
                <TrendingUp className="w-4 h-4 text-emerald-400" />
                <span className="text-white text-sm font-semibold">Popular</span>
              </div>
              {loading ? (
                <div className="flex items-center justify-center py-12">
                  <div className="w-6 h-6 border-2 border-emerald-400 border-t-transparent rounded-full animate-spin" />
                </div>
              ) : trendingPosts.length === 0 ? (
                <div className="text-center py-12">
                  <TrendingUp className="w-10 h-10 text-gray-700 mx-auto mb-3" />
                  <p className="text-gray-500 text-sm">No posts yet</p>
                  <p className="text-gray-700 text-xs mt-1">Be the first to share!</p>
                </div>
              ) : (
                <div className="grid grid-cols-3 gap-0.5">
                  {trendingPosts.map((post, index) => {
                    const isLarge = index === 0 || index === 5;
                    return (
                      <button
                        key={post.id}
                        onClick={() => onPostClick?.(post)}
                        className={`overflow-hidden relative group ${
                          isLarge ? 'col-span-2 row-span-2 aspect-square' : 'aspect-[3/4]'
                        }`}
                      >
                        <img
                          src={post.thumbnail_url || post.media_url}
                          alt={post.caption}
                          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                        />
                        <div className="absolute inset-0 bg-black/0 group-hover:bg-black/30 transition-colors flex items-center justify-center opacity-0 group-hover:opacity-100">
                          <div className="flex items-center gap-1 text-white text-sm font-semibold">
                            <Heart className="w-4 h-4 fill-white" />
                            <span>{post.likes_count}</span>
                          </div>
                        </div>
                        {post.media_type === 'video' && (
                          <div className="absolute top-2 right-2 w-5 h-5 rounded-full bg-black/50 flex items-center justify-center">
                            <Play className="w-3 h-3 text-white" fill="white" />
                          </div>
                        )}
                      </button>
                    );
                  })}
                </div>
              )}
            </div>
          </>
        )}
      </div>
    </div>
  );
};

// Post grid item for search results
const PostGridItem: React.FC<{ post: Post; onClick: () => void }> = ({ post, onClick }) => (
  <button
    onClick={onClick}
    className="aspect-[3/4] overflow-hidden relative group bg-gray-900"
  >
    <img
      src={post.thumbnail_url || post.media_url}
      alt=""
      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
    />
    <div className="absolute inset-0 bg-black/0 group-hover:bg-black/30 transition-colors" />
    {post.media_type === 'video' && (
      <div className="absolute top-1.5 right-1.5 w-4 h-4 rounded-full bg-black/50 flex items-center justify-center">
        <Play className="w-2.5 h-2.5 text-white" fill="white" />
      </div>
    )}
    <div className="absolute bottom-1 left-1 flex items-center gap-1">
      <Heart className="w-3 h-3 text-white fill-white" />
      <span className="text-white text-[9px] font-medium">{post.likes_count}</span>
    </div>
  </button>
);

export default SearchScreen;
