import React from 'react';
import { Home, Search, Plus, MessageCircle, User } from 'lucide-react';
import { useMessageStore } from '@/stores/messageStore';
import { useNotificationStore } from '@/stores/notificationStore';

export type TabName = 'home' | 'search' | 'create' | 'inbox' | 'profile';

interface BottomNavProps {
  activeTab: TabName;
  onTabChange: (tab: TabName) => void;
  isAuthenticated: boolean;
}

const BottomNav: React.FC<BottomNavProps> = ({ activeTab, onTabChange, isAuthenticated }) => {
  const totalUnreadMessages = useMessageStore(s => s.totalUnread);
  const totalUnreadNotifs = useNotificationStore(s => s.unreadCount);
  const totalInboxBadge = totalUnreadMessages + totalUnreadNotifs;

  const tabs: { name: TabName; icon: React.FC<any>; label: string; requiresAuth: boolean; badge?: number }[] = [
    { name: 'home', icon: Home, label: 'Home', requiresAuth: false },
    { name: 'search', icon: Search, label: 'Discover', requiresAuth: false },
    { name: 'create', icon: Plus, label: '', requiresAuth: true },
    { name: 'inbox', icon: MessageCircle, label: 'Inbox', requiresAuth: true, badge: totalInboxBadge },
    { name: 'profile', icon: User, label: 'Profile', requiresAuth: true },
  ];

  return (
    <div className="fixed bottom-0 left-0 right-0 z-50">
      <div className="bg-black/95 backdrop-blur-xl border-t border-white/5">
        <div className="max-w-lg mx-auto flex items-center justify-around px-2 py-1.5">
          {tabs.map((tab) => {
            const isActive = activeTab === tab.name;
            const isCenter = tab.name === 'create';
            const Icon = tab.icon;

            if (isCenter) {
              return (
                <button
                  key={tab.name}
                  onClick={() => {
                    if (!isAuthenticated) {
                      onTabChange('profile');
                      return;
                    }
                    onTabChange(tab.name);
                  }}
                  className="relative -mt-5 group"
                >
                  <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-emerald-400 to-cyan-400 flex items-center justify-center shadow-lg shadow-emerald-500/30 group-hover:shadow-emerald-500/50 transition-all duration-200 group-active:scale-90">
                    <Plus className="w-7 h-7 text-black" strokeWidth={3} />
                  </div>
                </button>
              );
            }

            return (
              <button
                key={tab.name}
                onClick={() => {
                  if (tab.requiresAuth && !isAuthenticated) {
                    onTabChange('profile');
                    return;
                  }
                  onTabChange(tab.name);
                }}
                className={`relative flex flex-col items-center py-1.5 px-3 transition-all duration-200 ${
                  isActive ? 'opacity-100' : 'opacity-50 hover:opacity-75'
                }`}
              >
                <div className="relative">
                  <Icon
                    className={`w-6 h-6 ${isActive ? 'text-white' : 'text-gray-400'}`}
                    strokeWidth={isActive ? 2.5 : 1.8}
                  />
                  {/* Badge */}
                  {tab.badge && tab.badge > 0 && isAuthenticated && (
                    <span className="absolute -top-1.5 -right-2 min-w-[16px] h-4 px-1 bg-red-500 rounded-full flex items-center justify-center">
                      <span className="text-[9px] text-white font-bold leading-none">
                        {tab.badge > 99 ? '99+' : tab.badge}
                      </span>
                    </span>
                  )}
                </div>
                <span className={`text-[10px] mt-0.5 ${isActive ? 'text-white font-medium' : 'text-gray-500'}`}>
                  {tab.label}
                </span>
              </button>
            );
          })}
        </div>
        {/* Safe area for mobile */}
        <div className="h-[env(safe-area-inset-bottom)]" />
      </div>
    </div>
  );
};

export default BottomNav;
