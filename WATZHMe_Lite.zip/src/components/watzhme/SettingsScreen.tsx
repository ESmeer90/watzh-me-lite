import React, { useState } from 'react';
import {
  ArrowLeft,
  Edit3,
  Shield,
  Scale,
  LogOut,
  Bell,
  Lock,
  HelpCircle,
  Info,
  Trash2,
  ChevronRight,
  Globe,
  Moon,
  User,
} from 'lucide-react';
import { useAuthStore } from '@/stores/authStore';

interface SettingsScreenProps {
  onBack: () => void;
  onEditProfile: () => void;
  onPrivacyPolicy: () => void;
  onTermsOfService: () => void;
  onLogout: () => void;
}

const SettingsScreen: React.FC<SettingsScreenProps> = ({
  onBack,
  onEditProfile,
  onPrivacyPolicy,
  onTermsOfService,
  onLogout,
}) => {
  const { profile, user } = useAuthStore();
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);

  const handleDeleteAccount = () => {
    setShowDeleteConfirm(false);
    alert(
      'To delete your account and all data, please email watzhme@gmail.com with your username. We will process your request within 30 days as required by POPIA.'
    );
    onLogout();
  };

  return (
    <div className="h-full w-full bg-black flex flex-col overflow-y-auto scrollbar-hide">
      {/* Header */}
      <div className="flex items-center gap-3 px-4 py-3 border-b border-white/10 bg-black/95 backdrop-blur-sm sticky top-0 z-10">
        <button onClick={onBack} className="p-1.5 hover:bg-white/10 rounded-full transition-colors">
          <ArrowLeft className="w-5 h-5 text-white" />
        </button>
        <h1 className="text-white font-bold text-lg">Settings</h1>
      </div>

      {/* Profile summary */}
      <div className="px-4 py-5 border-b border-white/5">
        <div className="flex items-center gap-4">
          <div className="w-14 h-14 rounded-full overflow-hidden bg-gray-800 flex-shrink-0">
            {profile?.avatar_url ? (
              <img src={profile.avatar_url} className="w-full h-full object-cover" alt={profile.username} />
            ) : (
              <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-emerald-500 to-cyan-500 text-white text-xl font-bold">
                {profile?.username?.[0]?.toUpperCase() || 'U'}
              </div>
            )}
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-white font-semibold text-base truncate">@{profile?.username || 'user'}</p>
            {profile?.full_name && (
              <p className="text-gray-400 text-sm truncate">{profile.full_name}</p>
            )}
            <p className="text-gray-600 text-xs truncate mt-0.5">{user?.email}</p>
          </div>
          <button
            onClick={onEditProfile}
            className="px-4 py-2 bg-white/10 text-white text-sm font-medium rounded-lg hover:bg-white/15 transition-colors flex items-center gap-1.5"
          >
            <Edit3 className="w-3.5 h-3.5" />
            Edit
          </button>
        </div>
      </div>

      {/* Settings sections */}
      <div className="flex-1 pb-20">
        {/* Account section */}
        <div className="px-4 pt-5 pb-2">
          <p className="text-gray-500 text-[11px] font-semibold uppercase tracking-wider mb-2">Account</p>
        </div>
        <div className="mx-4 bg-[#111111] rounded-xl border border-white/5 overflow-hidden">
          <SettingsItem
            icon={<User className="w-4 h-4 text-emerald-400" />}
            label="Edit Profile"
            sublabel="Username, bio, avatar"
            onClick={onEditProfile}
          />
          <Divider />
          <SettingsItem
            icon={<Lock className="w-4 h-4 text-blue-400" />}
            label="Account Security"
            sublabel="Password, two-factor"
            onClick={() => {}}
            disabled
            badge="Coming soon"
          />
        </div>

        {/* Notifications section */}
        <div className="px-4 pt-6 pb-2">
          <p className="text-gray-500 text-[11px] font-semibold uppercase tracking-wider mb-2">Preferences</p>
        </div>
        <div className="mx-4 bg-[#111111] rounded-xl border border-white/5 overflow-hidden">
          <SettingsItem
            icon={<Bell className="w-4 h-4 text-amber-400" />}
            label="Notifications"
            sublabel="Push, email, in-app"
            onClick={() => {}}
            disabled
            badge="Coming soon"
          />
          <Divider />
          <SettingsItem
            icon={<Moon className="w-4 h-4 text-purple-400" />}
            label="Appearance"
            sublabel="Dark mode (default)"
            onClick={() => {}}
            disabled
          />
          <Divider />
          <SettingsItem
            icon={<Globe className="w-4 h-4 text-cyan-400" />}
            label="Language"
            sublabel="English"
            onClick={() => {}}
            disabled
          />
        </div>

        {/* Legal section */}
        <div className="px-4 pt-6 pb-2">
          <p className="text-gray-500 text-[11px] font-semibold uppercase tracking-wider mb-2">Legal & Support</p>
        </div>
        <div className="mx-4 bg-[#111111] rounded-xl border border-white/5 overflow-hidden">
          <SettingsItem
            icon={<Shield className="w-4 h-4 text-emerald-400" />}
            label="Privacy Policy"
            sublabel="POPIA & data protection"
            onClick={onPrivacyPolicy}
          />
          <Divider />
          <SettingsItem
            icon={<Scale className="w-4 h-4 text-gray-400" />}
            label="Terms of Service"
            sublabel="Usage terms & conditions"
            onClick={onTermsOfService}
          />
          <Divider />
          <SettingsItem
            icon={<HelpCircle className="w-4 h-4 text-blue-400" />}
            label="Help & Support"
            sublabel="watzhme@gmail.com"
            onClick={() => {
              window.open('mailto:watzhme@gmail.com', '_blank');
            }}
          />
        </div>

        {/* Danger zone */}
        <div className="px-4 pt-6 pb-2">
          <p className="text-gray-500 text-[11px] font-semibold uppercase tracking-wider mb-2">Danger Zone</p>
        </div>
        <div className="mx-4 bg-[#111111] rounded-xl border border-white/5 overflow-hidden">
          <SettingsItem
            icon={<Trash2 className="w-4 h-4 text-orange-400" />}
            label="Delete Account"
            sublabel="Permanently remove your data"
            onClick={() => setShowDeleteConfirm(true)}
            danger
          />
          <Divider />
          <button
            onClick={onLogout}
            className="w-full flex items-center gap-3 px-4 py-3.5 hover:bg-white/5 transition-colors text-left"
          >
            <LogOut className="w-4 h-4 text-red-400" />
            <span className="text-red-400 text-sm font-medium">Sign Out</span>
          </button>
        </div>

        {/* App info */}
        <div className="flex flex-col items-center py-8">
          <div className="flex items-center gap-2 mb-1">
            <Info className="w-3 h-3 text-gray-600" />
            <span className="text-gray-600 text-xs">WATZHMe Lite v1.0.0</span>
          </div>
          <p className="text-gray-700 text-[10px]">Made with care in South Africa</p>
        </div>
      </div>

      {/* Delete account confirmation modal */}
      {showDeleteConfirm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center px-6">
          <div className="absolute inset-0 bg-black/70 backdrop-blur-sm" onClick={() => setShowDeleteConfirm(false)} />
          <div className="relative bg-[#1a1a1a] rounded-2xl border border-white/10 p-6 max-w-sm w-full">
            <h3 className="text-white text-base font-bold mb-2">Delete your account?</h3>
            <p className="text-gray-400 text-sm leading-relaxed mb-5">
              This will permanently delete your account, posts, comments, and all associated data.
              This action cannot be undone. As per POPIA, your data will be removed within 30 days.
            </p>
            <div className="flex gap-3">
              <button
                onClick={handleDeleteAccount}
                className="flex-1 py-2.5 bg-red-500 text-white text-sm font-medium rounded-xl hover:bg-red-600 transition-colors"
              >
                Delete Account
              </button>
              <button
                onClick={() => setShowDeleteConfirm(false)}
                className="flex-1 py-2.5 bg-white/10 text-white text-sm font-medium rounded-xl hover:bg-white/15 transition-colors"
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

// Reusable settings item
const SettingsItem: React.FC<{
  icon: React.ReactNode;
  label: string;
  sublabel?: string;
  onClick: () => void;
  disabled?: boolean;
  danger?: boolean;
  badge?: string;
}> = ({ icon, label, sublabel, onClick, disabled, danger, badge }) => (
  <button
    onClick={disabled ? undefined : onClick}
    disabled={disabled}
    className={`w-full flex items-center gap-3 px-4 py-3.5 transition-colors text-left ${
      disabled ? 'opacity-50 cursor-default' : 'hover:bg-white/5 active:bg-white/10'
    }`}
  >
    {icon}
    <div className="flex-1 min-w-0">
      <span className={`text-sm font-medium ${danger ? 'text-orange-400' : 'text-gray-200'}`}>{label}</span>
      {sublabel && <p className="text-gray-600 text-[11px] mt-0.5 truncate">{sublabel}</p>}
    </div>
    {badge && (
      <span className="px-2 py-0.5 bg-emerald-500/10 text-emerald-400 text-[10px] font-medium rounded-full">
        {badge}
      </span>
    )}
    <ChevronRight className="w-4 h-4 text-gray-600 flex-shrink-0" />
  </button>
);

const Divider = () => <div className="h-px bg-white/5 ml-11" />;

export default SettingsScreen;
