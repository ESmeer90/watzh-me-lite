import React, { useState, useEffect, useRef } from 'react';
import { ArrowLeft, Send, Phone, Video, MoreVertical, Check, CheckCheck, Smile } from 'lucide-react';

import { useMessageStore, type Message } from '@/stores/messageStore';
import { useAuthStore } from '@/stores/authStore';
import { supabase } from '@/lib/supabase';
import { useToast } from '@/hooks/use-toast';

interface ChatScreenProps {
  otherUserId: string;
  otherUsername: string;
  otherAvatarUrl: string | null;
  onBack: () => void;
  onProfileClick: (userId: string) => void;
}

const ChatScreen: React.FC<ChatScreenProps> = ({
  otherUserId,
  otherUsername,
  otherAvatarUrl,
  onBack,
  onProfileClick,
}) => {
  const { currentMessages, isLoadingMessages, fetchMessages, sendMessage, markAsRead } = useMessageStore();
  const { user } = useAuthStore();
  const { toast } = useToast();
  const [text, setText] = useState('');
  const [sending, setSending] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const channelRef = useRef<any>(null);
  const [localMessages, setLocalMessages] = useState<Message[]>([]);

  // === KEY FIX: Use refs to always have the latest values ===
  const textRef = useRef(text);
  textRef.current = text;

  const sendingRef = useRef(sending);
  sendingRef.current = sending;

  // Derived: has text to send?
  const hasText = text.trim().length > 0;

  useEffect(() => {
    if (user?.id) {
      fetchMessages(user.id, otherUserId);
      markAsRead(user.id, otherUserId);
      subscribeToChat();
    }
    return () => {
      unsubscribeFromChat();
    };
  }, [user?.id, otherUserId]);

  // Sync local messages with store
  useEffect(() => {
    setLocalMessages(currentMessages);
  }, [currentMessages]);

  // Auto-scroll to bottom when messages change
  useEffect(() => {
    scrollToBottom();
  }, [localMessages]);

  const subscribeToChat = () => {
    unsubscribeFromChat();
    if (!user?.id) return;

    try {
      const channel = supabase
        .channel(`chat-${user.id}-${otherUserId}-${Date.now()}`)
        .on(
          'postgres_changes',
          {
            event: 'INSERT',
            schema: 'public',
            table: 'messages',
          },
          (payload: any) => {
            const msg = payload.new as Message;
            if (
              (msg.sender_id === user?.id && msg.receiver_id === otherUserId) ||
              (msg.sender_id === otherUserId && msg.receiver_id === user?.id)
            ) {
              setLocalMessages(prev => {
                if (prev.some(m => m.id === msg.id)) return prev;
                // Remove optimistic version
                const filtered = prev.filter(m => {
                  if (
                    m.id.startsWith('temp-') &&
                    m.sender_id === msg.sender_id &&
                    m.content === msg.content
                  ) {
                    return false;
                  }
                  return true;
                });
                return [...filtered, msg];
              });
              // Mark incoming messages as read
              if (msg.receiver_id === user?.id) {
                markAsRead(user.id, otherUserId);
              }
            }
          }
        )
        .on(
          'postgres_changes',
          {
            event: 'UPDATE',
            schema: 'public',
            table: 'messages',
          },
          (payload: any) => {
            const updatedMsg = payload.new as Message;
            setLocalMessages(prev =>
              prev.map(m => m.id === updatedMsg.id ? { ...m, read: updatedMsg.read } : m)
            );
          }
        )
        .subscribe();

      channelRef.current = channel;
    } catch (err) {
      console.error('[Chat] Subscribe error:', err);
    }
  };

  const unsubscribeFromChat = () => {
    if (channelRef.current) {
      try {
        supabase.removeChannel(channelRef.current);
      } catch (err) {
        console.error('[Chat] Unsubscribe error:', err);
      }
      channelRef.current = null;
    }
  };

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  // ============================
  // SEND MESSAGE — Core handler
  // KEY FIX: NOT wrapped in useCallback — reads from refs to avoid stale closures
  // ============================
  const handleSend = async () => {
    // Read from refs to get the absolute latest values
    const trimmed = textRef.current.trim();
    if (!trimmed) {
      console.log('[Chat] handleSend: empty text, aborting');
      return;
    }
    if (sendingRef.current) {
      console.log('[Chat] handleSend: already sending, aborting');
      return;
    }

    console.log('[Chat] handleSend called, text:', trimmed.substring(0, 50));

    // === RESOLVE USER ID: store first, session fallback ===
    let userId = user?.id;
    if (!userId) {
      try {
        const { data: { session } } = await supabase.auth.getSession();
        userId = session?.user?.id;
      } catch {
        // ignore
      }
    }
    if (!userId) {
      console.warn('[Chat] No user ID found — not authenticated');
      toast({
        title: 'Please sign in',
        description: 'You need to be signed in to send messages.',
        variant: 'destructive',
      });
      return;
    }

    console.log('[Chat] Sending as user:', userId, 'to:', otherUserId);
    setSending(true);
    const content = trimmed;

    // Clear input IMMEDIATELY (TikTok behavior)
    setText('');

    // === OPTIMISTIC UPDATE: show message in list instantly ===
    const tempId = `temp-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;
    const optimisticMsg: Message = {
      id: tempId,
      sender_id: userId,
      receiver_id: otherUserId,
      content,
      created_at: new Date().toISOString(),
      read: false,
    };
    setLocalMessages(prev => [...prev, optimisticMsg]);

    // Blur input to dismiss keyboard (mobile behavior)
    inputRef.current?.blur();

    // === ACTUAL INSERT — direct Supabase first for reliability ===
    try {
      console.log('[Chat] Inserting directly to Supabase...');
      const { error: directError } = await supabase.from('messages').insert({
        sender_id: userId,
        receiver_id: otherUserId,
        content,
        read: false,
      });

      if (directError) {
        console.error('[Chat] Direct insert failed:', directError.message);
        // Remove optimistic message on failure
        setLocalMessages(prev => prev.filter(m => m.id !== tempId));
        setText(content); // Restore text
        toast({
          title: 'Failed to send',
          description: directError.message || 'Message could not be sent. Please try again.',
          variant: 'destructive',
        });
        setSending(false);
        return;
      }

      console.log('[Chat] Insert succeeded');

      // Fallback: if realtime doesn't replace optimistic within 4s, reload
      setTimeout(() => {
        setLocalMessages(prev => {
          const stillHasTemp = prev.some(m => m.id === tempId);
          if (stillHasTemp && userId) {
            console.log('[Chat] Realtime fallback: reloading messages');
            fetchMessages(userId, otherUserId);
          }
          return prev;
        });
      }, 4000);
    } catch (err: any) {
      console.error('[Chat] Send error:', err);
      setLocalMessages(prev => prev.filter(m => m.id !== tempId));
      setText(content);
      toast({
        title: 'Failed to send',
        description: err?.message || 'Something went wrong. Check your connection.',
        variant: 'destructive',
      });
    }

    setSending(false);
  };

  // Enter key sends (desktop)
  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const formatTime = (date: string) => {
    const d = new Date(date);
    return d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  const formatDateSeparator = (date: string) => {
    const d = new Date(date);
    const today = new Date();
    const yesterday = new Date(today);
    yesterday.setDate(yesterday.getDate() - 1);

    if (d.toDateString() === today.toDateString()) return 'Today';
    if (d.toDateString() === yesterday.toDateString()) return 'Yesterday';
    return d.toLocaleDateString([], { month: 'short', day: 'numeric', year: 'numeric' });
  };

  // Group messages by date
  const groupedMessages: { date: string; messages: Message[] }[] = [];
  localMessages.forEach((msg) => {
    const dateStr = new Date(msg.created_at).toDateString();
    const lastGroup = groupedMessages[groupedMessages.length - 1];
    if (lastGroup && new Date(lastGroup.messages[0].created_at).toDateString() === dateStr) {
      lastGroup.messages.push(msg);
    } else {
      groupedMessages.push({ date: msg.created_at, messages: [msg] });
    }
  });

  return (
    <div className="h-full w-full bg-black flex flex-col">
      {/* ===== HEADER ===== */}
      <div className="flex items-center gap-3 px-3 py-2.5 border-b border-white/10 bg-black/95 backdrop-blur-sm flex-shrink-0">
        <button
          onClick={onBack}
          className="p-1.5 hover:bg-white/10 rounded-full transition-colors active:scale-90"
        >
          <ArrowLeft className="w-5 h-5 text-white" />
        </button>

        <button
          onClick={() => onProfileClick(otherUserId)}
          className="flex items-center gap-3 flex-1 min-w-0"
        >
          <div className="w-9 h-9 rounded-full overflow-hidden bg-gray-800 flex-shrink-0">
            {otherAvatarUrl ? (
              <img src={otherAvatarUrl} className="w-full h-full object-cover" alt={otherUsername} />
            ) : (
              <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-emerald-500 to-cyan-500 text-white text-sm font-bold">
                {otherUsername[0]?.toUpperCase()}
              </div>
            )}
          </div>
          <div className="min-w-0">
            <p className="text-white text-sm font-semibold truncate">@{otherUsername}</p>
            <p className="text-emerald-400 text-[10px]">Online</p>
          </div>
        </button>

        <div className="flex items-center gap-1">
          <button className="p-2 hover:bg-white/10 rounded-full transition-colors">
            <Phone className="w-4 h-4 text-gray-400" />
          </button>
          <button className="p-2 hover:bg-white/10 rounded-full transition-colors">
            <Video className="w-4 h-4 text-gray-400" />
          </button>
          <button className="p-2 hover:bg-white/10 rounded-full transition-colors">
            <MoreVertical className="w-4 h-4 text-gray-400" />
          </button>
        </div>
      </div>

      {/* ===== MESSAGES LIST ===== */}
      <div className="flex-1 overflow-y-auto px-4 py-3 scrollbar-hide">
        {isLoadingMessages ? (
          <div className="flex items-center justify-center py-12">
            <div className="w-6 h-6 border-2 border-emerald-400 border-t-transparent rounded-full animate-spin" />
          </div>
        ) : localMessages.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-16 text-center">
            <div className="w-16 h-16 rounded-full overflow-hidden bg-gray-800 mb-4">
              {otherAvatarUrl ? (
                <img src={otherAvatarUrl} className="w-full h-full object-cover" alt={otherUsername} />
              ) : (
                <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-emerald-500 to-cyan-500 text-white text-xl font-bold">
                  {otherUsername[0]?.toUpperCase()}
                </div>
              )}
            </div>
            <p className="text-white font-semibold">@{otherUsername}</p>
            <p className="text-gray-500 text-sm mt-1">Send a message to start the conversation</p>
          </div>
        ) : (
          groupedMessages.map((group, gi) => (
            <div key={gi}>
              {/* Date separator */}
              <div className="flex items-center justify-center my-4">
                <span className="text-gray-600 text-[10px] bg-gray-900 px-3 py-1 rounded-full">
                  {formatDateSeparator(group.date)}
                </span>
              </div>

              {group.messages.map((msg, mi) => {
                const isMine = msg.sender_id === user?.id;
                const isOptimistic = msg.id.startsWith('temp-');
                const showTail = mi === group.messages.length - 1 ||
                  group.messages[mi + 1]?.sender_id !== msg.sender_id;

                return (
                  <div
                    key={msg.id}
                    className={`flex mb-1 ${isMine ? 'justify-end' : 'justify-start'}`}
                  >
                    <div
                      className={`max-w-[75%] px-3.5 py-2 ${
                        isMine
                          ? `bg-emerald-600 text-white ${showTail ? 'rounded-2xl rounded-br-sm' : 'rounded-2xl'}`
                          : `bg-[#1e1e1e] text-gray-200 ${showTail ? 'rounded-2xl rounded-bl-sm' : 'rounded-2xl'}`
                      } ${isOptimistic ? 'opacity-70' : ''}`}
                    >
                      <p className="text-sm break-words leading-relaxed">{msg.content}</p>
                      <div className={`flex items-center gap-1 mt-0.5 ${isMine ? 'justify-end' : 'justify-start'}`}>
                        <span className={`text-[9px] ${isMine ? 'text-emerald-200/60' : 'text-gray-500'}`}>
                          {isOptimistic ? 'sending...' : formatTime(msg.created_at)}
                        </span>
                        {/* Read receipt ticks */}
                        {isMine && !isOptimistic && (
                          msg.read ? (
                            <CheckCheck className="w-3 h-3 text-emerald-300" />
                          ) : (
                            <Check className="w-3 h-3 text-gray-400" />
                          )
                        )}
                        {/* Optimistic: single grey tick */}
                        {isMine && isOptimistic && (
                          <Check className="w-3 h-3 text-gray-500" />
                        )}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          ))
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* ===== INPUT ROW — TikTok-style send button ===== */}
      <div className="border-t border-white/10 px-3 py-2.5 bg-black flex-shrink-0">
        <div className="flex items-end gap-2">
          {/* Text input */}
          <div className="flex-1 relative">
            <input
              ref={inputRef}
              type="text"
              value={text}
              onChange={(e) => setText(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder="Message..."
              className="w-full bg-white/[0.06] border border-white/[0.08] rounded-full px-4 py-2.5 pr-10 text-white text-sm placeholder-gray-600 outline-none focus:border-emerald-500/50 focus:bg-white/[0.08] transition-all"
              maxLength={1000}
              autoComplete="off"
            />
            {/* Smile icon inside input (right side decoration) */}
            {!hasText && (
              <div className="absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none">
                <Smile className="w-5 h-5 text-gray-600" />
              </div>
            )}
          </div>

          {/* SEND BUTTON — TikTok style: hidden when empty, slides in when typing */}
          <div
            className={`transition-all duration-200 ease-out flex-shrink-0 ${
              hasText ? 'w-10 opacity-100' : 'w-0 opacity-0 overflow-hidden'
            }`}
          >
            <button
              type="button"
              onClick={(e) => {
                e.preventDefault();
                e.stopPropagation();
                console.log('[Chat] Send button clicked, hasText:', hasText, 'sending:', sending);
                handleSend();
              }}
              disabled={!hasText || sending}
              aria-label="Send message"
              className={`w-10 h-10 rounded-full flex items-center justify-center transition-all duration-150 active:scale-[0.85] ${
                hasText && !sending
                  ? 'bg-gradient-to-br from-emerald-500 to-cyan-500 shadow-lg shadow-emerald-500/30 hover:shadow-emerald-500/50 hover:from-emerald-400 hover:to-cyan-400'
                  : 'bg-gray-700'
              }`}
            >
              {sending ? (
                <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
              ) : (
                <Send className="w-[18px] h-[18px] text-white" style={{ transform: 'rotate(-45deg)', marginLeft: '2px', marginTop: '-1px' }} />
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ChatScreen;
