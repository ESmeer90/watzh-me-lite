import React, { useState } from 'react';
import { Eye, EyeOff, ArrowLeft, Mail, Lock, User, FileText, CheckSquare, Square, Shield, AlertTriangle, MailCheck, RefreshCw } from 'lucide-react';
import { useAuthStore } from '@/stores/authStore';
import { useToast } from '@/hooks/use-toast';

interface RegisterScreenProps {
  onBack: () => void;
  onLogin: () => void;
  onPrivacyPolicy: () => void;
  onTermsOfService?: () => void;
}

const RegisterScreen: React.FC<RegisterScreenProps> = ({ onBack, onLogin, onPrivacyPolicy, onTermsOfService }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [username, setUsername] = useState('');
  const [fullName, setFullName] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [consent, setConsent] = useState(false);
  const [localError, setLocalError] = useState('');
  const {
    register,
    isLoading,
    error,
    clearError,
    emailConfirmationPending,
    pendingEmail,
    resendVerificationEmail,
    resendCooldown,
    clearEmailConfirmation,
  } = useAuthStore();
  const { toast } = useToast();
  const [resendSuccess, setResendSuccess] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    clearError();
    setLocalError('');

    if (!email.trim() || !password.trim() || !username.trim()) {
      setLocalError('Please fill in all required fields');
      return;
    }
    if (password.length < 6) {
      setLocalError('Password must be at least 6 characters');
      return;
    }
    if (password !== confirmPassword) {
      setLocalError('Passwords do not match');
      return;
    }
    if (username.length < 3) {
      setLocalError('Username must be at least 3 characters');
      return;
    }
    if (!/^[a-zA-Z0-9_]+$/.test(username)) {
      setLocalError('Username can only contain letters, numbers, and underscores');
      return;
    }
    if (!consent) {
      toast({
        title: 'Consent Required',
        description: 'You must consent to data processing to create an account (required by POPIA).',
        variant: 'destructive',
      });
      setLocalError('You must consent to data processing to create an account (required by POPIA)');
      return;
    }

    console.log('[Register] Attempting registration for:', email);
    await register(email.trim(), password, username.trim(), fullName.trim());
  };

  const handleResend = async () => {
    setResendSuccess(false);
    const success = await resendVerificationEmail();
    if (success) {
      setResendSuccess(true);
      toast({
        title: 'Email Sent',
        description: 'Verification email has been resent. Check your inbox and spam folder.',
      });
      // Clear success message after 5 seconds
      setTimeout(() => setResendSuccess(false), 5000);
    } else {
      toast({
        title: 'Resend Failed',
        description: error || 'Could not resend verification email. Please try again later.',
        variant: 'destructive',
      });
    }
  };

  const handleBackToLogin = () => {
    clearEmailConfirmation();
    onLogin();
  };

  const handleBack = () => {
    clearEmailConfirmation();
    onBack();
  };

  const displayError = localError || error;

  // ── Email Verification Pending Screen ──
  if (emailConfirmationPending) {
    return (
      <div className="h-full w-full bg-black flex flex-col overflow-y-auto scrollbar-hide">
        {/* Header */}
        <div className="flex items-center px-4 py-3 sticky top-0 bg-black/90 backdrop-blur-sm z-10">
          <button onClick={handleBack} className="p-2 -ml-2 hover:bg-white/10 rounded-full transition-colors">
            <ArrowLeft className="w-5 h-5 text-white" />
          </button>
        </div>

        <div className="flex-1 flex flex-col items-center justify-center px-6 pb-8">
          {/* Success Icon */}
          <div className="w-20 h-20 rounded-full bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center mb-6">
            <MailCheck className="w-10 h-10 text-emerald-400" />
          </div>

          {/* Title */}
          <h1 className="text-2xl font-bold text-white mb-2 text-center">Check your email</h1>
          <p className="text-gray-400 text-sm text-center max-w-xs leading-relaxed mb-2">
            We've sent a verification link to
          </p>
          <p className="text-emerald-400 font-medium text-sm mb-4">{pendingEmail}</p>

          {/* Info Box */}
          <div className="w-full max-w-sm bg-white/[0.03] border border-white/10 rounded-xl p-4 mb-6">
            <div className="flex items-start gap-3">
              <Shield className="w-4 h-4 text-cyan-400 flex-shrink-0 mt-0.5" />
              <div className="space-y-2">
                <p className="text-gray-300 text-xs leading-relaxed">
                  Click the link in the email to verify your account. You can still browse the feed, but some features require verification.
                </p>
                <p className="text-gray-500 text-[11px] leading-relaxed">
                  Don't see it? Check your spam or junk folder.
                </p>
              </div>
            </div>
          </div>

          {/* Resend Button */}
          <button
            onClick={handleResend}
            disabled={resendCooldown || isLoading}
            className="w-full max-w-sm flex items-center justify-center gap-2 py-3 bg-white/5 border border-white/10 rounded-xl text-white text-sm font-medium hover:bg-white/10 disabled:opacity-40 disabled:cursor-not-allowed transition-all mb-3"
          >
            <RefreshCw className={`w-4 h-4 ${isLoading ? 'animate-spin' : ''}`} />
            {resendCooldown ? 'Resend available in 60s' : 'Resend verification email'}
          </button>

          {/* Resend success feedback */}
          {resendSuccess && (
            <div className="w-full max-w-sm px-4 py-2.5 bg-emerald-500/10 border border-emerald-500/20 rounded-xl mb-3">
              <p className="text-emerald-400 text-xs text-center">
                Verification email resent successfully!
              </p>
            </div>
          )}

          {/* Go to Login */}
          <button
            onClick={handleBackToLogin}
            className="w-full max-w-sm py-3 bg-gradient-to-r from-emerald-500 to-cyan-500 text-white font-semibold rounded-xl transition-all active:scale-[0.98] hover:shadow-lg hover:shadow-emerald-500/20 mt-2"
          >
            Go to Sign In
          </button>

          <p className="text-gray-600 text-[11px] mt-6 text-center max-w-xs">
            Once verified, sign in with your email and password to access all features.
          </p>
        </div>
      </div>
    );
  }

  // ── Registration Form ──
  return (
    <div className="h-full w-full bg-black flex flex-col overflow-y-auto scrollbar-hide">
      {/* Header */}
      <div className="flex items-center px-4 py-3 sticky top-0 bg-black/90 backdrop-blur-sm z-10">
        <button onClick={onBack} className="p-2 -ml-2 hover:bg-white/10 rounded-full transition-colors">
          <ArrowLeft className="w-5 h-5 text-white" />
        </button>
      </div>

      <div className="flex-1 flex flex-col px-6 pt-2 pb-8">
        {/* Title */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-white mb-1">Create account</h1>
          <p className="text-gray-500 text-sm">Join WATZHMe and share every moment</p>
        </div>

        <form onSubmit={handleSubmit} className="flex flex-col gap-4">
          {/* Error */}
          {displayError && (
            <div className="px-4 py-3 bg-red-500/10 border border-red-500/20 rounded-xl flex items-start gap-3">
              <AlertTriangle className="w-4 h-4 text-red-400 flex-shrink-0 mt-0.5" />
              <p className="text-red-400 text-sm">{displayError}</p>
            </div>
          )}

          {/* Full name */}
          <div>
            <label className="text-gray-400 text-xs font-medium mb-1.5 block">Full Name</label>
            <div className="relative">
              <FileText className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
              <input
                type="text"
                value={fullName}
                onChange={(e) => setFullName(e.target.value)}
                placeholder="Your full name"
                className="w-full bg-white/5 border border-white/10 rounded-xl pl-11 pr-4 py-3.5 text-white text-sm placeholder-gray-600 outline-none focus:border-emerald-500/50 focus:ring-1 focus:ring-emerald-500/20 transition-all"
              />
            </div>
          </div>

          {/* Username */}
          <div>
            <label className="text-gray-400 text-xs font-medium mb-1.5 block">Username *</label>
            <div className="relative">
              <User className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
              <input
                type="text"
                value={username}
                onChange={(e) => setUsername(e.target.value.toLowerCase().replace(/[^a-z0-9_]/g, ''))}
                placeholder="your_username"
                className="w-full bg-white/5 border border-white/10 rounded-xl pl-11 pr-4 py-3.5 text-white text-sm placeholder-gray-600 outline-none focus:border-emerald-500/50 focus:ring-1 focus:ring-emerald-500/20 transition-all"
                maxLength={30}
                required
              />
            </div>
          </div>

          {/* Email */}
          <div>
            <label className="text-gray-400 text-xs font-medium mb-1.5 block">Email *</label>
            <div className="relative">
              <Mail className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="your@email.com"
                className="w-full bg-white/5 border border-white/10 rounded-xl pl-11 pr-4 py-3.5 text-white text-sm placeholder-gray-600 outline-none focus:border-emerald-500/50 focus:ring-1 focus:ring-emerald-500/20 transition-all"
                required
              />
            </div>
          </div>

          {/* Password */}
          <div>
            <label className="text-gray-400 text-xs font-medium mb-1.5 block">Password *</label>
            <div className="relative">
              <Lock className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
              <input
                type={showPassword ? 'text' : 'password'}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Min 6 characters"
                className="w-full bg-white/5 border border-white/10 rounded-xl pl-11 pr-12 py-3.5 text-white text-sm placeholder-gray-600 outline-none focus:border-emerald-500/50 focus:ring-1 focus:ring-emerald-500/20 transition-all"
                minLength={6}
                required
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3 top-1/2 -translate-y-1/2 p-1 text-gray-500 hover:text-gray-300"
              >
                {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
          </div>

          {/* Confirm password */}
          <div>
            <label className="text-gray-400 text-xs font-medium mb-1.5 block">Confirm Password *</label>
            <div className="relative">
              <Lock className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
              <input
                type={showPassword ? 'text' : 'password'}
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                placeholder="Confirm your password"
                className="w-full bg-white/5 border border-white/10 rounded-xl pl-11 pr-4 py-3.5 text-white text-sm placeholder-gray-600 outline-none focus:border-emerald-500/50 focus:ring-1 focus:ring-emerald-500/20 transition-all"
                required
              />
            </div>
          </div>

          {/* POPIA Consent — Required */}
          <div className={`mt-2 rounded-xl p-4 border transition-colors ${
            consent 
              ? 'bg-emerald-500/5 border-emerald-500/20' 
              : 'bg-white/[0.02] border-white/10'
          }`}>
            <div className="flex items-center gap-2 mb-3">
              <Shield className="w-4 h-4 text-emerald-400" />
              <span className="text-emerald-400 text-xs font-semibold uppercase tracking-wider">Data Consent (Required)</span>
            </div>
            <button
              type="button"
              onClick={() => { setConsent(!consent); if (localError?.includes('consent')) setLocalError(''); }}
              className="flex items-start gap-3 text-left w-full group"
              aria-label={consent ? 'Revoke POPIA consent' : 'Give POPIA consent'}
              aria-checked={consent}
              role="checkbox"
            >
              {consent ? (
                <CheckSquare className="w-5 h-5 text-emerald-400 flex-shrink-0 mt-0.5 transition-transform group-active:scale-90" />
              ) : (
                <Square className="w-5 h-5 text-gray-500 flex-shrink-0 mt-0.5 group-hover:text-gray-400 transition-colors group-active:scale-90" />
              )}
              <span className="text-gray-400 text-xs leading-relaxed">
                I consent to WATZHMe processing my personal data in accordance with the 
                South African POPIA Act and the African Union Malabo Convention. Read our{' '}
                <span
                  onClick={(e) => { e.stopPropagation(); onPrivacyPolicy(); }}
                  className="text-emerald-400 underline font-medium hover:text-emerald-300 transition-colors"
                  role="link"
                  tabIndex={0}
                  onKeyDown={(e) => { if (e.key === 'Enter') { e.stopPropagation(); onPrivacyPolicy(); } }}
                >
                  Privacy Policy
                </span>
                {onTermsOfService && (
                  <>
                    {' '}and{' '}
                    <span
                      onClick={(e) => { e.stopPropagation(); onTermsOfService(); }}
                      className="text-cyan-400 underline font-medium hover:text-cyan-300 transition-colors"
                      role="link"
                      tabIndex={0}
                      onKeyDown={(e) => { if (e.key === 'Enter') { e.stopPropagation(); onTermsOfService(); } }}
                    >
                      Terms of Service
                    </span>
                  </>
                )}
                .
              </span>
            </button>
            {/* Consent status indicator */}
            {consent && (
              <div className="mt-3 pt-2 border-t border-emerald-500/10 flex items-center gap-2">
                <div className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                <span className="text-emerald-400/70 text-[10px] font-medium">Consent granted</span>
              </div>
            )}
          </div>

          {/* Submit */}
          <button
            type="submit"
            disabled={isLoading || !email.trim() || !password.trim() || !username.trim() || !consent}
            className="w-full py-3.5 mt-4 bg-gradient-to-r from-emerald-500 to-cyan-500 text-white font-semibold rounded-xl disabled:opacity-40 disabled:cursor-not-allowed transition-all active:scale-[0.98] hover:shadow-lg hover:shadow-emerald-500/20"
          >
            {isLoading ? (
              <div className="flex items-center justify-center gap-2">
                <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                <span>Creating account...</span>
              </div>
            ) : (
              'Sign Up'
            )}
          </button>

          {/* Consent hint when button is disabled due to consent */}
          {!consent && email.trim() && password.trim() && username.trim() && (
            <p className="text-center text-amber-400/60 text-[11px] -mt-2">
              Please accept the data consent above to continue
            </p>
          )}

          {/* Login link */}
          <div className="text-center mt-4">
            <span className="text-gray-500 text-sm">Already have an account? </span>
            <button
              type="button"
              onClick={onLogin}
              className="text-emerald-400 text-sm font-semibold hover:text-emerald-300 transition-colors"
            >
              Sign In
            </button>
          </div>
        </form>

        {/* Footer */}
        <div className="mt-8 text-center">
          <p className="text-gray-700 text-[10px] leading-relaxed">
            By creating an account, you agree to our{' '}
            {onTermsOfService ? (
              <button onClick={onTermsOfService} className="text-gray-600 underline hover:text-gray-500 transition-colors">Terms of Service</button>
            ) : (
              <span>Terms of Service</span>
            )}
            {' '}and{' '}
            <button onClick={onPrivacyPolicy} className="text-gray-600 underline hover:text-gray-500 transition-colors">Privacy Policy</button>.
            <br />
            WATZHMe Lite v1.0.0 | Kimberley, Northern Cape, South Africa
          </p>
        </div>
      </div>
    </div>
  );
};

export default RegisterScreen;
