import React, { useState } from 'react';
import { Eye, EyeOff, ArrowLeft, Mail, Lock, Shield, MailCheck, RefreshCw, AlertTriangle } from 'lucide-react';
import { useAuthStore } from '@/stores/authStore';
import { useToast } from '@/hooks/use-toast';

interface LoginScreenProps {
  onBack: () => void;
  onRegister: () => void;
  onForgotPassword: () => void;
  onPrivacyPolicy?: () => void;
  onTermsOfService?: () => void;
}

const LoginScreen: React.FC<LoginScreenProps> = ({
  onBack,
  onRegister,
  onForgotPassword,
  onPrivacyPolicy,
  onTermsOfService,
}) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const {
    login,
    isLoading,
    error,
    clearError,
    emailConfirmationPending,
    pendingEmail,
    resendVerificationEmail,
    resendCooldown,
    clearEmailConfirmation,
  } = useAuthStore();
  const { toast } = useToast();
  const [resendSuccess, setResendSuccess] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    clearError();
    if (!email.trim() || !password.trim()) return;
    await login(email.trim(), password);
  };

  const handleResend = async () => {
    setResendSuccess(false);
    const success = await resendVerificationEmail();
    if (success) {
      setResendSuccess(true);
      toast({
        title: 'Email Sent',
        description: 'Verification email has been resent. Check your inbox and spam folder.',
      });
      setTimeout(() => setResendSuccess(false), 5000);
    } else {
      toast({
        title: 'Resend Failed',
        description: 'Could not resend verification email. Please try again later.',
        variant: 'destructive',
      });
    }
  };

  const handleBackFromVerification = () => {
    clearEmailConfirmation();
  };

  const handleBack = () => {
    clearEmailConfirmation();
    onBack();
  };

  // ── Email Not Confirmed Screen (shown when login detects unconfirmed user) ──
  if (emailConfirmationPending) {
    return (
      <div className="h-full w-full bg-black flex flex-col overflow-y-auto scrollbar-hide">
        {/* Header */}
        <div className="flex items-center px-4 py-3 sticky top-0 bg-black/90 backdrop-blur-sm z-10">
          <button onClick={handleBack} className="p-2 -ml-2 hover:bg-white/10 rounded-full transition-colors">
            <ArrowLeft className="w-5 h-5 text-white" />
          </button>
        </div>

        <div className="flex-1 flex flex-col items-center justify-center px-6 pb-8">
          {/* Warning Icon */}
          <div className="w-20 h-20 rounded-full bg-amber-500/10 border border-amber-500/20 flex items-center justify-center mb-6">
            <MailCheck className="w-10 h-10 text-amber-400" />
          </div>

          {/* Title */}
          <h1 className="text-2xl font-bold text-white mb-2 text-center">Email not verified</h1>
          <p className="text-gray-400 text-sm text-center max-w-xs leading-relaxed mb-2">
            Your account exists but the email hasn't been verified yet.
          </p>
          {pendingEmail && (
            <p className="text-amber-400 font-medium text-sm mb-4">{pendingEmail}</p>
          )}

          {/* Info Box */}
          <div className="w-full max-w-sm bg-white/[0.03] border border-white/10 rounded-xl p-4 mb-6">
            <div className="flex items-start gap-3">
              <AlertTriangle className="w-4 h-4 text-amber-400 flex-shrink-0 mt-0.5" />
              <div className="space-y-2">
                <p className="text-gray-300 text-xs leading-relaxed">
                  Check your email to verify your account. You can still browse, but some features require verification.
                </p>
                <p className="text-gray-500 text-[11px] leading-relaxed">
                  Check your spam or junk folder if you don't see the email.
                </p>
              </div>
            </div>
          </div>

          {/* Resend Button */}
          <button
            onClick={handleResend}
            disabled={resendCooldown || isLoading}
            className="w-full max-w-sm flex items-center justify-center gap-2 py-3 bg-white/5 border border-white/10 rounded-xl text-white text-sm font-medium hover:bg-white/10 disabled:opacity-40 disabled:cursor-not-allowed transition-all mb-3"
          >
            <RefreshCw className={`w-4 h-4 ${isLoading ? 'animate-spin' : ''}`} />
            {resendCooldown ? 'Resend available in 60s' : 'Resend verification email'}
          </button>

          {/* Resend success feedback */}
          {resendSuccess && (
            <div className="w-full max-w-sm px-4 py-2.5 bg-emerald-500/10 border border-emerald-500/20 rounded-xl mb-3">
              <p className="text-emerald-400 text-xs text-center">
                Verification email resent successfully!
              </p>
            </div>
          )}

          {/* Back to Login */}
          <button
            onClick={handleBackFromVerification}
            className="w-full max-w-sm py-3 bg-gradient-to-r from-emerald-500 to-cyan-500 text-white font-semibold rounded-xl transition-all active:scale-[0.98] hover:shadow-lg hover:shadow-emerald-500/20 mt-2"
          >
            Try signing in again
          </button>

          <p className="text-gray-600 text-[11px] mt-6 text-center max-w-xs">
            Once verified, return here and sign in with your email and password.
          </p>
        </div>
      </div>
    );
  }

  // ── Login Form ──
  return (
    <div className="h-full w-full bg-black flex flex-col">
      {/* Header */}
      <div className="flex items-center px-4 py-3">
        <button onClick={handleBack} className="p-2 -ml-2 hover:bg-white/10 rounded-full transition-colors">
          <ArrowLeft className="w-5 h-5 text-white" />
        </button>
      </div>

      <div className="flex-1 flex flex-col px-6 pt-4 pb-8">
        {/* Logo & title */}
        <div className="mb-10">
          <h1 className="text-3xl font-bold text-white mb-1">Welcome back</h1>
          <p className="text-gray-500 text-sm">Sign in to your WATZHMe account</p>
        </div>

        <form onSubmit={handleSubmit} className="flex-1 flex flex-col">
          {/* Error */}
          {error && (
            <div className="mb-4 px-4 py-3 bg-red-500/10 border border-red-500/20 rounded-xl flex items-start gap-3">
              <AlertTriangle className="w-4 h-4 text-red-400 flex-shrink-0 mt-0.5" />
              <p className="text-red-400 text-sm">{error}</p>
            </div>
          )}

          {/* Email */}
          <div className="mb-4">
            <label className="text-gray-400 text-xs font-medium mb-1.5 block">Email</label>
            <div className="relative">
              <Mail className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="your@email.com"
                className="w-full bg-white/5 border border-white/10 rounded-xl pl-11 pr-4 py-3.5 text-white text-sm placeholder-gray-600 outline-none focus:border-emerald-500/50 focus:ring-1 focus:ring-emerald-500/20 transition-all"
                autoComplete="email"
                required
              />
            </div>
          </div>

          {/* Password */}
          <div className="mb-3">
            <label className="text-gray-400 text-xs font-medium mb-1.5 block">Password</label>
            <div className="relative">
              <Lock className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
              <input
                type={showPassword ? 'text' : 'password'}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Enter your password"
                className="w-full bg-white/5 border border-white/10 rounded-xl pl-11 pr-12 py-3.5 text-white text-sm placeholder-gray-600 outline-none focus:border-emerald-500/50 focus:ring-1 focus:ring-emerald-500/20 transition-all"
                autoComplete="current-password"
                required
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3 top-1/2 -translate-y-1/2 p-1 text-gray-500 hover:text-gray-300"
              >
                {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
          </div>

          {/* Forgot password */}
          <button
            type="button"
            onClick={onForgotPassword}
            className="text-emerald-400 text-xs font-medium self-end mb-8 hover:text-emerald-300 transition-colors"
          >
            Forgot password?
          </button>

          {/* Submit */}
          <button
            type="submit"
            disabled={isLoading || !email.trim() || !password.trim()}
            className="w-full py-3.5 bg-gradient-to-r from-emerald-500 to-cyan-500 text-white font-semibold rounded-xl disabled:opacity-50 transition-all active:scale-[0.98] hover:shadow-lg hover:shadow-emerald-500/20"
          >
            {isLoading ? (
              <div className="flex items-center justify-center gap-2">
                <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                <span>Signing in...</span>
              </div>
            ) : (
              'Sign In'
            )}
          </button>

          {/* Divider */}
          <div className="flex items-center gap-3 my-6">
            <div className="flex-1 h-px bg-white/10" />
            <span className="text-gray-600 text-xs">or</span>
            <div className="flex-1 h-px bg-white/10" />
          </div>

          {/* Register link */}
          <div className="text-center">
            <span className="text-gray-500 text-sm">Don&apos;t have an account? </span>
            <button
              type="button"
              onClick={onRegister}
              className="text-emerald-400 text-sm font-semibold hover:text-emerald-300 transition-colors"
            >
              Sign Up
            </button>
          </div>
        </form>

        {/* Footer with clickable legal links */}
        <div className="mt-auto pt-4 text-center space-y-2">
          <div className="flex items-center justify-center gap-1.5 text-gray-600">
            <Shield className="w-3 h-3" />
            <span className="text-[10px]">Your data is protected by POPIA</span>
          </div>
          <p className="text-gray-700 text-[10px] leading-relaxed">
            By signing in, you agree to our{' '}
            {onTermsOfService ? (
              <button
                type="button"
                onClick={onTermsOfService}
                className="text-gray-500 underline hover:text-gray-400 transition-colors"
              >
                Terms of Service
              </button>
            ) : (
              <span className="text-gray-500">Terms of Service</span>
            )}
            {' '}and{' '}
            {onPrivacyPolicy ? (
              <button
                type="button"
                onClick={onPrivacyPolicy}
                className="text-gray-500 underline hover:text-gray-400 transition-colors"
              >
                Privacy Policy
              </button>
            ) : (
              <span className="text-gray-500">Privacy Policy</span>
            )}
          </p>
        </div>
      </div>
    </div>
  );
};

export default LoginScreen;
