import React, { useState, useEffect } from 'react';
import {
  ArrowLeft, Eye, Heart, MessageCircle, Users, TrendingUp,
  BarChart3, Activity, Flame, Award, ArrowUpRight, ArrowDownRight,
  Calendar, Clock, Zap
} from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useAuthStore } from '@/stores/authStore';

interface AnalyticsScreenProps {
  onBack: () => void;
}

interface AnalyticsData {
  totalViews: number;
  totalLikes: number;
  totalComments: number;
  totalPosts: number;
  followersCount: number;
  followingCount: number;
  engagementRate: number;
  avgViewsPerPost: number;
  avgLikesPerPost: number;
  topPosts: {
    id: string;
    media_url: string;
    thumbnail_url: string | null;
    caption: string;
    media_type: string;
    likes_count: number;
    comments_count: number;
    view_count: number;
    created_at: string;
  }[];
  recentActivity: {
    newFollowers7d: number;
    newLikes7d: number;
    newComments7d: number;
    newViews7d: number;
  };
  postsByDay: { day: string; count: number }[];
}

const AnalyticsScreen: React.FC<AnalyticsScreenProps> = ({ onBack }) => {
  const { user, profile } = useAuthStore();
  const [data, setData] = useState<AnalyticsData | null>(null);
  const [loading, setLoading] = useState(true);
  const [activeMetric, setActiveMetric] = useState<'views' | 'likes' | 'comments'>('views');

  useEffect(() => {
    if (user?.id) {
      loadAnalytics();
    }
  }, [user?.id]);

  const loadAnalytics = async () => {
    if (!user?.id) return;
    setLoading(true);

    try {
      // Fetch all user posts
      const { data: posts, error: postsError } = await supabase
        .from('posts')
        .select('id, media_url, thumbnail_url, caption, media_type, likes_count, comments_count, view_count, created_at')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false });

      if (postsError) {
        console.error('[Analytics] Posts fetch error:', postsError);
        setLoading(false);
        return;
      }

      const allPosts = posts || [];

      // Calculate totals
      const totalViews = allPosts.reduce((sum, p) => sum + (p.view_count || 0), 0);
      const totalLikes = allPosts.reduce((sum, p) => sum + (p.likes_count || 0), 0);
      const totalComments = allPosts.reduce((sum, p) => sum + (p.comments_count || 0), 0);
      const totalPosts = allPosts.length;

      // Followers/following counts
      const [followersRes, followingRes] = await Promise.all([
        supabase.from('follows').select('id', { count: 'exact', head: true }).eq('following_id', user.id),
        supabase.from('follows').select('id', { count: 'exact', head: true }).eq('follower_id', user.id),
      ]);

      const followersCount = followersRes.count || 0;
      const followingCount = followingRes.count || 0;

      // Engagement rate
      const engagementRate = totalViews > 0
        ? ((totalLikes + totalComments) / totalViews) * 100
        : 0;

      // Top posts by views
      const topPosts = [...allPosts]
        .sort((a, b) => (b.view_count || 0) - (a.view_count || 0))
        .slice(0, 6);

      // Recent activity (last 7 days)
      const sevenDaysAgo = new Date();
      sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 7);
      const sevenDaysAgoStr = sevenDaysAgo.toISOString();

      const [newFollowersRes, newLikesRes, newCommentsRes] = await Promise.all([
        supabase.from('follows').select('id', { count: 'exact', head: true })
          .eq('following_id', user.id).gte('created_at', sevenDaysAgoStr),
        supabase.from('likes').select('id', { count: 'exact', head: true })
          .in('post_id', allPosts.map(p => p.id)).gte('created_at', sevenDaysAgoStr),
        supabase.from('comments').select('id', { count: 'exact', head: true })
          .in('post_id', allPosts.map(p => p.id)).gte('created_at', sevenDaysAgoStr),
      ]);

      // Posts by day of week
      const dayMap: Record<string, number> = { Sun: 0, Mon: 0, Tue: 0, Wed: 0, Thu: 0, Fri: 0, Sat: 0 };
      const dayNames = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
      allPosts.forEach(p => {
        const day = dayNames[new Date(p.created_at).getDay()];
        dayMap[day]++;
      });

      setData({
        totalViews,
        totalLikes,
        totalComments,
        totalPosts,
        followersCount,
        followingCount,
        engagementRate,
        avgViewsPerPost: totalPosts > 0 ? totalViews / totalPosts : 0,
        avgLikesPerPost: totalPosts > 0 ? totalLikes / totalPosts : 0,
        topPosts,
        recentActivity: {
          newFollowers7d: newFollowersRes.count || 0,
          newLikes7d: newLikesRes.count || 0,
          newComments7d: newCommentsRes.count || 0,
          newViews7d: 0, // Would need view tracking with timestamps
        },
        postsByDay: dayNames.map(day => ({ day, count: dayMap[day] })),
      });
    } catch (err) {
      console.error('[Analytics] Load error:', err);
    }
    setLoading(false);
  };

  const formatNumber = (n: number): string => {
    if (n >= 1000000) return (n / 1000000).toFixed(1) + 'M';
    if (n >= 10000) return (n / 1000).toFixed(0) + 'K';
    if (n >= 1000) return (n / 1000).toFixed(1) + 'K';
    return n.toString();
  };

  const formatDate = (dateStr: string): string => {
    const d = new Date(dateStr);
    return d.toLocaleDateString([], { month: 'short', day: 'numeric' });
  };

  if (loading) {
    return (
      <div className="h-full w-full bg-black flex flex-col">
        <div className="flex items-center gap-3 px-4 py-3 border-b border-white/10">
          <button onClick={onBack} className="p-1.5 hover:bg-white/10 rounded-full transition-colors">
            <ArrowLeft className="w-5 h-5 text-white" />
          </button>
          <h2 className="text-white font-bold text-base">Analytics</h2>
        </div>
        <div className="flex-1 flex items-center justify-center">
          <div className="flex flex-col items-center gap-3">
            <div className="w-10 h-10 border-2 border-emerald-400 border-t-transparent rounded-full animate-spin" />
            <p className="text-gray-500 text-sm">Loading analytics...</p>
          </div>
        </div>
      </div>
    );
  }

  if (!data) {
    return (
      <div className="h-full w-full bg-black flex flex-col">
        <div className="flex items-center gap-3 px-4 py-3 border-b border-white/10">
          <button onClick={onBack} className="p-1.5 hover:bg-white/10 rounded-full transition-colors">
            <ArrowLeft className="w-5 h-5 text-white" />
          </button>
          <h2 className="text-white font-bold text-base">Analytics</h2>
        </div>
        <div className="flex-1 flex items-center justify-center px-8 text-center">
          <div>
            <BarChart3 className="w-12 h-12 text-gray-700 mx-auto mb-3" />
            <p className="text-gray-500 text-sm">Unable to load analytics</p>
            <button onClick={loadAnalytics} className="mt-4 px-6 py-2 bg-emerald-500 text-white text-sm rounded-lg">
              Retry
            </button>
          </div>
        </div>
      </div>
    );
  }

  const maxBarValue = Math.max(...data.postsByDay.map(d => d.count), 1);

  return (
    <div className="h-full w-full bg-black flex flex-col">
      {/* Header */}
      <div className="flex items-center gap-3 px-4 py-3 border-b border-white/10 bg-black sticky top-0 z-10">
        <button onClick={onBack} className="p-1.5 hover:bg-white/10 rounded-full transition-colors">
          <ArrowLeft className="w-5 h-5 text-white" />
        </button>
        <div className="flex-1">
          <h2 className="text-white font-bold text-base">Analytics</h2>
          <p className="text-gray-500 text-[10px]">@{profile?.username || 'you'}</p>
        </div>
        <div className="flex items-center gap-1 px-2.5 py-1 bg-emerald-500/10 rounded-full">
          <Activity className="w-3 h-3 text-emerald-400" />
          <span className="text-emerald-400 text-[10px] font-medium">Live</span>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto pb-24 scrollbar-hide">
        {/* Overview Cards */}
        <div className="px-4 pt-4 pb-2">
          <div className="flex items-center gap-2 mb-3">
            <Zap className="w-4 h-4 text-yellow-400" />
            <span className="text-white text-sm font-semibold">Overview</span>
          </div>
          <div className="grid grid-cols-2 gap-2.5">
            {/* Total Views */}
            <div className="bg-gradient-to-br from-blue-500/10 to-cyan-500/10 rounded-2xl p-4 border border-blue-500/10">
              <div className="flex items-center gap-2 mb-2">
                <div className="w-8 h-8 rounded-xl bg-blue-500/20 flex items-center justify-center">
                  <Eye className="w-4 h-4 text-blue-400" />
                </div>
              </div>
              <p className="text-white text-2xl font-bold">{formatNumber(data.totalViews)}</p>
              <p className="text-gray-500 text-xs mt-0.5">Total Views</p>
            </div>

            {/* Total Likes */}
            <div className="bg-gradient-to-br from-red-500/10 to-pink-500/10 rounded-2xl p-4 border border-red-500/10">
              <div className="flex items-center gap-2 mb-2">
                <div className="w-8 h-8 rounded-xl bg-red-500/20 flex items-center justify-center">
                  <Heart className="w-4 h-4 text-red-400" />
                </div>
              </div>
              <p className="text-white text-2xl font-bold">{formatNumber(data.totalLikes)}</p>
              <p className="text-gray-500 text-xs mt-0.5">Total Likes</p>
            </div>

            {/* Total Comments */}
            <div className="bg-gradient-to-br from-cyan-500/10 to-emerald-500/10 rounded-2xl p-4 border border-cyan-500/10">
              <div className="flex items-center gap-2 mb-2">
                <div className="w-8 h-8 rounded-xl bg-cyan-500/20 flex items-center justify-center">
                  <MessageCircle className="w-4 h-4 text-cyan-400" />
                </div>
              </div>
              <p className="text-white text-2xl font-bold">{formatNumber(data.totalComments)}</p>
              <p className="text-gray-500 text-xs mt-0.5">Total Comments</p>
            </div>

            {/* Followers */}
            <div className="bg-gradient-to-br from-emerald-500/10 to-green-500/10 rounded-2xl p-4 border border-emerald-500/10">
              <div className="flex items-center gap-2 mb-2">
                <div className="w-8 h-8 rounded-xl bg-emerald-500/20 flex items-center justify-center">
                  <Users className="w-4 h-4 text-emerald-400" />
                </div>
              </div>
              <p className="text-white text-2xl font-bold">{formatNumber(data.followersCount)}</p>
              <p className="text-gray-500 text-xs mt-0.5">Followers</p>
            </div>
          </div>
        </div>

        {/* Engagement & Averages */}
        <div className="px-4 py-3">
          <div className="flex items-center gap-2 mb-3">
            <TrendingUp className="w-4 h-4 text-emerald-400" />
            <span className="text-white text-sm font-semibold">Performance</span>
          </div>
          <div className="bg-white/5 rounded-2xl p-4 border border-white/5 space-y-4">
            {/* Engagement Rate */}
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-purple-500/20 to-pink-500/20 flex items-center justify-center">
                  <Flame className="w-5 h-5 text-purple-400" />
                </div>
                <div>
                  <p className="text-white text-sm font-medium">Engagement Rate</p>
                  <p className="text-gray-500 text-[10px]">(Likes + Comments) / Views</p>
                </div>
              </div>
              <div className="text-right">
                <p className="text-white text-lg font-bold">{data.engagementRate.toFixed(1)}%</p>
                {data.engagementRate > 5 && (
                  <div className="flex items-center gap-0.5 text-emerald-400">
                    <ArrowUpRight className="w-3 h-3" />
                    <span className="text-[10px] font-medium">Great</span>
                  </div>
                )}
              </div>
            </div>

            <div className="h-px bg-white/5" />

            {/* Avg Views per Post */}
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-blue-500/10 flex items-center justify-center">
                  <Eye className="w-5 h-5 text-blue-400" />
                </div>
                <div>
                  <p className="text-white text-sm font-medium">Avg. Views / Post</p>
                  <p className="text-gray-500 text-[10px]">Across {data.totalPosts} posts</p>
                </div>
              </div>
              <p className="text-white text-lg font-bold">{formatNumber(Math.round(data.avgViewsPerPost))}</p>
            </div>

            <div className="h-px bg-white/5" />

            {/* Avg Likes per Post */}
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-red-500/10 flex items-center justify-center">
                  <Heart className="w-5 h-5 text-red-400" />
                </div>
                <div>
                  <p className="text-white text-sm font-medium">Avg. Likes / Post</p>
                  <p className="text-gray-500 text-[10px]">Across {data.totalPosts} posts</p>
                </div>
              </div>
              <p className="text-white text-lg font-bold">{formatNumber(Math.round(data.avgLikesPerPost))}</p>
            </div>
          </div>
        </div>

        {/* 7-Day Activity */}
        <div className="px-4 py-3">
          <div className="flex items-center gap-2 mb-3">
            <Calendar className="w-4 h-4 text-cyan-400" />
            <span className="text-white text-sm font-semibold">Last 7 Days</span>
          </div>
          <div className="grid grid-cols-3 gap-2.5">
            <div className="bg-white/5 rounded-xl p-3 text-center border border-white/5">
              <div className="flex items-center justify-center gap-1 mb-1">
                <Users className="w-3 h-3 text-emerald-400" />
                <ArrowUpRight className="w-3 h-3 text-emerald-400" />
              </div>
              <p className="text-white text-lg font-bold">+{data.recentActivity.newFollowers7d}</p>
              <p className="text-gray-500 text-[10px]">New Followers</p>
            </div>
            <div className="bg-white/5 rounded-xl p-3 text-center border border-white/5">
              <div className="flex items-center justify-center gap-1 mb-1">
                <Heart className="w-3 h-3 text-red-400" />
                <ArrowUpRight className="w-3 h-3 text-red-400" />
              </div>
              <p className="text-white text-lg font-bold">+{data.recentActivity.newLikes7d}</p>
              <p className="text-gray-500 text-[10px]">New Likes</p>
            </div>
            <div className="bg-white/5 rounded-xl p-3 text-center border border-white/5">
              <div className="flex items-center justify-center gap-1 mb-1">
                <MessageCircle className="w-3 h-3 text-cyan-400" />
                <ArrowUpRight className="w-3 h-3 text-cyan-400" />
              </div>
              <p className="text-white text-lg font-bold">+{data.recentActivity.newComments7d}</p>
              <p className="text-gray-500 text-[10px]">New Comments</p>
            </div>
          </div>
        </div>

        {/* Posting Activity Chart */}
        <div className="px-4 py-3">
          <div className="flex items-center gap-2 mb-3">
            <BarChart3 className="w-4 h-4 text-purple-400" />
            <span className="text-white text-sm font-semibold">Posting Activity</span>
            <span className="text-gray-600 text-[10px]">by day of week</span>
          </div>
          <div className="bg-white/5 rounded-2xl p-4 border border-white/5">
            <div className="flex items-end justify-between gap-2 h-28">
              {data.postsByDay.map((item) => {
                const height = maxBarValue > 0 ? (item.count / maxBarValue) * 100 : 0;
                return (
                  <div key={item.day} className="flex-1 flex flex-col items-center gap-1.5">
                    <span className="text-gray-400 text-[9px] font-medium">{item.count}</span>
                    <div className="w-full flex justify-center">
                      <div
                        className="w-6 rounded-t-md bg-gradient-to-t from-emerald-500 to-cyan-400 transition-all duration-500"
                        style={{ height: `${Math.max(height, 4)}%`, minHeight: '4px' }}
                      />
                    </div>
                    <span className="text-gray-500 text-[9px]">{item.day}</span>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Top Posts */}
        {data.topPosts.length > 0 && (
          <div className="px-4 py-3">
            <div className="flex items-center gap-2 mb-3">
              <Award className="w-4 h-4 text-yellow-400" />
              <span className="text-white text-sm font-semibold">Top Posts</span>
              <span className="text-gray-600 text-[10px]">by views</span>
            </div>
            <div className="space-y-2.5">
              {data.topPosts.map((post, index) => (
                <div
                  key={post.id}
                  className="flex items-center gap-3 bg-white/5 rounded-xl p-3 border border-white/5"
                >
                  {/* Rank */}
                  <div className={`w-7 h-7 rounded-lg flex items-center justify-center flex-shrink-0 text-xs font-bold ${
                    index === 0 ? 'bg-yellow-500/20 text-yellow-400' :
                    index === 1 ? 'bg-gray-400/20 text-gray-400' :
                    index === 2 ? 'bg-orange-500/20 text-orange-400' :
                    'bg-white/5 text-gray-500'
                  }`}>
                    #{index + 1}
                  </div>

                  {/* Thumbnail */}
                  <div className="w-12 h-12 rounded-lg overflow-hidden bg-gray-800 flex-shrink-0">
                    <img
                      src={post.thumbnail_url || post.media_url}
                      alt=""
                      className="w-full h-full object-cover"
                    />
                  </div>

                  {/* Info */}
                  <div className="flex-1 min-w-0">
                    <p className="text-white text-xs font-medium truncate">
                      {post.caption || 'No caption'}
                    </p>
                    <p className="text-gray-600 text-[10px] mt-0.5">{formatDate(post.created_at)}</p>
                  </div>

                  {/* Stats */}
                  <div className="flex items-center gap-3 flex-shrink-0">
                    <div className="flex items-center gap-1">
                      <Eye className="w-3 h-3 text-blue-400" />
                      <span className="text-gray-300 text-[10px] font-medium">{formatNumber(post.view_count || 0)}</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <Heart className="w-3 h-3 text-red-400" />
                      <span className="text-gray-300 text-[10px] font-medium">{formatNumber(post.likes_count)}</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Account Summary */}
        <div className="px-4 py-3 mb-4">
          <div className="bg-gradient-to-br from-emerald-500/5 to-cyan-500/5 rounded-2xl p-4 border border-emerald-500/10">
            <div className="flex items-center gap-2 mb-3">
              <div className="w-8 h-8 rounded-xl bg-gradient-to-br from-emerald-500 to-cyan-500 flex items-center justify-center">
                <BarChart3 className="w-4 h-4 text-white" />
              </div>
              <div>
                <p className="text-white text-sm font-semibold">Account Summary</p>
                <p className="text-gray-500 text-[10px]">All-time statistics</p>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="flex items-center gap-2">
                <Clock className="w-3.5 h-3.5 text-gray-500" />
                <span className="text-gray-400 text-xs">{data.totalPosts} posts shared</span>
              </div>
              <div className="flex items-center gap-2">
                <Users className="w-3.5 h-3.5 text-gray-500" />
                <span className="text-gray-400 text-xs">{data.followingCount} following</span>
              </div>
              <div className="flex items-center gap-2">
                <Eye className="w-3.5 h-3.5 text-gray-500" />
                <span className="text-gray-400 text-xs">{formatNumber(data.totalViews)} total views</span>
              </div>
              <div className="flex items-center gap-2">
                <Flame className="w-3.5 h-3.5 text-gray-500" />
                <span className="text-gray-400 text-xs">{data.engagementRate.toFixed(1)}% engagement</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AnalyticsScreen;
