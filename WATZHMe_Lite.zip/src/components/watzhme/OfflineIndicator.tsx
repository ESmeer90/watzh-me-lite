import React, { useState, useEffect } from 'react';
import { WifiOff, Wifi, X } from 'lucide-react';

const OfflineIndicator: React.FC = () => {
  const [isOnline, setIsOnline] = useState(navigator.onLine);
  const [showReconnected, setShowReconnected] = useState(false);
  const [dismissed, setDismissed] = useState(false);
  const [wasOffline, setWasOffline] = useState(false);

  useEffect(() => {
    const handleOnline = () => {
      setIsOnline(true);
      setDismissed(false);
      if (wasOffline) {
        setShowReconnected(true);
        setTimeout(() => setShowReconnected(false), 3000);
      }
    };

    const handleOffline = () => {
      setIsOnline(false);
      setDismissed(false);
      setWasOffline(true);
    };

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, [wasOffline]);

  // Show reconnected banner
  if (showReconnected) {
    return (
      <div className="fixed top-0 left-0 right-0 z-[100] animate-[slideDown_0.3s_ease-out]">
        <div className="bg-emerald-500 px-4 py-2 flex items-center justify-center gap-2">
          <Wifi className="w-4 h-4 text-white" />
          <span className="text-white text-xs font-medium">Back online</span>
        </div>
      </div>
    );
  }

  // Show offline banner
  if (!isOnline && !dismissed) {
    return (
      <div className="fixed top-0 left-0 right-0 z-[100] animate-[slideDown_0.3s_ease-out]">
        <div className="bg-red-500/90 backdrop-blur-sm px-4 py-2.5 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <WifiOff className="w-4 h-4 text-white" />
            <div>
              <span className="text-white text-xs font-medium">No internet connection</span>
              <p className="text-white/70 text-[10px]">Some features may not work</p>
            </div>
          </div>
          <button
            onClick={() => setDismissed(true)}
            className="p-1 hover:bg-white/10 rounded-full transition-colors"
          >
            <X className="w-3.5 h-3.5 text-white" />
          </button>
        </div>
      </div>
    );
  }

  return null;
};

export default OfflineIndicator;
