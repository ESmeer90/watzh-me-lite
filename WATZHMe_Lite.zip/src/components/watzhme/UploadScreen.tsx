import React, { useState, useRef, useCallback } from 'react';
import { Camera, Image, X, Upload, Film, Type, AlertCircle, CheckCircle } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useAuthStore } from '@/stores/authStore';
import { useFeedStore } from '@/stores/feedStore';

import {
  compressImage,
  generateVideoThumbnail,
  formatFileSize,
  validateFile,
  getExtFromMime,
} from '@/lib/mediaUtils';

interface UploadScreenProps {
  onClose: () => void;
  onSuccess: () => void;
}

type UploadStage = 'idle' | 'compressing' | 'uploading-media' | 'uploading-thumbnail' | 'creating-post' | 'done' | 'error';

const UploadScreen: React.FC<UploadScreenProps> = ({ onClose, onSuccess }) => {
  const [file, setFile] = useState<File | null>(null);
  const [preview, setPreview] = useState<string | null>(null);
  const [caption, setCaption] = useState('');
  const [stage, setStage] = useState<UploadStage>('idle');
  const [progress, setProgress] = useState(0);
  const [stageLabel, setStageLabel] = useState('');
  const [error, setError] = useState('');
  const [cancelled, setCancelled] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const abortRef = useRef(false);
  const { user } = useAuthStore();

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selected = e.target.files?.[0];
    if (!selected) return;

    console.log(`[Upload] File selected: ${selected.name}, type: ${selected.type}, size: ${formatFileSize(selected.size)}`);

    const validation = validateFile(selected);
    if (!validation.valid) {
      setError(validation.error || 'Invalid file');
      return;
    }

    setFile(selected);
    setError('');
    setCancelled(false);
    setStage('idle');
    setProgress(0);

    // Create preview URL
    const url = URL.createObjectURL(selected);
    setPreview(url);
  };

  const handleCancel = useCallback(() => {
    console.log('[Upload] Cancel requested');
    abortRef.current = true;
    setCancelled(true);
    setStage('idle');
    setProgress(0);
    setStageLabel('');
    setError('Upload cancelled');
  }, []);

  const handleUpload = async () => {
    if (!file || !user) {
      setError('No file selected or not logged in');
      return;
    }

    abortRef.current = false;
    setCancelled(false);
    setError('');

    const isVideo = file.type.startsWith('video/');
    const timestamp = Date.now();
    const userId = user.id;

    console.log(`[Upload] Starting upload: ${file.name} (${isVideo ? 'video' : 'image'})`);

    try {
      // ========== STAGE 1: Compress ==========
      setStage('compressing');
      setStageLabel(isVideo ? 'Preparing video...' : 'Compressing image...');
      setProgress(5);

      let uploadBlob: Blob = file;
      let uploadExt = getExtFromMime(file.type) || (isVideo ? 'mp4' : 'jpg');

      if (!isVideo) {
        try {
          const compressed = await compressImage(file, 1920, 1920, 0.82);
          uploadBlob = compressed.blob;
          uploadExt = 'jpg';
          console.log(`[Upload] Image compressed: ${formatFileSize(file.size)} → ${formatFileSize(uploadBlob.size)}`);
        } catch (compressErr) {
          console.warn('[Upload] Compression failed, using original:', compressErr);
          uploadBlob = file;
        }
      }

      if (abortRef.current) return;
      setProgress(15);

      // ========== STAGE 2: Generate thumbnail for video ==========
      let thumbnailUrl: string | null = null;

      if (isVideo) {
        setStageLabel('Generating thumbnail...');
        setProgress(20);

        try {
          const thumbBlob = await generateVideoThumbnail(file, 1, 640, 0.7);
          const thumbFileName = `${userId}/${timestamp}_thumb.jpg`;

          console.log(`[Upload] Uploading thumbnail: ${thumbFileName}`);

          if (abortRef.current) return;
          setStage('uploading-thumbnail');
          setProgress(25);

          const { error: thumbError } = await supabase.storage
            .from('media')
            .upload(thumbFileName, thumbBlob, {
              cacheControl: '3600',
              upsert: false,
              contentType: 'image/jpeg',
            });

          if (thumbError) {
            console.warn('[Upload] Thumbnail upload failed:', thumbError.message);
          } else {
            const { data: thumbUrlData } = supabase.storage.from('media').getPublicUrl(thumbFileName);
            thumbnailUrl = thumbUrlData.publicUrl;
            console.log(`[Upload] Thumbnail URL: ${thumbnailUrl}`);
          }
        } catch (thumbErr) {
          console.warn('[Upload] Thumbnail generation failed:', thumbErr);
        }
      }

      if (abortRef.current) return;
      setProgress(30);

      // ========== STAGE 3: Upload main media ==========
      setStage('uploading-media');
      setStageLabel(isVideo ? 'Uploading video...' : 'Uploading image...');

      const mediaFileName = `${userId}/${timestamp}.${uploadExt}`;
      console.log(`[Upload] Uploading media: ${mediaFileName} (${formatFileSize(uploadBlob.size)})`);

      // Simulate progress during upload
      const progressInterval = setInterval(() => {
        setProgress((prev) => {
          if (prev >= 85) {
            clearInterval(progressInterval);
            return prev;
          }
          // Slower progress for larger files
          const increment = uploadBlob.size > 10 * 1024 * 1024 ? 2 : 5;
          return Math.min(prev + increment, 85);
        });
      }, 500);

      const { data: uploadData, error: uploadError } = await supabase.storage
        .from('media')
        .upload(mediaFileName, uploadBlob, {
          cacheControl: '3600',
          upsert: false,
          contentType: isVideo ? file.type : 'image/jpeg',
        });

      clearInterval(progressInterval);

      if (abortRef.current) {
        // Try to clean up uploaded file
        try {
          await supabase.storage.from('media').remove([mediaFileName]);
        } catch {}
        return;
      }

      if (uploadError) {
        console.error('[Upload] Storage upload error:', uploadError);
        throw new Error(`Storage upload failed: ${uploadError.message}`);
      }

      console.log(`[Upload] Media uploaded successfully: ${uploadData.path}`);
      setProgress(90);

      // Get public URL
      const { data: urlData } = supabase.storage.from('media').getPublicUrl(mediaFileName);
      const mediaUrl = urlData.publicUrl;
      console.log(`[Upload] Media URL: ${mediaUrl}`);

      // ========== STAGE 4: Create post record ==========
      setStage('creating-post');
      setStageLabel('Creating post...');
      setProgress(92);

      if (abortRef.current) return;

      const postData = {
        user_id: userId,
        media_url: mediaUrl,
        thumbnail_url: thumbnailUrl || (isVideo ? null : mediaUrl),
        caption: caption.trim(),
        media_type: isVideo ? 'video' as const : 'image' as const,
      };

      console.log('[Upload] Inserting post:', JSON.stringify(postData, null, 2));

      const { error: insertError } = await supabase.from('posts').insert({
        user_id: postData.user_id,
        media_url: postData.media_url,
        thumbnail_url: postData.thumbnail_url,
        caption: postData.caption,
        media_type: postData.media_type,
        likes_count: 0,
        comments_count: 0,
        view_count: 0,
      });


      if (insertError) {
        console.error('[Upload] Post insert error:', insertError);
        throw new Error(`Failed to create post: ${insertError.message}`);
      }

      console.log('[Upload] Post created successfully!');
      setProgress(100);
      setStage('done');
      setStageLabel('Posted!');

      // Refresh feed in background (don't await)
      useFeedStore.getState().fetchPosts(true).catch((err) => {
        console.warn('[Upload] Feed refresh failed:', err);
      });

      // Navigate back after brief success animation
      setTimeout(() => {
        resetForm();
        onSuccess();
      }, 800);

    } catch (err: any) {
      if (abortRef.current) {
        console.log('[Upload] Upload was cancelled');
        return;
      }

      const errorMsg = err?.message || 'Upload failed. Please check your connection and try again.';
      console.error('[Upload] Error:', errorMsg, err);
      setError(errorMsg);
      setStage('error');
      setStageLabel('');
      setProgress(0);
    }
  };

  const resetForm = () => {
    setFile(null);
    setPreview(null);
    setCaption('');
    setStage('idle');
    setProgress(0);
    setStageLabel('');
    setError('');
    setCancelled(false);
    abortRef.current = false;
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const removeFile = () => {
    if (preview) URL.revokeObjectURL(preview);
    resetForm();
  };

  const isUploading = ['compressing', 'uploading-media', 'uploading-thumbnail', 'creating-post'].includes(stage);

  return (
    <div className="h-full w-full bg-black flex flex-col">
      {/* Header */}
      <div className="flex items-center justify-between px-4 py-3 border-b border-white/10 flex-shrink-0">
        <button
          onClick={isUploading ? handleCancel : onClose}
          className="p-1 hover:bg-white/10 rounded-full transition-colors"
        >
          <X className="w-5 h-5 text-white" />
        </button>
        <h2 className="text-white font-bold text-base">New Post</h2>
        {isUploading ? (
          <button
            onClick={handleCancel}
            className="px-4 py-1.5 bg-red-500/20 text-red-400 text-sm font-semibold rounded-full transition-all active:scale-95 border border-red-500/30"
          >
            Cancel
          </button>
        ) : (
          <button
            onClick={handleUpload}
            disabled={!file || stage === 'done'}
            className="px-4 py-1.5 bg-emerald-500 text-white text-sm font-semibold rounded-full disabled:opacity-40 transition-all active:scale-95 hover:bg-emerald-400"
          >
            {stage === 'done' ? 'Done!' : 'Post'}
          </button>
        )}
      </div>

      <div className="flex-1 overflow-y-auto px-4 py-4 scrollbar-hide">
        {/* Error banner */}
        {error && (
          <div className="mb-4 px-4 py-3 bg-red-500/10 border border-red-500/20 rounded-xl flex items-start gap-3">
            <AlertCircle className="w-5 h-5 text-red-400 flex-shrink-0 mt-0.5" />
            <div className="flex-1 min-w-0">
              <p className="text-red-400 text-sm font-medium">Upload Error</p>
              <p className="text-red-400/80 text-xs mt-0.5">{error}</p>
            </div>
            <button onClick={() => setError('')} className="p-0.5 hover:bg-red-500/10 rounded">
              <X className="w-4 h-4 text-red-400" />
            </button>
          </div>
        )}

        {/* Upload progress */}
        {(isUploading || stage === 'done') && (
          <div className="mb-4 p-4 bg-white/5 rounded-xl border border-white/10">
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-2">
                {stage === 'done' ? (
                  <CheckCircle className="w-4 h-4 text-emerald-400" />
                ) : (
                  <div className="w-4 h-4 border-2 border-emerald-400 border-t-transparent rounded-full animate-spin" />
                )}
                <span className="text-gray-300 text-sm font-medium">{stageLabel}</span>
              </div>
              <span className={`text-xs font-bold ${stage === 'done' ? 'text-emerald-400' : 'text-cyan-400'}`}>
                {progress}%
              </span>
            </div>
            <div className="w-full h-2 bg-white/10 rounded-full overflow-hidden">
              <div
                className={`h-full rounded-full transition-all duration-300 ease-out ${
                  stage === 'done'
                    ? 'bg-emerald-500'
                    : 'bg-gradient-to-r from-emerald-500 to-cyan-500'
                }`}
                style={{ width: `${progress}%` }}
              />
            </div>
            {file && (
              <p className="text-gray-600 text-[10px] mt-2">
                {file.name} ({formatFileSize(file.size)})
              </p>
            )}
          </div>
        )}

        {/* Media preview / picker */}
        {preview ? (
          <div className="relative mb-4 rounded-2xl overflow-hidden bg-gray-900">
            {file?.type.startsWith('video/') ? (
              <video
                src={preview}
                className="w-full max-h-[400px] object-contain bg-black"
                controls
                playsInline
                muted
                preload="metadata"
              />
            ) : (
              <img
                src={preview}
                alt="Preview"
                className="w-full max-h-[400px] object-contain"
              />
            )}
            {!isUploading && stage !== 'done' && (
              <button
                onClick={removeFile}
                className="absolute top-3 right-3 w-8 h-8 rounded-full bg-black/70 flex items-center justify-center hover:bg-black/90 transition-colors backdrop-blur-sm"
              >
                <X className="w-4 h-4 text-white" />
              </button>
            )}
            {/* File info badge */}
            {file && (
              <div className="absolute bottom-3 left-3 px-2.5 py-1 bg-black/70 backdrop-blur-sm rounded-full flex items-center gap-1.5">
                {file.type.startsWith('video/') ? (
                  <Film className="w-3 h-3 text-cyan-400" />
                ) : (
                  <Image className="w-3 h-3 text-emerald-400" />
                )}
                <span className="text-white text-[10px] font-medium">{formatFileSize(file.size)}</span>
              </div>
            )}
          </div>
        ) : (
          <div className="mb-4">
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*,video/*"
              onChange={handleFileSelect}
              className="hidden"
            />
            <button
              onClick={() => fileInputRef.current?.click()}
              className="w-full aspect-[3/4] max-h-[400px] border-2 border-dashed border-white/10 rounded-2xl flex flex-col items-center justify-center gap-4 hover:border-emerald-500/30 hover:bg-emerald-500/5 transition-all active:scale-[0.99]"
            >
              <div className="w-16 h-16 rounded-full bg-gradient-to-br from-emerald-500/20 to-cyan-500/20 flex items-center justify-center">
                <Upload className="w-7 h-7 text-emerald-400" />
              </div>
              <div className="text-center">
                <p className="text-white text-sm font-medium">Tap to select media</p>
                <p className="text-gray-600 text-xs mt-1">Images or videos up to 100MB</p>
              </div>
              <div className="flex items-center gap-4 mt-2">
                <div className="flex items-center gap-1.5 text-gray-500">
                  <Image className="w-4 h-4" />
                  <span className="text-xs">Photo</span>
                </div>
                <div className="flex items-center gap-1.5 text-gray-500">
                  <Film className="w-4 h-4" />
                  <span className="text-xs">Video</span>
                </div>
                <div className="flex items-center gap-1.5 text-gray-500">
                  <Camera className="w-4 h-4" />
                  <span className="text-xs">Camera</span>
                </div>
              </div>
            </button>
          </div>
        )}

        {/* Caption */}
        <div className="mb-4">
          <div className="flex items-center gap-2 mb-2">
            <Type className="w-4 h-4 text-gray-500" />
            <span className="text-gray-400 text-xs font-medium">Caption</span>
            <span className="text-gray-600 text-xs ml-auto">{caption.length}/280</span>
          </div>
          <textarea
            value={caption}
            onChange={(e) => setCaption(e.target.value)}
            placeholder="Write a caption for your moment..."
            maxLength={280}
            rows={3}
            className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white text-sm placeholder-gray-600 outline-none focus:border-emerald-500/50 focus:ring-1 focus:ring-emerald-500/20 transition-all resize-none"
            disabled={isUploading || stage === 'done'}
          />
        </div>

        {/* Tips */}
        <div className="bg-white/5 rounded-xl p-4 mb-20">
          <p className="text-gray-500 text-xs font-medium mb-2">Tips for great content:</p>
          <ul className="text-gray-600 text-xs space-y-1">
            <li className="flex items-start gap-2">
              <span className="text-emerald-500 mt-0.5">-</span>
              <span>Use good lighting for clear photos</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-emerald-500 mt-0.5">-</span>
              <span>Keep videos short and engaging (under 60s)</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-emerald-500 mt-0.5">-</span>
              <span>Images are auto-compressed for faster uploads</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-emerald-500 mt-0.5">-</span>
              <span>Video thumbnails are generated automatically</span>
            </li>
          </ul>
        </div>
      </div>
    </div>
  );
};

export default UploadScreen;
