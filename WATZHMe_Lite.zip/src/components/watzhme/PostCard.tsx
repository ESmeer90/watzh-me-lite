import React, { useState, useRef, useEffect } from 'react';
import { Heart, MessageCircle, Share2, Music, UserPlus, Bookmark, Play, Pause, Volume2, VolumeX, Eye } from 'lucide-react';
import type { Post } from '@/stores/feedStore';

interface PostCardProps {
  post: Post;
  isLiked: boolean;
  isBookmarked: boolean;
  isActive: boolean;
  onLike: () => void;
  onComment: () => void;
  onShare: () => void;
  onBookmark: () => void;
  onProfileClick: (userId: string) => void;
  isAuthenticated: boolean;
  isFollowing?: boolean;
  onFollow?: () => void;
}

function formatCount(n: number): string {
  if (n >= 1000000) return (n / 1000000).toFixed(1) + 'M';
  if (n >= 1000) return (n / 1000).toFixed(1) + 'K';
  return n.toString();
}

const PostCard: React.FC<PostCardProps> = ({
  post,
  isLiked,
  isBookmarked,
  isActive,
  onLike,
  onComment,
  onShare,
  onBookmark,
  onProfileClick,
  isAuthenticated,
  isFollowing,
  onFollow,
}) => {
  const [imageLoaded, setImageLoaded] = useState(false);
  const [showHeart, setShowHeart] = useState(false);
  const [muted, setMuted] = useState(true);
  const [isPlaying, setIsPlaying] = useState(false);
  const [showPlayIcon, setShowPlayIcon] = useState(false);
  const [progress, setProgress] = useState(0);
  const videoRef = useRef<HTMLVideoElement>(null);
  const lastTapRef = useRef(0);
  const username = post.profiles?.username || 'unknown';
  const avatarUrl = post.profiles?.avatar_url;
  const isVideo = post.media_type === 'video';
  const viewCount = post.view_count || 0;

  // Auto-play/pause video based on visibility
  useEffect(() => {
    if (!videoRef.current || !isVideo) return;
    
    if (isActive) {
      videoRef.current.play().then(() => setIsPlaying(true)).catch(() => {});
    } else {
      videoRef.current.pause();
      videoRef.current.currentTime = 0;
      setIsPlaying(false);
      setProgress(0);
    }
  }, [isActive, isVideo]);

  // Video progress tracking
  useEffect(() => {
    if (!videoRef.current || !isVideo || !isActive) return;
    
    const video = videoRef.current;
    const updateProgress = () => {
      if (video.duration) {
        setProgress((video.currentTime / video.duration) * 100);
      }
    };
    
    video.addEventListener('timeupdate', updateProgress);
    return () => video.removeEventListener('timeupdate', updateProgress);
  }, [isActive, isVideo]);

  const handleTap = () => {
    const now = Date.now();
    if (now - lastTapRef.current < 300) {
      // Double tap - like
      if (!isLiked) {
        onLike();
      }
      setShowHeart(true);
      setTimeout(() => setShowHeart(false), 800);
      lastTapRef.current = 0;
    } else {
      lastTapRef.current = now;
      // Single tap on video - toggle play/pause
      if (isVideo && videoRef.current) {
        if (videoRef.current.paused) {
          videoRef.current.play().then(() => setIsPlaying(true)).catch(() => {});
        } else {
          videoRef.current.pause();
          setIsPlaying(false);
        }
        setShowPlayIcon(true);
        setTimeout(() => setShowPlayIcon(false), 600);
      }
    }
  };

  const toggleMute = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (videoRef.current) {
      videoRef.current.muted = !muted;
      setMuted(!muted);
    }
  };

  return (
    <div
      className="relative w-full h-full bg-black flex items-center justify-center overflow-hidden select-none"
      onClick={handleTap}
    >
      {/* Media */}
      {isVideo ? (
        <>
          <video
            ref={videoRef}
            src={post.media_url}
            className="w-full h-full object-cover"
            loop
            muted={muted}
            playsInline
            preload="metadata"
            poster={post.thumbnail_url || undefined}
          />
          {/* Video progress bar */}
          {isActive && (
            <div className="absolute top-0 left-0 right-0 h-0.5 bg-white/10 z-30">
              <div
                className="h-full bg-white/60 transition-all duration-200"
                style={{ width: `${progress}%` }}
              />
            </div>
          )}
          {/* Play/Pause overlay */}
          {showPlayIcon && (
            <div className="absolute inset-0 flex items-center justify-center pointer-events-none z-20">
              <div className="w-16 h-16 rounded-full bg-black/40 flex items-center justify-center animate-[fadeIn_0.1s_ease-out]">
                {isPlaying ? (
                  <Pause className="w-8 h-8 text-white" fill="white" />
                ) : (
                  <Play className="w-8 h-8 text-white ml-1" fill="white" />
                )}
              </div>
            </div>
          )}
          {/* Mute button */}
          <button
            onClick={toggleMute}
            className="absolute top-14 right-3 z-30 w-8 h-8 rounded-full bg-black/40 flex items-center justify-center backdrop-blur-sm"
          >
            {muted ? (
              <VolumeX className="w-4 h-4 text-white" />
            ) : (
              <Volume2 className="w-4 h-4 text-white" />
            )}
          </button>
        </>
      ) : (
        <>
          {!imageLoaded && (
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="w-10 h-10 border-2 border-emerald-400 border-t-transparent rounded-full animate-spin" />
            </div>
          )}
          <img
            src={post.media_url}
            alt={post.caption}
            className={`w-full h-full object-cover transition-opacity duration-300 ${imageLoaded ? 'opacity-100' : 'opacity-0'}`}
            onLoad={() => setImageLoaded(true)}
            draggable={false}
          />
        </>
      )}

      {/* Gradient overlays */}
      <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-black/40 pointer-events-none" />

      {/* ============================================ */}
      {/* VIEW COUNT — TOP-LEFT CORNER ONLY             */}
      {/* This is the ONLY place view count is shown.   */}
      {/* No duplicate at bottom-right or anywhere else */}
      {/* ============================================ */}
      <div className="absolute top-12 left-3 z-30 flex items-center gap-1.5 bg-black/50 backdrop-blur-sm rounded-full px-2.5 py-1.5 pointer-events-none">
        <Eye className="w-3.5 h-3.5 text-white/90" />
        <span className="text-white/90 text-xs font-semibold drop-shadow-lg">{formatCount(viewCount)} views</span>
      </div>

      {/* Double-tap heart animation */}
      {showHeart && (
        <div className="absolute inset-0 flex items-center justify-center pointer-events-none z-30">
          <Heart
            className="w-24 h-24 text-red-500 fill-red-500"
            style={{ animation: 'scaleIn 0.3s ease-out, fadeIn 0.3s ease-out reverse 0.5s forwards' }}
          />
        </div>
      )}

      {/* Right side action buttons */}
      <div className="absolute right-3 bottom-28 flex flex-col items-center gap-5 z-20">
        {/* Avatar */}
        <button
          onClick={(e) => { e.stopPropagation(); onProfileClick(post.user_id); }}
          className="relative mb-2"
        >
          <div className="w-11 h-11 rounded-full border-2 border-white overflow-hidden bg-gray-800">
            {avatarUrl ? (
              <img src={avatarUrl} alt={username} className="w-full h-full object-cover" />
            ) : (
              <div className="w-full h-full flex items-center justify-center text-white text-sm font-bold bg-gradient-to-br from-emerald-500 to-cyan-500">
                {username[0]?.toUpperCase()}
              </div>
            )}
          </div>
          {isAuthenticated && !isFollowing && onFollow && (
            <button
              onClick={(e) => { e.stopPropagation(); onFollow(); }}
              className="absolute -bottom-1.5 left-1/2 -translate-x-1/2 w-5 h-5 rounded-full bg-emerald-500 flex items-center justify-center"
            >
              <UserPlus className="w-3 h-3 text-white" />
            </button>
          )}
        </button>

        {/* Like */}
        <button onClick={(e) => { e.stopPropagation(); onLike(); }} className="flex flex-col items-center group">
          <div className={`w-11 h-11 rounded-full flex items-center justify-center group-active:scale-90 transition-all duration-200 ${isLiked ? 'bg-red-500/20' : 'bg-white/10 backdrop-blur-sm'}`}>
            <Heart
              className={`w-6 h-6 transition-all duration-200 ${isLiked ? 'text-red-500 fill-red-500 scale-110' : 'text-white'}`}
            />
          </div>
          <span className={`text-xs mt-1 font-medium ${isLiked ? 'text-red-400' : 'text-white'}`}>{formatCount(post.likes_count)}</span>
        </button>

        {/* Comment */}
        <button onClick={(e) => { e.stopPropagation(); onComment(); }} className="flex flex-col items-center group">
          <div className="w-11 h-11 rounded-full bg-white/10 backdrop-blur-sm flex items-center justify-center group-active:scale-90 transition-transform">
            <MessageCircle className="w-6 h-6 text-white" />
          </div>
          <span className="text-white text-xs mt-1 font-medium">{formatCount(post.comments_count)}</span>
        </button>

        {/* Bookmark */}
        <button onClick={(e) => { e.stopPropagation(); onBookmark(); }} className="flex flex-col items-center group">
          <div className={`w-11 h-11 rounded-full flex items-center justify-center group-active:scale-90 transition-all ${isBookmarked ? 'bg-yellow-500/20' : 'bg-white/10 backdrop-blur-sm'}`}>
            <Bookmark
              className={`w-6 h-6 transition-colors ${isBookmarked ? 'text-yellow-400 fill-yellow-400' : 'text-white'}`}
            />
          </div>
          <span className={`text-xs mt-1 font-medium ${isBookmarked ? 'text-yellow-400' : 'text-white'}`}>Save</span>
        </button>

        {/* Share */}
        <button onClick={(e) => { e.stopPropagation(); onShare(); }} className="flex flex-col items-center group">
          <div className="w-11 h-11 rounded-full bg-white/10 backdrop-blur-sm flex items-center justify-center group-active:scale-90 transition-transform">
            <Share2 className="w-6 h-6 text-white" />
          </div>
          <span className="text-white text-xs mt-1 font-medium">Share</span>
        </button>

        {/* Music disc */}
        <div className={`w-10 h-10 rounded-full border-2 border-gray-600 overflow-hidden bg-gradient-to-br from-gray-800 to-gray-900 ${isActive && isVideo && isPlaying ? 'animate-[spin_3s_linear_infinite]' : ''}`}>
          <div className="w-full h-full flex items-center justify-center">
            <Music className="w-4 h-4 text-gray-400" />
          </div>
        </div>
      </div>

      {/* Bottom overlay: username + caption */}
      {/* NOTE: View count REMOVED from this section — it only appears at top-left */}
      <div className="absolute bottom-20 left-0 right-16 px-4 z-20">
        <button
          onClick={(e) => { e.stopPropagation(); onProfileClick(post.user_id); }}
          className="flex items-center gap-2 mb-2"
        >
          <span className="text-white font-bold text-sm">@{username}</span>
          {isFollowing && (
            <span className="px-2 py-0.5 bg-white/10 rounded-full text-[10px] text-emerald-400 font-medium">Following</span>
          )}
        </button>
        <p className="text-white/90 text-sm leading-5 line-clamp-3">{post.caption}</p>
        
        {/* Sound row — view count REMOVED, only sound info here */}
        <div className="flex items-center gap-2 mt-2 opacity-70">
          <Music className="w-3.5 h-3.5 text-white" />
          <div className="overflow-hidden max-w-[200px]">
            <span className="text-white text-xs whitespace-nowrap inline-block animate-[marquee_8s_linear_infinite]">
              Original Sound - @{username}
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PostCard;
