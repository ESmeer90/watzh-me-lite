import React, { useEffect, useState } from 'react';
import { MessageCircle, Bell, Search, Edit, Heart, UserPlus, AtSign, MessageSquare, CheckCheck } from 'lucide-react';
import { useMessageStore, type Conversation } from '@/stores/messageStore';
import { useNotificationStore, type Notification } from '@/stores/notificationStore';
import { useAuthStore } from '@/stores/authStore';

interface InboxScreenProps {
  isAuthenticated: boolean;
  onLogin: () => void;
  onOpenChat?: (userId: string, username: string, avatarUrl: string | null) => void;
  onProfileClick?: (userId: string) => void;
}

const InboxScreen: React.FC<InboxScreenProps> = ({ isAuthenticated, onLogin, onOpenChat, onProfileClick }) => {
  const { conversations, isLoadingConversations, fetchConversations, totalUnread, subscribeToMessages, unsubscribeFromMessages } = useMessageStore();
  const { notifications, unreadCount: notifUnread, isLoading: loadingNotifs, fetchNotifications, markAsRead, markAllAsRead, subscribeToNotifications, unsubscribeFromNotifications } = useNotificationStore();
  const { user } = useAuthStore();
  const [activeTab, setActiveTab] = useState<'messages' | 'notifications'>('messages');
  const [searchQuery, setSearchQuery] = useState('');

  useEffect(() => {
    if (isAuthenticated && user?.id) {
      fetchConversations(user.id);
      fetchNotifications(user.id);
      subscribeToMessages(user.id);
      subscribeToNotifications(user.id);
    }
    return () => {
      unsubscribeFromMessages();
      unsubscribeFromNotifications();
    };
  }, [isAuthenticated, user?.id]);

  if (!isAuthenticated) {
    return (
      <div className="h-full w-full bg-black flex flex-col items-center justify-center px-8 text-center">
        <div className="w-16 h-16 rounded-full bg-gradient-to-br from-emerald-500/20 to-cyan-500/20 flex items-center justify-center mb-4">
          <MessageCircle className="w-7 h-7 text-emerald-400" />
        </div>
        <h3 className="text-white text-lg font-bold mb-2">Messages & Activity</h3>
        <p className="text-gray-500 text-sm mb-6">Sign in to see your messages and notifications</p>
        <button
          onClick={onLogin}
          className="px-8 py-3 bg-gradient-to-r from-emerald-500 to-cyan-500 text-white font-semibold rounded-xl hover:shadow-lg hover:shadow-emerald-500/20 transition-all active:scale-[0.98]"
        >
          Sign In
        </button>
      </div>
    );
  }

  const filteredConversations = searchQuery.trim()
    ? conversations.filter(c =>
        c.username.toLowerCase().includes(searchQuery.toLowerCase()) ||
        (c.full_name || '').toLowerCase().includes(searchQuery.toLowerCase())
      )
    : conversations;

  const timeAgo = (date: string) => {
    const seconds = Math.floor((Date.now() - new Date(date).getTime()) / 1000);
    if (seconds < 60) return 'now';
    if (seconds < 3600) return `${Math.floor(seconds / 60)}m`;
    if (seconds < 86400) return `${Math.floor(seconds / 3600)}h`;
    if (seconds < 604800) return `${Math.floor(seconds / 86400)}d`;
    return `${Math.floor(seconds / 604800)}w`;
  };

  const handleNotificationTap = (notif: Notification) => {
    if (!notif.read) {
      markAsRead(notif.id);
    }
    // Navigate based on type
    if (notif.type === 'follow' && notif.actor_id && onProfileClick) {
      onProfileClick(notif.actor_id);
    }
  };

  const getNotificationIcon = (type: string) => {
    switch (type) {
      case 'like': return { icon: Heart, color: 'bg-red-500/10', iconColor: 'text-red-400' };
      case 'comment': return { icon: MessageSquare, color: 'bg-cyan-500/10', iconColor: 'text-cyan-400' };
      case 'follow': return { icon: UserPlus, color: 'bg-emerald-500/10', iconColor: 'text-emerald-400' };
      case 'message': return { icon: MessageCircle, color: 'bg-purple-500/10', iconColor: 'text-purple-400' };
      default: return { icon: Bell, color: 'bg-gray-500/10', iconColor: 'text-gray-400' };
    }
  };

  const getNotificationText = (notif: Notification) => {
    switch (notif.type) {
      case 'like': return 'liked your post';
      case 'comment': return notif.comment_text ? `commented: "${notif.comment_text}"` : 'commented on your post';
      case 'follow': return 'started following you';
      case 'message': return 'sent you a message';
      default: return 'interacted with you';
    }
  };

  return (
    <div className="h-full w-full bg-black flex flex-col">
      {/* Header */}
      <div className="flex items-center justify-between px-4 py-3 border-b border-white/10">
        <h2 className="text-white font-bold text-lg">Inbox</h2>
        <div className="flex items-center gap-2">
          {(totalUnread + notifUnread) > 0 && (
            <span className="px-2 py-0.5 bg-emerald-500 rounded-full text-[10px] text-white font-bold min-w-[20px] text-center">
              {totalUnread + notifUnread}
            </span>
          )}
          <button className="p-2 hover:bg-white/10 rounded-full transition-colors">
            <Edit className="w-5 h-5 text-gray-400" />
          </button>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex border-b border-white/10">
        <button
          onClick={() => setActiveTab('messages')}
          className={`flex-1 py-3 text-sm font-medium transition-colors relative ${
            activeTab === 'messages' ? 'text-white' : 'text-gray-500 hover:text-gray-300'
          }`}
        >
          <div className="flex items-center justify-center gap-1.5">
            Messages
            {totalUnread > 0 && (
              <span className="w-5 h-5 bg-emerald-500 rounded-full flex items-center justify-center">
                <span className="text-[9px] text-white font-bold">{totalUnread}</span>
              </span>
            )}
          </div>
          {activeTab === 'messages' && (
            <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-12 h-0.5 bg-emerald-500 rounded-full" />
          )}
        </button>
        <button
          onClick={() => setActiveTab('notifications')}
          className={`flex-1 py-3 text-sm font-medium transition-colors relative ${
            activeTab === 'notifications' ? 'text-white' : 'text-gray-500 hover:text-gray-300'
          }`}
        >
          <div className="flex items-center justify-center gap-1.5">
            Activity
            {notifUnread > 0 && (
              <span className="w-5 h-5 bg-red-500 rounded-full flex items-center justify-center">
                <span className="text-[9px] text-white font-bold">{notifUnread > 9 ? '9+' : notifUnread}</span>
              </span>
            )}
          </div>
          {activeTab === 'notifications' && (
            <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-12 h-0.5 bg-emerald-500 rounded-full" />
          )}
        </button>
      </div>

      {activeTab === 'messages' ? (
        <>
          {/* Search */}
          <div className="px-4 py-3">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search messages..."
                className="w-full bg-white/5 border border-white/10 rounded-xl pl-10 pr-4 py-2.5 text-white text-sm placeholder-gray-600 outline-none focus:border-emerald-500/40 transition-all"
              />
            </div>
          </div>

          {/* Conversations list */}
          <div className="flex-1 overflow-y-auto pb-20 scrollbar-hide">
            {isLoadingConversations ? (
              <div className="flex items-center justify-center py-12">
                <div className="w-6 h-6 border-2 border-emerald-400 border-t-transparent rounded-full animate-spin" />
              </div>
            ) : filteredConversations.length === 0 ? (
              <div className="flex flex-col items-center justify-center py-16 text-center px-8">
                <div className="w-16 h-16 rounded-full bg-gradient-to-br from-emerald-500/10 to-cyan-500/10 flex items-center justify-center mb-4">
                  <MessageCircle className="w-7 h-7 text-emerald-400/60" />
                </div>
                <h3 className="text-white text-base font-semibold mb-1">
                  {searchQuery ? 'No results' : 'No messages yet'}
                </h3>
                <p className="text-gray-500 text-sm">
                  {searchQuery
                    ? `No conversations matching "${searchQuery}"`
                    : "Start a conversation by visiting someone's profile and tapping Message"
                  }
                </p>
              </div>
            ) : (
              filteredConversations.map((conv) => (
                <ConversationItem
                  key={conv.userId}
                  conversation={conv}
                  onPress={() => onOpenChat?.(conv.userId, conv.username, conv.avatar_url)}
                  timeAgo={timeAgo}
                />
              ))
            )}
          </div>
        </>
      ) : (
        /* Notifications tab */
        <div className="flex-1 overflow-y-auto pb-20 scrollbar-hide">
          {/* Mark all as read */}
          {notifUnread > 0 && user?.id && (
            <div className="px-4 py-2 flex justify-end">
              <button
                onClick={() => markAllAsRead(user.id)}
                className="flex items-center gap-1.5 px-3 py-1.5 bg-white/5 rounded-full text-xs text-emerald-400 font-medium hover:bg-white/10 transition-colors"
              >
                <CheckCheck className="w-3.5 h-3.5" />
                Mark all read
              </button>
            </div>
          )}

          {loadingNotifs ? (
            <div className="flex items-center justify-center py-12">
              <div className="w-6 h-6 border-2 border-emerald-400 border-t-transparent rounded-full animate-spin" />
            </div>
          ) : notifications.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-16 text-center px-8">
              <div className="w-16 h-16 rounded-full bg-gradient-to-br from-emerald-500/10 to-cyan-500/10 flex items-center justify-center mb-4">
                <Bell className="w-7 h-7 text-emerald-400/60" />
              </div>
              <h3 className="text-white text-base font-semibold mb-1">No activity yet</h3>
              <p className="text-gray-500 text-sm">
                When someone likes, comments, or follows you, it'll show up here
              </p>
            </div>
          ) : (
            <div className="px-2">
              {notifications.map((notif) => {
                const { icon: Icon, color, iconColor } = getNotificationIcon(notif.type);
                return (
                  <button
                    key={notif.id}
                    onClick={() => handleNotificationTap(notif)}
                    className={`w-full flex items-center gap-3 px-3 py-3 rounded-xl transition-colors ${
                      notif.read ? 'hover:bg-white/5' : 'bg-emerald-500/5 hover:bg-emerald-500/10'
                    }`}
                  >
                    {/* Actor avatar */}
                    <div className="relative flex-shrink-0">
                      <div className="w-10 h-10 rounded-full overflow-hidden bg-gray-800">
                        {notif.actor?.avatar_url ? (
                          <img src={notif.actor.avatar_url} className="w-full h-full object-cover" alt="" />
                        ) : (
                          <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-emerald-500 to-cyan-500 text-white text-sm font-bold">
                            {notif.actor?.username?.[0]?.toUpperCase() || '?'}
                          </div>
                        )}
                      </div>
                      <div className={`absolute -bottom-0.5 -right-0.5 w-5 h-5 rounded-full ${color} flex items-center justify-center border-2 border-black`}>
                        <Icon className={`w-2.5 h-2.5 ${iconColor}`} />
                      </div>
                    </div>

                    {/* Content */}
                    <div className="flex-1 min-w-0 text-left">
                      <p className="text-sm leading-snug">
                        <span className={`font-semibold ${notif.read ? 'text-gray-300' : 'text-white'}`}>
                          @{notif.actor?.username || 'someone'}
                        </span>{' '}
                        <span className={notif.read ? 'text-gray-500' : 'text-gray-300'}>
                          {getNotificationText(notif)}
                        </span>
                      </p>
                      <span className="text-gray-600 text-[10px]">{timeAgo(notif.created_at)}</span>
                    </div>

                    {/* Unread dot */}
                    {!notif.read && (
                      <div className="w-2 h-2 bg-emerald-500 rounded-full flex-shrink-0" />
                    )}
                  </button>
                );
              })}
            </div>
          )}
        </div>
      )}
    </div>
  );
};

// Conversation item component
const ConversationItem: React.FC<{
  conversation: Conversation;
  onPress: () => void;
  timeAgo: (date: string) => string;
}> = ({ conversation, onPress, timeAgo }) => {
  const hasUnread = conversation.unreadCount > 0;

  return (
    <button
      onClick={onPress}
      className="w-full flex items-center gap-3 px-4 py-3 hover:bg-white/5 transition-colors active:bg-white/10"
    >
      <div className="relative flex-shrink-0">
        <div className="w-12 h-12 rounded-full overflow-hidden bg-gray-800">
          {conversation.avatar_url ? (
            <img src={conversation.avatar_url} className="w-full h-full object-cover" alt={conversation.username} />
          ) : (
            <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-emerald-500 to-cyan-500 text-white font-bold text-lg">
              {conversation.username[0]?.toUpperCase()}
            </div>
          )}
        </div>
        <div className="absolute -bottom-0.5 -right-0.5 w-3.5 h-3.5 bg-emerald-500 rounded-full border-2 border-black" />
      </div>

      <div className="flex-1 min-w-0 text-left">
        <div className="flex items-center justify-between">
          <span className={`text-sm truncate ${hasUnread ? 'text-white font-bold' : 'text-white font-medium'}`}>
            @{conversation.username}
          </span>
          <span className={`text-[10px] flex-shrink-0 ml-2 ${hasUnread ? 'text-emerald-400' : 'text-gray-600'}`}>
            {timeAgo(conversation.lastMessageTime)}
          </span>
        </div>
        <div className="flex items-center justify-between mt-0.5">
          <p className={`text-sm truncate ${hasUnread ? 'text-gray-300 font-medium' : 'text-gray-500'}`}>
            {conversation.isLastMessageMine && <span className="text-gray-600">You: </span>}
            {conversation.lastMessage}
          </p>
          {hasUnread && (
            <span className="ml-2 w-5 h-5 bg-emerald-500 rounded-full flex items-center justify-center flex-shrink-0">
              <span className="text-[10px] text-white font-bold">{conversation.unreadCount}</span>
            </span>
          )}
        </div>
      </div>
    </button>
  );
};

export default InboxScreen;
