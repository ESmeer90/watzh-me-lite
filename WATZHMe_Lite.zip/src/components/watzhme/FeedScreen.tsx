import React, { useEffect, useRef, useState, useCallback } from 'react';
import { RefreshCw, Wifi, ArrowDown } from 'lucide-react';
import PostCard from './PostCard';
import CommentsSheet from './CommentsSheet';
import { useFeedStore } from '@/stores/feedStore';
import { useAuthStore } from '@/stores/authStore';

interface FeedScreenProps {
  onProfileClick: (userId: string) => void;
  onAuthRequired: () => void;
}

const FeedScreen: React.FC<FeedScreenProps> = ({ onProfileClick, onAuthRequired }) => {
  const {
    posts, followingPosts, isLoading, isLoadingFollowing, hasMore, hasMoreFollowing,
    fetchPosts, fetchFollowingPosts, toggleLike, toggleBookmark, toggleFollow,
    likedPosts, bookmarkedPosts, followingUsers,
    fetchUserLikes, fetchUserBookmarks, fetchUserFollowing,
    subscribeToFeed, unsubscribeFromFeed,
    incrementViews,
  } = useFeedStore();
  const { user, isAuthenticated } = useAuthStore();
  const [currentIndex, setCurrentIndex] = useState(0);
  const [commentPostId, setCommentPostId] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<'foryou' | 'following'>('foryou');
  const [refreshing, setRefreshing] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);

  // View tracking: track which posts have been viewed this session
  const viewedPostsRef = useRef<Set<string>>(new Set());
  const viewTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  const activePosts = activeTab === 'foryou' ? posts : followingPosts;
  const activeLoading = activeTab === 'foryou' ? isLoading : isLoadingFollowing;
  const activeHasMore = activeTab === 'foryou' ? hasMore : hasMoreFollowing;

  useEffect(() => {
    if (posts.length === 0) {
      fetchPosts(true);
    }
    subscribeToFeed();
    return () => unsubscribeFromFeed();
  }, []);

  // Fetch user-specific data when authenticated
  useEffect(() => {
    if (isAuthenticated && user?.id) {
      fetchUserLikes(user.id);
      fetchUserBookmarks(user.id);
      fetchUserFollowing(user.id);
    }
  }, [isAuthenticated, user?.id]);

  // Fetch following posts when tab changes
  useEffect(() => {
    if (activeTab === 'following' && isAuthenticated && user?.id && followingPosts.length === 0) {
      fetchFollowingPosts(user.id, true);
    }
  }, [activeTab, isAuthenticated]);

  // View tracking: when currentIndex changes, start a timer
  // If the user stays on this post for 800ms+, count it as a view
  useEffect(() => {
    // Clear any existing timer
    if (viewTimerRef.current) {
      clearTimeout(viewTimerRef.current);
      viewTimerRef.current = null;
    }

    const currentPost = activePosts[currentIndex];
    if (!currentPost) return;

    // Check if already viewed this session
    if (viewedPostsRef.current.has(currentPost.id)) return;

    // Start 800ms timer for view counting
    viewTimerRef.current = setTimeout(() => {
      if (!viewedPostsRef.current.has(currentPost.id)) {
        viewedPostsRef.current.add(currentPost.id);
        incrementViews(currentPost.id);
        console.log('[Feed] View counted for post:', currentPost.id);
      }
    }, 800);

    return () => {
      if (viewTimerRef.current) {
        clearTimeout(viewTimerRef.current);
        viewTimerRef.current = null;
      }
    };
  }, [currentIndex, activePosts, incrementViews]);

  const handleScroll = useCallback(() => {
    const container = containerRef.current;
    if (!container) return;

    const scrollTop = container.scrollTop;
    const itemHeight = container.clientHeight;
    const newIndex = Math.round(scrollTop / itemHeight);
    if (newIndex !== currentIndex) {
      setCurrentIndex(newIndex);
    }

    // Load more when near bottom
    if (scrollTop + itemHeight * 2 >= container.scrollHeight && activeHasMore && !activeLoading) {
      if (activeTab === 'foryou') {
        fetchPosts();
      } else if (user?.id) {
        fetchFollowingPosts(user.id);
      }
    }
  }, [currentIndex, activeHasMore, activeLoading, activeTab, user?.id]);

  const handleLike = (postId: string) => {
    if (!isAuthenticated) {
      onAuthRequired();
      return;
    }
    toggleLike(postId, user?.id);
  };

  const handleBookmark = (postId: string) => {
    if (!isAuthenticated) {
      onAuthRequired();
      return;
    }
    toggleBookmark(postId, user?.id);
  };

  const handleFollow = (targetUserId: string) => {
    if (!isAuthenticated || !user?.id) {
      onAuthRequired();
      return;
    }
    toggleFollow(targetUserId, user.id);
  };

  const handleComment = (postId: string) => {
    setCommentPostId(postId);
  };

  const handleShare = async (post: any) => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: 'WATZHMe',
          text: post.caption,
          url: window.location.href,
        });
      } catch {}
    }
  };

  const handleRefresh = async () => {
    setRefreshing(true);
    // Reset viewed posts on refresh
    viewedPostsRef.current.clear();
    if (activeTab === 'foryou') {
      await fetchPosts(true);
    } else if (user?.id) {
      await fetchFollowingPosts(user.id, true);
    }
    if (containerRef.current) {
      containerRef.current.scrollTo({ top: 0, behavior: 'smooth' });
    }
    setCurrentIndex(0);
    setRefreshing(false);
  };

  const switchTab = (tab: 'foryou' | 'following') => {
    if (tab === 'following' && !isAuthenticated) {
      onAuthRequired();
      return;
    }
    setActiveTab(tab);
    setCurrentIndex(0);
    if (containerRef.current) {
      containerRef.current.scrollTo({ top: 0 });
    }
  };

  if (activeLoading && activePosts.length === 0) {
    return (
      <div className="h-full w-full bg-black flex flex-col items-center justify-center">
        <div className="w-12 h-12 border-3 border-emerald-400 border-t-transparent rounded-full animate-spin" />
        <p className="text-gray-500 text-sm mt-4">Loading your feed...</p>
      </div>
    );
  }

  if (!activeLoading && activePosts.length === 0) {
    return (
      <div className="h-full w-full bg-black flex flex-col relative">
        <FeedHeader activeTab={activeTab} onTabChange={switchTab} />
        <div className="flex-1 flex flex-col items-center justify-center px-8 text-center">
          <div className="w-20 h-20 rounded-full bg-gradient-to-br from-emerald-500/20 to-cyan-500/20 flex items-center justify-center mb-4">
            {activeTab === 'following' ? (
              <Wifi className="w-8 h-8 text-emerald-400" />
            ) : (
              <RefreshCw className="w-8 h-8 text-emerald-400" />
            )}
          </div>
          <h3 className="text-white text-lg font-semibold mb-2">
            {activeTab === 'following' ? 'Follow creators to see their posts' : 'No posts yet'}
          </h3>
          <p className="text-gray-500 text-sm mb-6">
            {activeTab === 'following'
              ? 'Posts from people you follow will appear here'
              : 'Be the first to share a moment!'
            }
          </p>
          <button
            onClick={handleRefresh}
            className="px-6 py-2.5 bg-emerald-500 text-white rounded-full text-sm font-medium hover:bg-emerald-600 transition-colors active:scale-95"
          >
            {activeTab === 'following' ? 'Discover People' : 'Refresh Feed'}
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="h-full w-full bg-black relative">
      {/* Feed header overlay */}
      <FeedHeader activeTab={activeTab} onTabChange={switchTab} />

      {/* Refresh indicator */}
      {refreshing && (
        <div className="absolute top-12 left-1/2 -translate-x-1/2 z-40 px-4 py-2 bg-black/80 backdrop-blur-sm rounded-full flex items-center gap-2">
          <div className="w-4 h-4 border-2 border-emerald-400 border-t-transparent rounded-full animate-spin" />
          <span className="text-emerald-400 text-xs font-medium">Refreshing...</span>
        </div>
      )}

      {/* New posts indicator */}
      {currentIndex > 0 && (
        <button
          onClick={handleRefresh}
          className="absolute top-14 left-1/2 -translate-x-1/2 z-30 px-3 py-1.5 bg-emerald-500 rounded-full flex items-center gap-1.5 shadow-lg shadow-emerald-500/30 hover:bg-emerald-400 transition-all active:scale-95"
        >
          <ArrowDown className="w-3 h-3 text-white" />
          <span className="text-white text-[10px] font-semibold">Back to top</span>
        </button>
      )}

      {/* Scrollable feed */}
      <div
        ref={containerRef}
        onScroll={handleScroll}
        className="h-full w-full overflow-y-scroll snap-y snap-mandatory scrollbar-hide"
        style={{ scrollSnapType: 'y mandatory' }}
      >
        {activePosts.map((post, index) => (
          <div
            key={post.id}
            className="h-full w-full snap-start snap-always flex-shrink-0"
            style={{ scrollSnapAlign: 'start' }}
          >
            <PostCard
              post={post}
              isLiked={likedPosts.has(post.id)}
              isBookmarked={bookmarkedPosts.has(post.id)}
              isActive={index === currentIndex}
              onLike={() => handleLike(post.id)}
              onComment={() => handleComment(post.id)}
              onShare={() => handleShare(post)}
              onBookmark={() => handleBookmark(post.id)}
              onProfileClick={onProfileClick}
              isAuthenticated={isAuthenticated}
              isFollowing={followingUsers.has(post.user_id)}
              onFollow={() => handleFollow(post.user_id)}
            />
          </div>
        ))}

        {/* Loading more indicator */}
        {activeLoading && activePosts.length > 0 && (
          <div className="h-20 flex items-center justify-center">
            <div className="w-6 h-6 border-2 border-emerald-400 border-t-transparent rounded-full animate-spin" />
          </div>
        )}
      </div>

      {/* Comments sheet */}
      <CommentsSheet
        postId={commentPostId || ''}
        isOpen={!!commentPostId}
        onClose={() => setCommentPostId(null)}
        onAuthRequired={onAuthRequired}
      />
    </div>
  );
};

// Feed header component
const FeedHeader: React.FC<{
  activeTab: 'foryou' | 'following';
  onTabChange: (tab: 'foryou' | 'following') => void;
}> = ({ activeTab, onTabChange }) => (
  <div className="absolute top-0 left-0 right-0 z-30 flex items-center justify-center pt-3 pb-8 bg-gradient-to-b from-black/70 via-black/30 to-transparent pointer-events-none">
    <div className="flex items-center gap-6 pointer-events-auto">
      <button
        onClick={() => onTabChange('following')}
        className={`text-sm font-medium transition-all duration-200 ${
          activeTab === 'following' ? 'text-white font-bold' : 'text-gray-400 hover:text-gray-200'
        }`}
      >
        Following
        {activeTab === 'following' && (
          <div className="mt-1 mx-auto w-6 h-0.5 bg-white rounded-full" />
        )}
      </button>
      <div className="w-px h-4 bg-gray-600" />
      <button
        onClick={() => onTabChange('foryou')}
        className={`text-sm font-medium transition-all duration-200 ${
          activeTab === 'foryou' ? 'text-white font-bold' : 'text-gray-400 hover:text-gray-200'
        }`}
      >
        For You
        {activeTab === 'foryou' && (
          <div className="mt-1 mx-auto w-6 h-0.5 bg-white rounded-full" />
        )}
      </button>
    </div>
  </div>
);

export default FeedScreen;
