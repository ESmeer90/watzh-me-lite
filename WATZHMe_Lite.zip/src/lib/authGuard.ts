/**
 * authGuard.ts
 * -----------
 * Simple auth guard for sensitive mutations (likes, comments, messages, follows).
 * If no active session exists, shows a "Please log in" toast and returns false.
 * Usage: if (!requireAuth()) return;
 */

import { supabase } from '@/lib/supabase';
import { toast } from '@/hooks/use-toast';

/**
 * Synchronous check using a cached session reference.
 * Call this before any mutation that requires authentication.
 * Returns true if authenticated, false otherwise (and shows toast).
 */
let _cachedUserId: string | null = null;

// Initialize cached session on load
supabase.auth.getSession().then(({ data }) => {
  _cachedUserId = data.session?.user?.id ?? null;
});

// Keep cache in sync with auth state changes
supabase.auth.onAuthStateChange((_event, session) => {
  _cachedUserId = session?.user?.id ?? null;
});

/**
 * requireAuth — call before any sensitive mutation.
 * @param userId Optional userId to double-check (from store state).
 * @returns true if user is authenticated, false if not (shows toast).
 */
export function requireAuth(userId?: string | null): boolean {
  const isAuthed = !!(userId || _cachedUserId);
  if (!isAuthed) {
    toast({
      title: 'Please log in',
      description: 'You need to be signed in to perform this action.',
      variant: 'destructive',
    });
    return false;
  }
  return true;
}
