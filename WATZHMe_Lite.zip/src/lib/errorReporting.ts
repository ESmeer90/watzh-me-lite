/**
 * WATZHMe Lite - Error Reporting & Crash Analytics
 * Sends error reports to Sentry via edge function proxy
 */

import { supabase } from '@/lib/supabase';

const APP_VERSION = '1.0.0';

interface ErrorReport {
  error_message: string;
  error_stack?: string;
  error_type?: string;
  component?: string;
  user_id?: string;
  username?: string;
  platform?: string;
  app_version?: string;
  timestamp?: string;
  extra_context?: Record<string, any>;
}

// Queue for batching errors (avoid spamming)
let errorQueue: ErrorReport[] = [];
let flushTimer: ReturnType<typeof setTimeout> | null = null;
const MAX_QUEUE_SIZE = 10;
const FLUSH_INTERVAL = 5000; // 5 seconds

/**
 * Report an error to Sentry via edge function
 */
export async function reportError(
  error: Error | string,
  context?: {
    component?: string;
    userId?: string;
    username?: string;
    extra?: Record<string, any>;
  }
): Promise<void> {
  const errorMessage = typeof error === 'string' ? error : error.message;
  const errorStack = typeof error === 'string' ? undefined : error.stack;
  const errorType = typeof error === 'string' ? 'Error' : error.name || 'Error';

  console.error(`[ErrorReporting] ${errorType}: ${errorMessage}`, context);

  const report: ErrorReport = {
    error_message: errorMessage,
    error_stack: errorStack,
    error_type: errorType,
    component: context?.component || 'unknown',
    user_id: context?.userId,
    username: context?.username,
    platform: 'web',
    app_version: APP_VERSION,
    timestamp: new Date().toISOString(),
    extra_context: {
      ...context?.extra,
      url: window.location.href,
      userAgent: navigator.userAgent,
      online: navigator.onLine,
      screen: `${window.innerWidth}x${window.innerHeight}`,
    },
  };

  errorQueue.push(report);

  // Flush immediately for critical errors
  if (errorType === 'fatal' || errorQueue.length >= MAX_QUEUE_SIZE) {
    await flushErrors();
  } else {
    // Schedule flush
    if (!flushTimer) {
      flushTimer = setTimeout(() => {
        flushErrors();
        flushTimer = null;
      }, FLUSH_INTERVAL);
    }
  }
}

/**
 * Flush queued errors to Sentry
 */
async function flushErrors(): Promise<void> {
  if (errorQueue.length === 0) return;

  const batch = [...errorQueue];
  errorQueue = [];

  for (const report of batch) {
    try {
      await supabase.functions.invoke('report-error', {
        body: report,
      });
    } catch (err) {
      // Don't recurse on error reporting failures
      console.warn('[ErrorReporting] Failed to send error report:', err);
    }
  }
}

/**
 * Set up global error handlers
 */
export function initErrorReporting(): void {
  console.log('[ErrorReporting] Initializing crash reporting v' + APP_VERSION);

  // Catch unhandled errors
  window.addEventListener('error', (event) => {
    reportError(event.error || event.message, {
      component: 'global',
      extra: {
        filename: event.filename,
        lineno: event.lineno,
        colno: event.colno,
      },
    });
  });

  // Catch unhandled promise rejections
  window.addEventListener('unhandledrejection', (event) => {
    const error = event.reason instanceof Error
      ? event.reason
      : String(event.reason || 'Unhandled promise rejection');
    
    reportError(error, {
      component: 'promise',
      extra: { type: 'unhandledrejection' },
    });
  });

  // Report app lifecycle events
  window.addEventListener('beforeunload', () => {
    flushErrors(); // Best effort flush on page close
  });

  // Network status changes
  window.addEventListener('offline', () => {
    console.log('[ErrorReporting] App went offline');
  });

  window.addEventListener('online', () => {
    console.log('[ErrorReporting] App came back online');
    flushErrors(); // Flush any queued errors
  });
}

/**
 * Performance monitoring - track slow operations
 */
export function trackPerformance(operation: string, durationMs: number, threshold = 3000): void {
  if (durationMs > threshold) {
    console.warn(`[Performance] Slow operation: ${operation} took ${durationMs}ms`);
    reportError(`Slow operation: ${operation} (${durationMs}ms)`, {
      component: 'performance',
      extra: { operation, durationMs, threshold },
    });
  }
}
