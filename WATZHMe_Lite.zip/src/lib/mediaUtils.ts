/**
 * Media Utilities for WATZHMe Lite
 * - Image compression via Canvas API
 * - Video thumbnail generation
 * - File size formatting
 * - Progress simulation
 */

/**
 * Compress an image file using Canvas API
 * Reduces quality and optionally resizes
 */
export async function compressImage(
  file: File,
  maxWidth = 1920,
  maxHeight = 1920,
  quality = 0.8
): Promise<{ blob: Blob; width: number; height: number }> {
  console.log(`[MediaUtils] Compressing image: ${file.name}, size: ${formatFileSize(file.size)}`);

  return new Promise((resolve, reject) => {
    const img = new Image();
    const url = URL.createObjectURL(file);

    img.onload = () => {
      URL.revokeObjectURL(url);

      let { width, height } = img;

      // Scale down if needed
      if (width > maxWidth || height > maxHeight) {
        const ratio = Math.min(maxWidth / width, maxHeight / height);
        width = Math.round(width * ratio);
        height = Math.round(height * ratio);
      }

      const canvas = document.createElement('canvas');
      canvas.width = width;
      canvas.height = height;

      const ctx = canvas.getContext('2d');
      if (!ctx) {
        reject(new Error('Could not get canvas context'));
        return;
      }

      ctx.drawImage(img, 0, 0, width, height);

      canvas.toBlob(
        (blob) => {
          if (!blob) {
            reject(new Error('Failed to compress image'));
            return;
          }
          console.log(`[MediaUtils] Compressed: ${formatFileSize(file.size)} → ${formatFileSize(blob.size)} (${Math.round((1 - blob.size / file.size) * 100)}% reduction)`);
          resolve({ blob, width, height });
        },
        'image/jpeg',
        quality
      );
    };

    img.onerror = () => {
      URL.revokeObjectURL(url);
      reject(new Error('Failed to load image for compression'));
    };

    img.src = url;
  });
}

/**
 * Generate a thumbnail from a video file
 * Captures a frame at the specified time (default: 1 second)
 */
export async function generateVideoThumbnail(
  file: File,
  captureTime = 1,
  maxWidth = 640,
  quality = 0.7
): Promise<Blob> {
  console.log(`[MediaUtils] Generating video thumbnail for: ${file.name}`);

  return new Promise((resolve, reject) => {
    const video = document.createElement('video');
    const url = URL.createObjectURL(file);

    video.preload = 'metadata';
    video.muted = true;
    video.playsInline = true;

    const cleanup = () => {
      URL.revokeObjectURL(url);
      video.remove();
    };

    video.onloadedmetadata = () => {
      // Seek to capture time or 25% of duration
      const seekTime = Math.min(captureTime, video.duration * 0.25);
      video.currentTime = seekTime;
    };

    video.onseeked = () => {
      try {
        const canvas = document.createElement('canvas');
        let width = video.videoWidth;
        let height = video.videoHeight;

        // Scale down
        if (width > maxWidth) {
          const ratio = maxWidth / width;
          width = maxWidth;
          height = Math.round(height * ratio);
        }

        canvas.width = width;
        canvas.height = height;

        const ctx = canvas.getContext('2d');
        if (!ctx) {
          cleanup();
          reject(new Error('Could not get canvas context'));
          return;
        }

        ctx.drawImage(video, 0, 0, width, height);

        canvas.toBlob(
          (blob) => {
            cleanup();
            if (!blob) {
              reject(new Error('Failed to generate thumbnail'));
              return;
            }
            console.log(`[MediaUtils] Thumbnail generated: ${formatFileSize(blob.size)}`);
            resolve(blob);
          },
          'image/jpeg',
          quality
        );
      } catch (err) {
        cleanup();
        reject(err);
      }
    };

    video.onerror = () => {
      cleanup();
      reject(new Error('Failed to load video for thumbnail generation'));
    };

    // Timeout after 10 seconds
    setTimeout(() => {
      cleanup();
      reject(new Error('Video thumbnail generation timed out'));
    }, 10000);

    video.src = url;
  });
}

/**
 * Format file size to human-readable string
 */
export function formatFileSize(bytes: number): string {
  if (bytes === 0) return '0 B';
  const k = 1024;
  const sizes = ['B', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return `${parseFloat((bytes / Math.pow(k, i)).toFixed(1))} ${sizes[i]}`;
}

/**
 * Get file extension from MIME type
 */
export function getExtFromMime(mime: string): string {
  const map: Record<string, string> = {
    'image/jpeg': 'jpg',
    'image/jpg': 'jpg',
    'image/png': 'png',
    'image/gif': 'gif',
    'image/webp': 'webp',
    'video/mp4': 'mp4',
    'video/quicktime': 'mov',
    'video/webm': 'webm',
    'video/x-msvideo': 'avi',
  };
  return map[mime] || 'bin';
}

/**
 * Validate file for upload
 */
export function validateFile(file: File): { valid: boolean; error?: string } {
  const isImage = file.type.startsWith('image/');
  const isVideo = file.type.startsWith('video/');

  if (!isImage && !isVideo) {
    return { valid: false, error: 'Please select an image or video file' };
  }

  // 50MB max for images, 100MB for videos
  const maxSize = isVideo ? 100 * 1024 * 1024 : 50 * 1024 * 1024;
  if (file.size > maxSize) {
    return {
      valid: false,
      error: `File too large (${formatFileSize(file.size)}). Max: ${formatFileSize(maxSize)}`,
    };
  }

  // Warn for large videos
  if (isVideo && file.size > 30 * 1024 * 1024) {
    console.warn(`[MediaUtils] Large video file: ${formatFileSize(file.size)}. Upload may take a while.`);
  }

  return { valid: true };
}
