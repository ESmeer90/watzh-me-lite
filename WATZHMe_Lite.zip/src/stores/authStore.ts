import { create } from 'zustand';
import { supabase } from '@/lib/supabase';

export interface Profile {
  id: string;
  username: string;
  full_name: string | null;
  avatar_url: string | null;
  bio: string;
  followers_count: number;
  following_count: number;
  posts_count: number;
  created_at: string;
}

export interface AuthState {
  user: any | null;
  profile: Profile | null;
  session: any | null;
  isLoading: boolean;
  isAuthenticated: boolean;
  error: string | null;
  // Email verification
  emailConfirmationPending: boolean;
  pendingEmail: string | null;
  resendCooldown: boolean;
  login: (email: string, password: string) => Promise<boolean>;
  register: (email: string, password: string, username: string, fullName: string) => Promise<boolean>;
  logout: () => Promise<void>;
  fetchProfile: (userId: string) => Promise<void>;
  updateProfile: (updates: Partial<Profile>) => Promise<boolean>;
  clearError: () => void;
  clearEmailConfirmation: () => void;
  resendVerificationEmail: () => Promise<boolean>;
  initialize: () => Promise<void>;
}

export const useAuthStore = create<AuthState>((set, get) => ({
  user: null,
  profile: null,
  session: null,
  isLoading: true,
  isAuthenticated: false,
  error: null,
  emailConfirmationPending: false,
  pendingEmail: null,
  resendCooldown: false,

  clearError: () => set({ error: null }),

  clearEmailConfirmation: () => set({ emailConfirmationPending: false, pendingEmail: null }),

  resendVerificationEmail: async () => {
    const { pendingEmail, resendCooldown } = get();
    if (!pendingEmail || resendCooldown) return false;

    // Set cooldown to prevent spam
    set({ resendCooldown: true });

    try {
      const { error } = await supabase.auth.resend({
        type: 'signup',
        email: pendingEmail,
      });

      if (error) {
        console.error('[Auth] Resend verification error:', error.message);
        set({ error: error.message, resendCooldown: false });
        return false;
      }

      console.log('[Auth] Verification email resent to:', pendingEmail);

      // Reset cooldown after 60 seconds
      setTimeout(() => {
        set({ resendCooldown: false });
      }, 60000);

      return true;
    } catch (err: any) {
      const msg = typeof err === 'object' && err?.message ? err.message : 'Failed to resend verification email.';
      set({ error: msg, resendCooldown: false });
      return false;
    }
  },

  initialize: async () => {
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (session?.user) {
        set({ user: session.user, session, isAuthenticated: true });
        await get().fetchProfile(session.user.id);
      }
    } catch (err) {
      console.error('Init error:', err);
    } finally {
      set({ isLoading: false });
    }

    try {
      supabase.auth.onAuthStateChange(async (event, session) => {
        console.log('[Auth] State change:', event);
        if (session?.user) {
          set({ user: session.user, session, isAuthenticated: true, emailConfirmationPending: false, pendingEmail: null });
          await get().fetchProfile(session.user.id);
        } else {
          set({ user: null, session: null, profile: null, isAuthenticated: false });
        }
      });
    } catch (err) {
      console.error('Auth state change listener error:', err);
    }
  },

  login: async (email: string, password: string) => {
    set({ isLoading: true, error: null, emailConfirmationPending: false });
    try {
      const { data, error } = await supabase.auth.signInWithPassword({ email, password });
      if (error) {
        // Detect unconfirmed email — Supabase returns "Email not confirmed" error
        const isUnconfirmed =
          error.message?.toLowerCase().includes('email not confirmed') ||
          error.message?.toLowerCase().includes('email_not_confirmed');

        if (isUnconfirmed) {
          set({
            error: null,
            isLoading: false,
            emailConfirmationPending: true,
            pendingEmail: email,
          });
          return false;
        }

        set({ error: error.message, isLoading: false });
        return false;
      }
      set({ user: data.user, session: data.session, isAuthenticated: true, isLoading: false });
      if (data.user) await get().fetchProfile(data.user.id);
      return true;
    } catch (err: any) {
      const msg = typeof err === 'object' && err?.message ? err.message : 'Login failed. Please try again.';
      set({ error: msg, isLoading: false });
      return false;
    }
  },

  register: async (email: string, password: string, username: string, fullName: string) => {
    set({ isLoading: true, error: null, emailConfirmationPending: false });
    try {
      const { data, error } = await supabase.auth.signUp({ email, password });
      if (error) {
        set({ error: error.message, isLoading: false });
        return false;
      }

      if (data.user) {
        // Create profile row
        const { error: profileError } = await supabase.from('profiles').insert({
          id: data.user.id,
          username: username.toLowerCase().replace(/\s/g, '_'),
          full_name: fullName,
          bio: '',
          avatar_url: null,
        });
        if (profileError) {
          console.error('[Auth] Profile creation error:', profileError.message);
          // Don't block registration if profile creation fails — it can be retried
        }

        // Check if email confirmation is required:
        // When "Confirm email" is enabled, session will be null even though user is created
        if (!data.session) {
          console.log('[Auth] Email confirmation required for:', email);
          set({
            isLoading: false,
            emailConfirmationPending: true,
            pendingEmail: email,
            error: null,
          });
          // Return true to indicate signup itself succeeded (just needs confirmation)
          return true;
        }

        // If session exists, email confirmation is not required (auto-confirmed)
        set({ user: data.user, session: data.session, isAuthenticated: true, isLoading: false });
        await get().fetchProfile(data.user.id);
      }
      return true;
    } catch (err: any) {
      const msg = typeof err === 'object' && err?.message ? err.message : 'Registration failed. Please try again.';
      set({ error: msg, isLoading: false });
      return false;
    }
  },

  logout: async () => {
    try {
      await supabase.auth.signOut();
    } catch (err) {
      console.error('Logout error:', err);
    }
    set({ user: null, session: null, profile: null, isAuthenticated: false, emailConfirmationPending: false, pendingEmail: null });
  },

  fetchProfile: async (userId: string) => {
    try {
      const { data, error } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', userId)
        .single();
      if (data && !error) {
        set({ profile: data as Profile });
      }
    } catch (err) {
      console.error('Fetch profile error:', err);
    }
  },

  updateProfile: async (updates: Partial<Profile>) => {
    const { user } = get();
    if (!user) return false;
    try {
      const { error } = await supabase
        .from('profiles')
        .update(updates)
        .eq('id', user.id);
      if (error) {
        set({ error: error.message });
        return false;
      }
      await get().fetchProfile(user.id);
      return true;
    } catch (err: any) {
      const msg = typeof err === 'object' && err?.message ? err.message : 'Update failed';
      set({ error: msg });
      return false;
    }
  },
}));
