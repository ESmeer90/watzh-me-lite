import { create } from 'zustand';
import { supabase } from '@/lib/supabase';

export interface Message {
  id: string;
  sender_id: string;
  receiver_id: string;
  content: string;
  created_at: string;
  read: boolean;
}

export interface Conversation {
  userId: string;
  username: string;
  avatar_url: string | null;
  full_name: string | null;
  lastMessage: string;
  lastMessageTime: string;
  unreadCount: number;
  isLastMessageMine: boolean;
}

interface MessageState {
  conversations: Conversation[];
  currentMessages: Message[];
  isLoadingConversations: boolean;
  isLoadingMessages: boolean;
  totalUnread: number;
  realtimeChannel: any | null;

  fetchConversations: (userId: string) => Promise<void>;
  fetchMessages: (userId: string, otherUserId: string) => Promise<void>;
  sendMessage: (senderId: string, receiverId: string, content: string) => Promise<boolean>;
  markAsRead: (userId: string, otherUserId: string) => Promise<void>;
  subscribeToMessages: (userId: string) => void;
  unsubscribeFromMessages: () => void;
  addRealtimeMessage: (message: Message, currentUserId: string) => void;
}

export const useMessageStore = create<MessageState>((set, get) => ({
  conversations: [],
  currentMessages: [],
  isLoadingConversations: false,
  isLoadingMessages: false,
  totalUnread: 0,
  realtimeChannel: null,

  fetchConversations: async (userId: string) => {
    set({ isLoadingConversations: true });
    try {
      // Fetch all messages involving this user
      const { data: messages, error } = await supabase
        .from('messages')
        .select('*')
        .or(`sender_id.eq.${userId},receiver_id.eq.${userId}`)
        .order('created_at', { ascending: false });

      if (error || !messages) {
        set({ isLoadingConversations: false, conversations: [] });
        return;
      }

      // Group by conversation partner
      const convMap = new Map<string, { msgs: Message[] }>();
      messages.forEach((msg: Message) => {
        const partnerId = msg.sender_id === userId ? msg.receiver_id : msg.sender_id;
        if (!convMap.has(partnerId)) {
          convMap.set(partnerId, { msgs: [] });
        }
        convMap.get(partnerId)!.msgs.push(msg);
      });

      // Fetch profiles for all partners
      const partnerIds = Array.from(convMap.keys());
      if (partnerIds.length === 0) {
        set({ conversations: [], isLoadingConversations: false, totalUnread: 0 });
        return;
      }

      const { data: profiles } = await supabase
        .from('profiles')
        .select('id, username, avatar_url, full_name')
        .in('id', partnerIds);

      const profileMap = new Map<string, any>();
      (profiles || []).forEach((p: any) => profileMap.set(p.id, p));

      // Build conversations
      const convs: Conversation[] = [];
      let totalUnread = 0;

      convMap.forEach((val, partnerId) => {
        const profile = profileMap.get(partnerId);
        const lastMsg = val.msgs[0]; // Already sorted desc
        const unread = val.msgs.filter(m => m.receiver_id === userId && !m.read).length;
        totalUnread += unread;

        convs.push({
          userId: partnerId,
          username: profile?.username || 'Unknown',
          avatar_url: profile?.avatar_url || null,
          full_name: profile?.full_name || null,
          lastMessage: lastMsg.content,
          lastMessageTime: lastMsg.created_at,
          unreadCount: unread,
          isLastMessageMine: lastMsg.sender_id === userId,
        });
      });

      // Sort by last message time
      convs.sort((a, b) => new Date(b.lastMessageTime).getTime() - new Date(a.lastMessageTime).getTime());

      set({ conversations: convs, isLoadingConversations: false, totalUnread });
    } catch (err) {
      console.error('Fetch conversations error:', err);
      set({ isLoadingConversations: false, conversations: [] });
    }
  },

  fetchMessages: async (userId: string, otherUserId: string) => {
    set({ isLoadingMessages: true });
    try {
      const { data, error } = await supabase
        .from('messages')
        .select('*')
        .or(
          `and(sender_id.eq.${userId},receiver_id.eq.${otherUserId}),and(sender_id.eq.${otherUserId},receiver_id.eq.${userId})`
        )
        .order('created_at', { ascending: true });

      if (!error && data) {
        set({ currentMessages: data as Message[], isLoadingMessages: false });
      } else {
        set({ isLoadingMessages: false, currentMessages: [] });
      }
    } catch (err) {
      console.error('Fetch messages error:', err);
      set({ isLoadingMessages: false, currentMessages: [] });
    }
  },

  sendMessage: async (senderId: string, receiverId: string, content: string) => {
    try {
      const { error } = await supabase.from('messages').insert({
        sender_id: senderId,
        receiver_id: receiverId,
        content,
        read: false,
      });
      if (error) {
        console.error('Send message error:', error);
        return false;
      }
      return true;
    } catch (err) {
      console.error('Send message error:', err);
      return false;
    }
  },

  markAsRead: async (userId: string, otherUserId: string) => {
    try {
      await supabase
        .from('messages')
        .update({ read: true })
        .eq('sender_id', otherUserId)
        .eq('receiver_id', userId)
        .eq('read', false);
    } catch (err) {
      console.error('Mark as read error:', err);
    }
  },

  subscribeToMessages: (userId: string) => {
    try {
      const { realtimeChannel } = get();
      if (realtimeChannel) {
        supabase.removeChannel(realtimeChannel);
      }

      const channel = supabase
        .channel(`messages-${userId}`)
        .on(
          'postgres_changes',
          {
            event: 'INSERT',
            schema: 'public',
            table: 'messages',
          },
          (payload: any) => {
            const newMsg = payload.new as Message;
            // Only process messages involving this user
            if (newMsg.sender_id === userId || newMsg.receiver_id === userId) {
              get().addRealtimeMessage(newMsg, userId);
            }
          }
        )
        .subscribe();

      set({ realtimeChannel: channel });
    } catch (err) {
      console.error('Subscribe to messages error:', err);
    }
  },

  unsubscribeFromMessages: () => {
    try {
      const { realtimeChannel } = get();
      if (realtimeChannel) {
        supabase.removeChannel(realtimeChannel);
        set({ realtimeChannel: null });
      }
    } catch (err) {
      console.error('Unsubscribe error:', err);
    }
  },

  addRealtimeMessage: (message: Message, currentUserId: string) => {
    const { currentMessages, conversations } = get();

    // Add to current messages if it's part of the active chat
    const updatedMessages = [...currentMessages, message];
    
    // Update conversations
    const partnerId = message.sender_id === currentUserId ? message.receiver_id : message.sender_id;
    const existingConv = conversations.find(c => c.userId === partnerId);
    
    let updatedConversations: Conversation[];
    if (existingConv) {
      updatedConversations = conversations.map(c => {
        if (c.userId === partnerId) {
          return {
            ...c,
            lastMessage: message.content,
            lastMessageTime: message.created_at,
            unreadCount: message.receiver_id === currentUserId ? c.unreadCount + 1 : c.unreadCount,
            isLastMessageMine: message.sender_id === currentUserId,
          };
        }
        return c;
      });
    } else {
      // New conversation - we'll refetch to get profile info
      updatedConversations = conversations;
    }

    updatedConversations.sort((a, b) => new Date(b.lastMessageTime).getTime() - new Date(a.lastMessageTime).getTime());

    const totalUnread = updatedConversations.reduce((sum, c) => sum + c.unreadCount, 0);

    set({
      currentMessages: updatedMessages,
      conversations: updatedConversations,
      totalUnread,
    });
  },
}));
