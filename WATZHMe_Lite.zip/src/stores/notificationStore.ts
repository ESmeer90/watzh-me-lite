import { create } from 'zustand';
import { supabase } from '@/lib/supabase';

export interface Notification {
  id: string;
  user_id: string;
  actor_id: string;
  type: 'like' | 'comment' | 'follow' | 'message';
  post_id: string | null;
  comment_text: string | null;
  read: boolean;
  created_at: string;
  actor?: {
    username: string;
    avatar_url: string | null;
    full_name: string | null;
  };
}

interface NotificationState {
  notifications: Notification[];
  unreadCount: number;
  isLoading: boolean;
  realtimeChannel: any | null;

  fetchNotifications: (userId: string) => Promise<void>;
  markAsRead: (notificationId: string) => Promise<void>;
  markAllAsRead: (userId: string) => Promise<void>;
  subscribeToNotifications: (userId: string) => void;
  unsubscribeFromNotifications: () => void;
  createNotification: (data: {
    user_id: string;
    actor_id: string;
    type: 'like' | 'comment' | 'follow' | 'message';
    post_id?: string;
    comment_text?: string;
  }) => Promise<void>;
}

export const useNotificationStore = create<NotificationState>((set, get) => ({
  notifications: [],
  unreadCount: 0,
  isLoading: false,
  realtimeChannel: null,

  fetchNotifications: async (userId: string) => {
    set({ isLoading: true });
    try {
      console.log('[Notifications] Fetching for user:', userId);
      const { data, error } = await supabase
        .from('notifications')
        .select('*')
        .eq('user_id', userId)
        .order('created_at', { ascending: false })
        .limit(50);

      if (error) {
        console.error('[Notifications] Fetch error:', error);
        set({ isLoading: false });
        return;
      }

      const notifications = (data || []) as Notification[];

      // Fetch actor profiles
      const actorIds = [...new Set(notifications.map(n => n.actor_id))];
      if (actorIds.length > 0) {
        const { data: profiles } = await supabase
          .from('profiles')
          .select('id, username, avatar_url, full_name')
          .in('id', actorIds);

        const profileMap = new Map<string, any>();
        (profiles || []).forEach((p: any) => profileMap.set(p.id, p));

        notifications.forEach(n => {
          const profile = profileMap.get(n.actor_id);
          if (profile) {
            n.actor = {
              username: profile.username,
              avatar_url: profile.avatar_url,
              full_name: profile.full_name,
            };
          }
        });
      }

      const unreadCount = notifications.filter(n => !n.read).length;
      console.log(`[Notifications] Fetched ${notifications.length}, ${unreadCount} unread`);

      set({ notifications, unreadCount, isLoading: false });
    } catch (err) {
      console.error('[Notifications] Fetch exception:', err);
      set({ isLoading: false });
    }
  },

  markAsRead: async (notificationId: string) => {
    try {
      const { error } = await supabase
        .from('notifications')
        .update({ read: true })
        .eq('id', notificationId);

      if (!error) {
        const { notifications } = get();
        const updated = notifications.map(n =>
          n.id === notificationId ? { ...n, read: true } : n
        );
        const unreadCount = updated.filter(n => !n.read).length;
        set({ notifications: updated, unreadCount });
      }
    } catch (err) {
      console.error('[Notifications] Mark as read error:', err);
    }
  },

  markAllAsRead: async (userId: string) => {
    try {
      const { error } = await supabase
        .from('notifications')
        .update({ read: true })
        .eq('user_id', userId)
        .eq('read', false);

      if (!error) {
        const { notifications } = get();
        set({
          notifications: notifications.map(n => ({ ...n, read: true })),
          unreadCount: 0,
        });
      }
    } catch (err) {
      console.error('[Notifications] Mark all as read error:', err);
    }
  },

  subscribeToNotifications: (userId: string) => {
    const { realtimeChannel } = get();
    if (realtimeChannel) {
      try { supabase.removeChannel(realtimeChannel); } catch {}
    }

    try {
      const channel = supabase
        .channel(`notifications-${userId}`)
        .on(
          'postgres_changes',
          {
            event: 'INSERT',
            schema: 'public',
            table: 'notifications',
            filter: `user_id=eq.${userId}`,
          },
          async (payload: any) => {
            const newNotif = payload.new as Notification;
            console.log('[Notifications] Realtime new:', newNotif.type);

            // Fetch actor profile
            try {
              const { data: profile } = await supabase
                .from('profiles')
                .select('username, avatar_url, full_name')
                .eq('id', newNotif.actor_id)
                .single();

              if (profile) {
                newNotif.actor = profile;
              }
            } catch {}

            set(state => ({
              notifications: [newNotif, ...state.notifications],
              unreadCount: state.unreadCount + 1,
            }));
          }
        )
        .subscribe();

      set({ realtimeChannel: channel });
    } catch (err) {
      console.error('[Notifications] Subscribe error:', err);
    }
  },

  unsubscribeFromNotifications: () => {
    const { realtimeChannel } = get();
    if (realtimeChannel) {
      try { supabase.removeChannel(realtimeChannel); } catch {}
      set({ realtimeChannel: null });
    }
  },

  createNotification: async (data) => {
    try {
      // Don't notify yourself
      if (data.user_id === data.actor_id) return;

      const { error } = await supabase.from('notifications').insert({
        user_id: data.user_id,
        actor_id: data.actor_id,
        type: data.type,
        post_id: data.post_id || null,
        comment_text: data.comment_text || null,
      });

      if (error) {
        console.error('[Notifications] Create error:', error);
      }
    } catch (err) {
      console.error('[Notifications] Create exception:', err);
    }
  },
}));
