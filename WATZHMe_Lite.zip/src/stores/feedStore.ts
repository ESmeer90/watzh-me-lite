import { create } from 'zustand';
import { supabase } from '@/lib/supabase';
import { requireAuth } from '@/lib/authGuard';

export interface Post {
  id: string;
  user_id: string;
  media_url: string;
  thumbnail_url: string | null;
  caption: string;
  media_type: 'image' | 'video';
  likes_count: number;
  comments_count: number;
  shares_count: number;
  view_count: number;
  created_at: string;
  profiles?: {
    id: string;
    username: string;
    avatar_url: string | null;
    full_name: string | null;
  };
}

export interface Comment {
  id: string;
  post_id: string;
  user_id: string;
  content: string;
  created_at: string;
  profiles?: {
    username: string;
    avatar_url: string | null;
  };
}

interface FeedState {
  posts: Post[];
  followingPosts: Post[];
  isLoading: boolean;
  isLoadingFollowing: boolean;
  hasMore: boolean;
  hasMoreFollowing: boolean;
  currentPage: number;
  currentPageFollowing: number;
  likedPosts: Set<string>;
  bookmarkedPosts: Set<string>;
  followingUsers: Set<string>;
  realtimeChannel: any | null;

  fetchPosts: (reset?: boolean) => Promise<void>;
  fetchFollowingPosts: (userId: string, reset?: boolean) => Promise<void>;
  fetchUserLikes: (userId: string) => Promise<void>;
  fetchUserBookmarks: (userId: string) => Promise<void>;
  fetchUserFollowing: (userId: string) => Promise<void>;
  toggleLike: (postId: string, userId?: string) => Promise<void>;
  toggleBookmark: (postId: string, userId?: string) => Promise<void>;
  toggleFollow: (targetUserId: string, currentUserId: string) => Promise<boolean>;
  isFollowing: (userId: string) => boolean;
  addPost: (post: Omit<Post, 'id' | 'created_at' | 'likes_count' | 'comments_count' | 'shares_count' | 'view_count'>) => Promise<boolean>;
  deletePost: (postId: string, userId: string, mediaUrl?: string) => Promise<boolean>;
  fetchComments: (postId: string) => Promise<Comment[]>;
  addComment: (postId: string, userId: string, content: string) => Promise<boolean>;
  incrementViews: (postId: string) => Promise<void>;
  updatePostViewCount: (postId: string, viewCount: number) => void;
  subscribeToFeed: () => void;
  unsubscribeFromFeed: () => void;
  updatePostCounts: (postId: string, field: 'likes_count' | 'comments_count', delta: number) => void;
  getFollowCounts: (userId: string) => Promise<{ followers_count: number; following_count: number }>;
}


const PAGE_SIZE = 10;

export const useFeedStore = create<FeedState>((set, get) => ({
  posts: [],
  followingPosts: [],
  isLoading: false,
  isLoadingFollowing: false,
  hasMore: true,
  hasMoreFollowing: true,
  currentPage: 0,
  currentPageFollowing: 0,
  likedPosts: new Set<string>(),
  bookmarkedPosts: new Set<string>(),
  followingUsers: new Set<string>(),
  realtimeChannel: null,

  fetchPosts: async (reset = false) => {
    const { isLoading, currentPage, posts } = get();
    if (isLoading && !reset) return;

    const page = reset ? 0 : currentPage;
    set({ isLoading: true });

    try {
      console.log(`[Feed] Fetching posts page ${page}${reset ? ' (reset)' : ''}`);
      const { data, error } = await supabase
        .from('posts')
        .select('*, profiles(id, username, avatar_url, full_name)')
        .order('created_at', { ascending: false })
        .range(page * PAGE_SIZE, (page + 1) * PAGE_SIZE - 1);

      if (error) {
        console.error('[Feed] Fetch posts error:', error);
        set({ isLoading: false });
        return;
      }

      const newPosts = (data || []).map((p: any) => ({
        ...p,
        view_count: p.view_count ?? 0,
      })) as Post[];
      console.log(`[Feed] Fetched ${newPosts.length} posts`);
      
      set({
        posts: reset ? newPosts : [...posts, ...newPosts],
        currentPage: page + 1,
        hasMore: newPosts.length === PAGE_SIZE,
        isLoading: false,
      });
    } catch (err) {
      console.error('[Feed] Fetch error:', err);
      set({ isLoading: false });
    }
  },

  fetchFollowingPosts: async (userId: string, reset = false) => {
    const { isLoadingFollowing, currentPageFollowing, followingPosts, followingUsers } = get();
    if (isLoadingFollowing && !reset) return;

    const page = reset ? 0 : currentPageFollowing;
    set({ isLoadingFollowing: true });

    try {
      const followIds = Array.from(followingUsers);
      if (followIds.length === 0) {
        set({ followingPosts: [], isLoadingFollowing: false, hasMoreFollowing: false });
        return;
      }

      const { data, error } = await supabase
        .from('posts')
        .select('*, profiles(id, username, avatar_url, full_name)')
        .in('user_id', followIds)
        .order('created_at', { ascending: false })
        .range(page * PAGE_SIZE, (page + 1) * PAGE_SIZE - 1);

      if (error) {
        set({ isLoadingFollowing: false });
        return;
      }

      const newPosts = (data || []).map((p: any) => ({
        ...p,
        view_count: p.view_count ?? 0,
      })) as Post[];
      set({
        followingPosts: reset ? newPosts : [...followingPosts, ...newPosts],
        currentPageFollowing: page + 1,
        hasMoreFollowing: newPosts.length === PAGE_SIZE,
        isLoadingFollowing: false,
      });
    } catch (err) {
      console.error('[Feed] Fetch following error:', err);
      set({ isLoadingFollowing: false });
    }
  },

  fetchUserLikes: async (userId: string) => {
    try {
      const { data } = await supabase
        .from('likes')
        .select('post_id')
        .eq('user_id', userId);
      if (data) {
        set({ likedPosts: new Set(data.map((l: any) => l.post_id)) });
      }
    } catch (err) {
      console.error('[Feed] Fetch likes error:', err);
    }
  },

  fetchUserBookmarks: async (userId: string) => {
    try {
      const { data } = await supabase
        .from('bookmarks')
        .select('post_id')
        .eq('user_id', userId);
      if (data) {
        set({ bookmarkedPosts: new Set(data.map((b: any) => b.post_id)) });
      }
    } catch (err) {
      console.error('[Feed] Fetch bookmarks error:', err);
    }
  },

  fetchUserFollowing: async (userId: string) => {
    try {
      const { data } = await supabase
        .from('follows')
        .select('following_id')
        .eq('follower_id', userId);
      if (data) {
        set({ followingUsers: new Set(data.map((f: any) => f.following_id)) });
      }
    } catch (err) {
      console.error('[Feed] Fetch following error:', err);
    }
  },

  toggleLike: async (postId: string, userId?: string) => {
    const { likedPosts, posts, followingPosts } = get();
    const isLiked = likedPosts.has(postId);
    const newLiked = new Set(likedPosts);

    // Optimistic update
    const delta = isLiked ? -1 : 1;
    if (isLiked) {
      newLiked.delete(postId);
    } else {
      newLiked.add(postId);
    }

    set({
      likedPosts: newLiked,
      posts: posts.map(p => p.id === postId ? { ...p, likes_count: Math.max(0, p.likes_count + delta) } : p),
      followingPosts: followingPosts.map(p => p.id === postId ? { ...p, likes_count: Math.max(0, p.likes_count + delta) } : p),
    });

    if (userId) {
      try {
        if (isLiked) {
          const { error } = await supabase.from('likes').delete().eq('post_id', postId).eq('user_id', userId);
          if (error) console.error('[Feed] Unlike error:', error);
        } else {
          const { error } = await supabase.from('likes').insert({ post_id: postId, user_id: userId });
          if (error) console.error('[Feed] Like error:', error);

          // Create notification for post owner
          const post = [...posts, ...followingPosts].find(p => p.id === postId);
          if (post && post.user_id !== userId) {
            try {
              await supabase.from('notifications').insert({
                user_id: post.user_id,
                actor_id: userId,
                type: 'like',
                post_id: postId,
              });
            } catch {}
          }
        }
      } catch (err) {
        console.error('[Feed] Toggle like error:', err);
        // Revert optimistic update
        const revertLiked = new Set(newLiked);
        if (isLiked) revertLiked.add(postId);
        else revertLiked.delete(postId);
        set({
          likedPosts: revertLiked,
          posts: get().posts.map(p => p.id === postId ? { ...p, likes_count: Math.max(0, p.likes_count - delta) } : p),
          followingPosts: get().followingPosts.map(p => p.id === postId ? { ...p, likes_count: Math.max(0, p.likes_count - delta) } : p),
        });
      }
    }
  },

  toggleBookmark: async (postId: string, userId?: string) => {
    if (!userId) return;
    const { bookmarkedPosts } = get();
    const isBookmarked = bookmarkedPosts.has(postId);
    const newBookmarks = new Set(bookmarkedPosts);

    // Optimistic
    if (isBookmarked) {
      newBookmarks.delete(postId);
    } else {
      newBookmarks.add(postId);
    }
    set({ bookmarkedPosts: newBookmarks });

    try {
      if (isBookmarked) {
        await supabase.from('bookmarks').delete().eq('post_id', postId).eq('user_id', userId);
      } else {
        await supabase.from('bookmarks').insert({ post_id: postId, user_id: userId });
      }
    } catch (err) {
      console.error('[Feed] Toggle bookmark error:', err);
      // Revert
      if (isBookmarked) newBookmarks.add(postId);
      else newBookmarks.delete(postId);
      set({ bookmarkedPosts: new Set(newBookmarks) });
    }
  },

  toggleFollow: async (targetUserId: string, currentUserId: string) => {
    const { followingUsers } = get();
    const isCurrentlyFollowing = followingUsers.has(targetUserId);
    const newFollowing = new Set(followingUsers);

    if (isCurrentlyFollowing) {
      newFollowing.delete(targetUserId);
    } else {
      newFollowing.add(targetUserId);
    }
    set({ followingUsers: newFollowing });

    try {
      if (isCurrentlyFollowing) {
        const { error } = await supabase
          .from('follows')
          .delete()
          .eq('follower_id', currentUserId)
          .eq('following_id', targetUserId);
        if (error) {
          newFollowing.add(targetUserId);
          set({ followingUsers: new Set(newFollowing) });
          return false;
        }
      } else {
        const { error } = await supabase
          .from('follows')
          .insert({ follower_id: currentUserId, following_id: targetUserId });
        if (error) {
          newFollowing.delete(targetUserId);
          set({ followingUsers: new Set(newFollowing) });
          return false;
        }

        // Create follow notification
        try {
          await supabase.from('notifications').insert({
            user_id: targetUserId,
            actor_id: currentUserId,
            type: 'follow',
          });
        } catch {}
      }
      return true;
    } catch (err) {
      console.error('[Feed] Toggle follow error:', err);
      return false;
    }
  },

  isFollowing: (userId: string) => {
    return get().followingUsers.has(userId);
  },

  addPost: async (post) => {
    try {
      console.log('[Feed] addPost called - inserting to database');
      const { error } = await supabase.from('posts').insert({
        user_id: post.user_id,
        media_url: post.media_url,
        thumbnail_url: post.thumbnail_url,
        caption: post.caption,
        media_type: post.media_type,
        likes_count: 0,
        comments_count: 0,
        view_count: 0,
      });
      
      if (error) {
        console.error('[Feed] Add post error:', error.message, error.details, error.hint);
        return false;
      }
      
      console.log('[Feed] Post inserted successfully, refreshing feed...');
      get().fetchPosts(true).catch(err => {
        console.warn('[Feed] Background feed refresh failed:', err);
      });
      
      return true;
    } catch (err: any) {
      console.error('[Feed] Add post exception:', err?.message || err);
      return false;
    }
  },

  deletePost: async (postId: string, userId: string, mediaUrl?: string) => {
    try {
      console.log('[Feed] deletePost called for post:', postId);

      // Safety: only delete if user_id matches
      const { error } = await supabase
        .from('posts')
        .delete()
        .eq('id', postId)
        .eq('user_id', userId);

      if (error) {
        console.error('[Feed] Delete post error:', error.message, error.details);
        return false;
      }

      // Optimistic: remove from local state
      const { posts, followingPosts } = get();
      set({
        posts: posts.filter(p => p.id !== postId),
        followingPosts: followingPosts.filter(p => p.id !== postId),
      });

      // Best-effort: clean up related data (likes, comments, bookmarks, notifications)
      try {
        await Promise.allSettled([
          supabase.from('likes').delete().eq('post_id', postId),
          supabase.from('comments').delete().eq('post_id', postId),
          supabase.from('bookmarks').delete().eq('post_id', postId),
          supabase.from('notifications').delete().eq('post_id', postId),
        ]);
      } catch (cleanupErr) {
        console.warn('[Feed] Post cleanup partial failure (non-critical):', cleanupErr);
      }

      // Best-effort: remove media from storage
      if (mediaUrl) {
        try {
          // Extract the storage path from the URL
          // URLs look like: https://<project>.supabase.co/storage/v1/object/public/media/<path>
          const mediaMatch = mediaUrl.match(/\/storage\/v1\/object\/public\/media\/(.+)$/);
          if (mediaMatch && mediaMatch[1]) {
            const storagePath = decodeURIComponent(mediaMatch[1]);
            console.log('[Feed] Attempting to delete media file:', storagePath);
            const { error: storageError } = await supabase.storage.from('media').remove([storagePath]);
            if (storageError) {
              console.warn('[Feed] Media file delete failed (non-critical):', storageError.message);
            } else {
              console.log('[Feed] Media file deleted successfully');
            }
          }
        } catch (storageErr) {
          console.warn('[Feed] Storage cleanup failed (non-critical):', storageErr);
        }
      }

      console.log('[Feed] Post deleted successfully');
      return true;
    } catch (err: any) {
      console.error('[Feed] Delete post exception:', err?.message || err);
      return false;
    }
  },


  fetchComments: async (postId: string) => {
    try {
      console.log('[Feed] Fetching comments for post:', postId);
      const { data, error } = await supabase
        .from('comments')
        .select('*, profiles(username, avatar_url)')
        .eq('post_id', postId)
        .order('created_at', { ascending: false })
        .limit(100);
      
      if (error) {
        console.error('[Feed] Fetch comments error:', error);
        return [];
      }
      
      const comments = (data || []) as Comment[];
      console.log(`[Feed] Fetched ${comments.length} comments`);
      return comments;
    } catch (err) {
      console.error('[Feed] Fetch comments exception:', err);
      return [];
    }
  },

  addComment: async (postId: string, userId: string, content: string) => {
    try {
      console.log('[Feed] Adding comment to post:', postId);
      const { error } = await supabase.from('comments').insert({
        post_id: postId,
        user_id: userId,
        content,
      });
      
      if (error) {
        console.error('[Feed] Add comment error:', error.message, error.details);
        return false;
      }
      
      // Optimistic update for comment count
      const { posts, followingPosts } = get();
      set({
        posts: posts.map(p => p.id === postId ? { ...p, comments_count: p.comments_count + 1 } : p),
        followingPosts: followingPosts.map(p => p.id === postId ? { ...p, comments_count: p.comments_count + 1 } : p),
      });

      // Create notification for post owner
      const post = [...posts, ...followingPosts].find(p => p.id === postId);
      if (post && post.user_id !== userId) {
        try {
          await supabase.from('notifications').insert({
            user_id: post.user_id,
            actor_id: userId,
            type: 'comment',
            post_id: postId,
            comment_text: content.substring(0, 100),
          });
        } catch {}
      }
      
      console.log('[Feed] Comment added successfully');
      return true;
    } catch (err: any) {
      console.error('[Feed] Add comment exception:', err?.message || err);
      return false;
    }
  },

  incrementViews: async (postId: string) => {
    try {
      // Optimistic update - increment locally first
      const { posts, followingPosts } = get();
      set({
        posts: posts.map(p => p.id === postId ? { ...p, view_count: (p.view_count || 0) + 1 } : p),
        followingPosts: followingPosts.map(p => p.id === postId ? { ...p, view_count: (p.view_count || 0) + 1 } : p),
      });

      // Call the RPC to increment server-side
      const { error } = await supabase.rpc('increment_views', { p_post_id: postId });
      if (error) {
        console.error('[Feed] Increment views error:', error);
      }
    } catch (err) {
      console.error('[Feed] Increment views exception:', err);
    }
  },

  updatePostViewCount: (postId: string, viewCount: number) => {
    const { posts, followingPosts } = get();
    set({
      posts: posts.map(p => p.id === postId ? { ...p, view_count: viewCount } : p),
      followingPosts: followingPosts.map(p => p.id === postId ? { ...p, view_count: viewCount } : p),
    });
  },

  subscribeToFeed: () => {
    try {
      const { realtimeChannel } = get();
      if (realtimeChannel) {
        supabase.removeChannel(realtimeChannel);
      }

      const channel = supabase
        .channel('feed-realtime')
        .on(
          'postgres_changes',
          { event: 'INSERT', schema: 'public', table: 'posts' },
          (payload: any) => {
            console.log('[Feed] Realtime: New post detected:', payload.new?.id);
          }
        )
        .on(
          'postgres_changes',
          { event: 'UPDATE', schema: 'public', table: 'posts' },
          (payload: any) => {
            const updated = payload.new;
            if (updated?.id && updated.view_count !== undefined) {
              // Update view count from realtime
              get().updatePostViewCount(updated.id, updated.view_count);
            }
          }
        )
        .subscribe();

      set({ realtimeChannel: channel });
    } catch (err) {
      console.error('[Feed] Subscribe to feed error:', err);
    }
  },

  unsubscribeFromFeed: () => {
    try {
      const { realtimeChannel } = get();
      if (realtimeChannel) {
        supabase.removeChannel(realtimeChannel);
        set({ realtimeChannel: null });
      }
    } catch (err) {
      console.error('[Feed] Unsubscribe error:', err);
    }
  },

  updatePostCounts: (postId: string, field: 'likes_count' | 'comments_count', delta: number) => {
    const { posts, followingPosts } = get();
    set({
      posts: posts.map(p => p.id === postId ? { ...p, [field]: Math.max(0, p[field] + delta) } : p),
      followingPosts: followingPosts.map(p => p.id === postId ? { ...p, [field]: Math.max(0, p[field] + delta) } : p),
    });
  },

  getFollowCounts: async (userId: string) => {
    try {
      const [followersRes, followingRes] = await Promise.all([
        supabase.from('follows').select('id', { count: 'exact', head: true }).eq('following_id', userId),
        supabase.from('follows').select('id', { count: 'exact', head: true }).eq('follower_id', userId),
      ]);
      return {
        followers_count: followersRes.count || 0,
        following_count: followingRes.count || 0,
      };
    } catch {
      return { followers_count: 0, following_count: 0 };
    }
  },
}));
